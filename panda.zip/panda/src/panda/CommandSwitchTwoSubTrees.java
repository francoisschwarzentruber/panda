/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class CommandSwitchTwoSubTrees implements Command {
    private final ProofFormulaNode father;
    private final int i1;
    private final int i2;

    public CommandSwitchTwoSubTrees(ProofFormulaNode father, int i1, int i2) {
        this.father = father;
        this.i1 = i1;
        this.i2 = i2;
    }

    

    
    public void execute(ProofPanel proofPanel) {
        father.echangerChildren2(i1, i2);
    }

    public void undo(ProofPanel proofPanel) {
        father.echangerChildren2(i1, i2);
    }



}
