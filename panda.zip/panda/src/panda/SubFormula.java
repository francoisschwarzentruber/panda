/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class SubFormula {
final String formula; final String subformula; final int position;

    public SubFormula(String formula, String subformula, int position) {
        this.formula = formula;
        this.subformula = subformula;
        this.position = position;
    }

    public int getPosition() {
        return position;
    }

    public String getSubformula() {
        return subformula;
    }

    

}
