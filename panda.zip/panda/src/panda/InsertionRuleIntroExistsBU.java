/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroExistsBU extends InsertionRuleButtonOneNode {


    public InsertionRuleIntroExistsBU() throws Exception {
        super("\\frac{\\selectednode{A[t/x]}}{\\newnode{\\exists x. A}} (I \\exists)");

    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.noFather() & !node.getFormula().getFreeVariables().isEmpty();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        InsertionRuleIntroExistsBUDialog d = new InsertionRuleIntroExistsBUDialog(null, true, node.getFormula());
        d.setVisible(true);
        
        if(d.isOk())
        {
            ProofFormulaNodeNatDet father = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), d.getFormulaExistential());
        proofPanel.commandExecute(new CommandCreateFatherForNode(father, node));
        proofPanel.setNodeSelected(father);
        }
        
        
    }

}
