/*
 * MrnatureView.java
 */

package panda;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Point;
import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JMenu;
import org.jdesktop.application.Action;
import org.jdesktop.application.ResourceMap;
import org.jdesktop.application.SingleFrameApplication;
import org.jdesktop.application.FrameView;
import org.jdesktop.application.TaskMonitor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import javax.swing.Timer;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.filechooser.FileFilter;
import org.jdom.Element;
import org.jdom.JDOMException;

/**
 * The application's main frame.
 */
public class MrnatureView extends FrameView {
    private Mission mission;
    private Element elementCopy;

    

    InsertionRuleButtonOneNode setup(final InsertionRuleButtonOneNode b)
    {
        b.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if(b.testIfRuleApplicable(proofPanel.getSelectedNode()))
                      b.ruleApply(proofPanel, proofPanel.getSelectedNode());
                proofPanel.repaint();
            }
        });


        return b;
    }





    InsertionRuleButton setupMN(final InsertionRuleButton b)
    {
        b.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                if(b.testIfRuleApplicable(proofPanel.getSelectedNodes()))
                      b.ruleApply(proofPanel, proofPanel.getSelectedNodes());
                proofPanel.repaint();
            }
        });


        return b;
    }









    public MrnatureView(SingleFrameApplication app) {
        super(app);

        initComponents();


        panInsertionRules.add(setup(new InsertionRuleEliminationAndG()));
        panInsertionRulesBU.add(setup(new InsertionRuleEliminationAndGBU()));
        panInsertionRules.add(setup(new InsertionRuleEliminationAndD()));
        panInsertionRulesBU.add(setup(new InsertionRuleEliminationAndDBU()));
        panInsertionRules.add(setup(new InsertionRuleEliminationImply()));
        panInsertionRulesBU.add(setup(new InsertionRuleEliminationImplyBU()));
        panInsertionRules.add(setup(new InsertionRuleEliminationNotNot()));
        panInsertionRulesBU.add(setup(new InsertionRuleEliminationNotNotBU()));
        panInsertionRules.add(setup(new InsertionRuleEliminationBottom()));
        panInsertionRulesBU.add(setup(new InsertionRuleEliminationBottomBU()));
        panInsertionRules.add(setup(new InsertionRuleEliminationOr()));
        panInsertionRules.add(setup(new InsertionRuleIntroAnd()));
        panInsertionRules.add(setup(new InsertionRuleIntroOr1()));
        panInsertionRules.add(setup(new InsertionRuleIntroOr2()));
        panInsertionRules.add(setup(new InsertionRuleIntroBottom()));
        panInsertionRulesBU.add(setup(new InsertionRuleIntroBottomBU()));
        panInsertionRules.add(setup(new InsertionRuleIntroImply()));
        panInsertionRules.add(setup(new InsertionRuleIntroNot()));
        panInsertionRules.add(setup(new InsertionRuleIntroAndEchangerAB()));
        panInsertionRules.add(setup(new InsertionRuleIntroOrEchangerAB()));
        panInsertionRules.add(setup(new InsertionRuleEliminationOrEchangerDerniersArbres()));


        panInsertionRules.add(setup(new InsertionRuleIntroForall()));
        panInsertionRules.add(setup(new InsertionRuleIntroExists()));
        panInsertionRules.add(setup(new InsertionRuleEliminationExists()));

        panInsertionRulesBU.add(setupMN(new InsertionRuleIntroAndBUTwoNodes()));
        panInsertionRulesBU.add(setupMN(new InsertionRuleIntroEquivBU()));
        panInsertionRulesBU.add(setupMN(new InsertionRuleEliminationImplyBUTwoNodes()));
        panInsertionRulesBU.add(setupMN(new InsertionRuleIntroBottomBUTwoNodes()));
        panInsertionRulesBU.add(setupMN(new InsertionRuleEliminationOrBUThreeNodes()));
        panInsertionRulesBU.add(setupMN(new InsertionRuleEliminationOrBUTwoNodes()));
        panInsertionRulesBU.add(setupMN(new InsertionRuleEliminationOrBUNodeOr()));

        panInsertionRulesBU.add(setup(new InsertionRuleEliminationForallBU()));
        panInsertionRulesBU.add(setup(new InsertionRuleEliminationExistsBUNodeExists()));
        panInsertionRulesBU.add(setupMN(new InsertionRuleEliminationExistsBUTwoNodes()));
        panInsertionRulesBU.add(setupMN(new InsertionRuleEliminationExistsBUTwoNodes2()));
        // status bar initialization - message timeout, idle icon and busy animation, etc
        ResourceMap resourceMap = getResourceMap();
        int messageTimeout = resourceMap.getInteger("StatusBar.messageTimeout");
        messageTimer = new Timer(messageTimeout, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                statusMessageLabel.setText("");
            }
        });
        messageTimer.setRepeats(false);
        int busyAnimationRate = resourceMap.getInteger("StatusBar.busyAnimationRate");
        for (int i = 0; i < busyIcons.length; i++) {
            busyIcons[i] = resourceMap.getIcon("StatusBar.busyIcons[" + i + "]");
        }
        busyIconTimer = new Timer(busyAnimationRate, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                busyIconIndex = (busyIconIndex + 1) % busyIcons.length;
                statusAnimationLabel.setIcon(busyIcons[busyIconIndex]);
            }
        });
        idleIcon = resourceMap.getIcon("StatusBar.idleIcon");
        statusAnimationLabel.setIcon(idleIcon);
        progressBar.setVisible(false);

        // connecting action tasks to status bar via TaskMonitor
        TaskMonitor taskMonitor = new TaskMonitor(getApplication().getContext());
        taskMonitor.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                String propertyName = evt.getPropertyName();
                if ("started".equals(propertyName)) {
                    if (!busyIconTimer.isRunning()) {
                        statusAnimationLabel.setIcon(busyIcons[0]);
                        busyIconIndex = 0;
                        busyIconTimer.start();
                    }
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(true);
                } else if ("done".equals(propertyName)) {
                    busyIconTimer.stop();
                    statusAnimationLabel.setIcon(idleIcon);
                    progressBar.setVisible(false);
                    progressBar.setValue(0);
                } else if ("message".equals(propertyName)) {
                    String text = (String)(evt.getNewValue());
                    statusMessageLabel.setText((text == null) ? "" : text);
                    messageTimer.restart();
                } else if ("progress".equals(propertyName)) {
                    int value = (Integer)(evt.getNewValue());
                    progressBar.setVisible(true);
                    progressBar.setIndeterminate(false);
                    progressBar.setValue(value);
                }
            }
        });

        proofPanel.setActionListenerSelectionChange(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                cmdNodesRemove.setVisible(!proofPanel.getSelectedNodes().isEmpty());
                panPaletteMettreAJour();
                panHypothesesADechargerMettreAJour();
            }
        });


        proofPanel.setActionListenerModification(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                panHypothesesADechargerMettreAJour();
                panMissionMettreAJour();
            }



            
        });

        panPaletteMettreAJour();
        setMission(null);
        
        mnuNiveau1.add(setupMenuItemExample(new MenuItemExample("((a imply (b imply c)) imply (b imply (a imply c)))")));
        mnuNiveau1.add(setupMenuItemExample(new MenuItemExample("((a and (a or b)) equiv a)")));
        mnuNiveau1.add(setupMenuItemExample(new MenuItemExample("((c imply a) imply ((c imply b) imply (c imply (a and b))))")));
        addFormulaExample(mnuNiveau1, "((a imply b) equiv ((a and b) equiv a))");
        addFormulaExample(mnuNiveau1, "((a imply (b imply c)) imply ((a imply b) imply (a imply c)))");
        addFormulaExample(mnuNiveau1, "((c imply (a and b)) equiv ((c imply a) and (c imply b)))");

        mnuNiveau2.add(setupMenuItemExample(new MenuItemExample("((a imply b) equiv ((a or b) equiv b))")));
        mnuNiveau2.add(setupMenuItemExample(new MenuItemExample("((a or (a and b)) imply a)")));
        addFormulaExample(mnuNiveau2, "((a and (b or c)) imply ((a and b) or (a and c)))");
        addFormulaExample(mnuNiveau2, "((a or (b and c)) imply ((a or b) and (a or c)))");
        addFormulaExample(mnuNiveau2, "((a imply c) imply ((b imply c) imply ((a or b) imply c)))");
        addFormulaExample(mnuNiveau2, "(((a imply c) and (b imply c)) imply ((a or b) imply c))");
        
        
        mnuNiveau3.add(setupMenuItemExample(new MenuItemExample("(a equiv (not (not a)))")));
        mnuNiveau3.add(setupMenuItemExample(new MenuItemExample("((a imply b) imply ((not b) imply (not a)))")));
        mnuNiveau3.add(setupMenuItemExample(new MenuItemExample("(a or (not a))")));
        mnuNiveau3.add(setupMenuItemExample(new MenuItemExample("(((a imply b) imply a) imply a)")));
        addFormulaExample(mnuNiveau3, "((a and b) equiv (not ((not a) or (not b))))");
        addFormulaExample(mnuNiveau3, "((a imply b) equiv (not (a and (not b))))");
        addFormulaExample(mnuNiveau3, "((not (a and b)) equiv ((not a) or (not b)))");
        addFormulaExample(mnuNiveau3, "((a or b) equiv (not ((not a) and (not b))))");
        addFormulaExample(mnuNiveau3, "((not (a or b)) equiv ((not a) and (not b)))");
        addFormulaExample(mnuNiveau3, "((a imply b) equiv ((not a) or b))");



       String reflexiveFormula = "(forall x (R x x))";
       String serielFormula = "(forall x (exists y (R x y)))";
       String denseFormula = "(forall x (forall y ((R x y) imply (exists z ((R x z) and (R z y))))))";
       String irreflexiveFormula = "(forall x (not (R x x)))";
       String transitiveFormula = "(forall x (forall y (forall z (((R x y) and (R y z)) imply (R x z)))))";
       String symetricFormula = "(forall x (forall y ((R x y) imply (R y x))))";
       String asymetricFormula = "(forall x (forall y ((R x y) imply (not (R y x)))))";
       String confluentFormula = "(forall x (forall y (forall z (((R x y) and (R x z)) imply (exists u ((R y u) and (R z u)))))))";
       String euclidianFormula = "(forall x (forall y (forall z (( (R x y) and (R x z)) imply (R y z)))))";




        addFormulaExample(mnuNiveau4, "((forall x (R x x)) imply (forall x (exists y (R x y))))");




        addFormulaExample(mnuNiveau4, "((exists x (forall y (R x y))) imply (forall y (exists x (R x y))))");
        //addFormulaExample(mnuNiveau5, "((( and (forall x (exists y (R x y)))) and (forall x (forall y ((R x y) imply (R y x))))) imply (forall x (R x x)))");
        




       mnuNiveau4.add(setupMenuItemExample(
         new MenuItemExample(reflexiveFormula,
                             serielFormula)));



       mnuNiveau4.add(setupMenuItemExample(
         new MenuItemExample(reflexiveFormula,
                             denseFormula)));

       mnuNiveau4.add(setupMenuItemExample(
         new MenuItemExample(asymetricFormula,
                             irreflexiveFormula)));


       mnuNiveau4.add(setupMenuItemExample(
         new MenuItemExample("(exists x (p x))",
                             "(not (forall x (not (p x))))")));

       mnuNiveau4.add(setupMenuItemExample(
         new MenuItemExample("(exists x (p x x))",
                             "(exists x (exists y (p x y)))")));

       mnuNiveau5.add(setupMenuItemExample(
         new MenuItemExample(irreflexiveFormula,transitiveFormula,
                             asymetricFormula)));

      mnuNiveau5.add(setupMenuItemExample(
         new MenuItemExample(symetricFormula, confluentFormula)));

      mnuNiveau5.add(setupMenuItemExample(
         new MenuItemExample(symetricFormula, transitiveFormula, euclidianFormula)));
      mnuNiveau5.add(setupMenuItemExample(
         new MenuItemExample(serielFormula, symetricFormula, transitiveFormula, reflexiveFormula)));


      mnuNiveau5.add(setupMenuItemExample(
         new MenuItemExample(reflexiveFormula, euclidianFormula, symetricFormula)));

      mnuNiveau5.add(setupMenuItemExample(
         new MenuItemExample(reflexiveFormula, euclidianFormula, transitiveFormula)));
        

      java.net.URL helpURL = getClass().getResource(java.util.ResourceBundle.getBundle("panda/resources/MrnatureView").getString("helpGeneralFileName"));
        try {
            jEditorPaneHelp.setPage(helpURL);
        } catch (IOException ex) {
            Logger.getLogger(MrnatureView.class.getName()).log(Level.SEVERE, null, ex);
        }



      getFrame().setTitle(getStringFromRessource("applicationTitle"));

    }



    private String getStringFromRessource(String key)
    {
        return java.util.ResourceBundle.getBundle("panda/resources/MrnatureView").getString(key);
    }


    private void panHypothesesADechargerMettreAJour() {
        panHypothesesADecharger.removeAll();


        Set<Formula> hypothesePeutEtreDechargeable = new HashSet<Formula>();
        
        if(proofPanel.getSelectedNode() != null)
        {
            if(proofPanel.getSelectedNode().getFormula().isNot())
                hypothesePeutEtreDechargeable.add(proofPanel.getSelectedNode().getFormula().getSubFormulaForNot());
            else if(proofPanel.getSelectedNode().getFormula().isOr())
            {
                hypothesePeutEtreDechargeable.add(proofPanel.getSelectedNode().getFormula().getSubFormulaLeft());
                hypothesePeutEtreDechargeable.add(proofPanel.getSelectedNode().getFormula().getSubFormulaRight());
            }
            else if(proofPanel.getSelectedNode().getFormula().isExists())
            {
                hypothesePeutEtreDechargeable.add(proofPanel.getSelectedNode().getFormula().getQuantifierSubFormula());
            }

        }



        for(final Formula formula : hypothesePeutEtreDechargeable)
        {
            ButtonHypothesePeutEtreDechargeable b = null;
            try {
                b = new ButtonHypothesePeutEtreDechargeable(formula);
            } catch (Exception ex) {
                Logger.getLogger(MrnatureView.class.getName()).log(Level.SEVERE, null, ex);
            }

            b.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    ProofFormulaNodeNatDet node = new ProofFormulaNodeNatDet(new Point(100, 100), formula);
                    proofPanel.commandExecute(new CommandAddNode(node));
                    proofPanel.moveNodeToEnsureNoOverlaping(node);
                    proofPanel.repaint();
                }
            });



            panHypothesesADecharger.add(b);
        }


        Set<HypotheseTemporaireDechargee> hypothesesADecharger = proofPanel.getHypothesesADecharger();

        for(final HypotheseTemporaireDechargee hypothese : hypothesesADecharger)
        {
            ButtonHypotheseADecharger b = null;
            try {
                b = new ButtonHypotheseADecharger(hypothese);
            } catch (Exception ex) {
                Logger.getLogger(MrnatureView.class.getName()).log(Level.SEVERE, null, ex);
            }

            b.addActionListener(new ActionListener() {

                public void actionPerformed(ActionEvent e) {
                    ProofFormulaNodeNatDet node = new ProofFormulaNodeNatDet(new Point(100, 100), hypothese.getFormula());
                    proofPanel.commandExecute(new CommandAddNode(node));
                    proofPanel.moveNodeToEnsureNoOverlaping(node);
                    proofPanel.repaint();
                }
            });



            panHypothesesADecharger.add(b);
        }
        panHypothesesADecharger.doLayout();
        panHypothesesADecharger.repaint();
    }




    private MenuItemExample setupMenuItemExample(final MenuItemExample m)
    {
        m.addActionListener(new ActionListener() {


            public void actionPerformed(ActionEvent e) {
                  proofPanel.clear();
                  proofPanel.nodeAdd(new ProofFormulaNodeNatDet(new Point(proofPanel.getWidth()/2, proofPanel.getHeight()/2), m.getGoalFormula()));
                  proofPanel.repaint();
                  panHypothesePrincipales.removeAll();
                  setMission(new Mission(m.getHypothesisFormulas(), m.getGoalFormula()));
                  
                  for(final Formula formula : m.getHypothesisFormulas())
                  {
                      ButtonFormula b = null;
                    try {
                        b = new ButtonFormula(formula);
                    } catch (Exception ex) {
                        Logger.getLogger(MrnatureView.class.getName()).log(Level.SEVERE, null, ex);
                    }

                    b.addActionListener(new ActionListener() {

                        public void actionPerformed(ActionEvent e) {
                            ProofFormulaNodeNatDet node = new ProofFormulaNodeNatDet(new Point(100, 100), formula);
                            proofPanel.commandExecute(new CommandAddNode(node));
                            proofPanel.moveNodeToEnsureNoOverlaping(node);
                            proofPanel.repaint();
                        }
                    });
                    panHypothesePrincipales.add(b);
                    panHypothesePrincipales.doLayout();
                    
                    
                  }
            }

            
        });
        return m;
    }


    @Action
    public void showAboutBox() {
        if (aboutBox == null) {
            JFrame mainFrame = MrnatureApp.getApplication().getMainFrame();
            aboutBox = new MrnatureAboutBox(mainFrame);
            aboutBox.setLocationRelativeTo(mainFrame);
        }
        MrnatureApp.getApplication().show(aboutBox);
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        panPalette = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        panFormulas = new javax.swing.JPanel();
        cmdNodesRemove = new javax.swing.JButton();
        jScrollPaneInsertionRules = new javax.swing.JScrollPane();
        jPanel3 = new javax.swing.JPanel();
        panInsertionRules = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        panInsertionRulesBU = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        panInsertionRuleButtonsCustomized = new javax.swing.JPanel();
        panAide = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jEditorPaneHelp = new javax.swing.JEditorPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        panHypothesePrincipales = new javax.swing.JPanel();
        panHypothesesADecharger = new javax.swing.JPanel();
        panMission = new javax.swing.JPanel();
        cmdMission = new javax.swing.JButton();
        lblMissionGagnee = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        proofPanel = new ProofPanelWithHint();
        menuBar = new javax.swing.JMenuBar();
        javax.swing.JMenu fileMenu = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        mnuLoad = new javax.swing.JMenuItem();
        mnuSave = new javax.swing.JMenuItem();
        mnuLaTEXCode = new javax.swing.JMenuItem();
        javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        mnuUndo = new javax.swing.JMenuItem();
        mnuRedo = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        mnuNiveau1 = new javax.swing.JMenu();
        mnuNiveau2 = new javax.swing.JMenu();
        mnuNiveau3 = new javax.swing.JMenu();
        mnuNiveau4 = new javax.swing.JMenu();
        mnuNiveau5 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        mnuProofRead = new javax.swing.JMenuItem();
        javax.swing.JMenu helpMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem aboutMenuItem = new javax.swing.JMenuItem();
        mnuGeneralHelp = new javax.swing.JMenuItem();
        statusPanel = new javax.swing.JPanel();
        javax.swing.JSeparator statusPanelSeparator = new javax.swing.JSeparator();
        statusMessageLabel = new javax.swing.JLabel();
        statusAnimationLabel = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();

        mainPanel.setName("mainPanel"); // NOI18N
        mainPanel.setLayout(new javax.swing.BoxLayout(mainPanel, javax.swing.BoxLayout.LINE_AXIS));

        panPalette.setMaximumSize(new java.awt.Dimension(232, 32767));
        panPalette.setName("panPalette"); // NOI18N
        panPalette.setPreferredSize(new java.awt.Dimension(232, 254));
        panPalette.setLayout(new javax.swing.BoxLayout(panPalette, javax.swing.BoxLayout.PAGE_AXIS));

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(panda.MrnatureApp.class).getContext().getResourceMap(MrnatureView.class);
        jButton1.setIcon(resourceMap.getIcon("jButton1.icon")); // NOI18N
        jButton1.setText(resourceMap.getString("jButton1.text")); // NOI18N
        jButton1.setName("jButton1"); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        panPalette.add(jButton1);

        panFormulas.setName("panFormulas"); // NOI18N
        panFormulas.setLayout(new javax.swing.BoxLayout(panFormulas, javax.swing.BoxLayout.PAGE_AXIS));
        panPalette.add(panFormulas);

        cmdNodesRemove.setIcon(resourceMap.getIcon("cmdNodesRemove.icon")); // NOI18N
        cmdNodesRemove.setText(resourceMap.getString("cmdNodesRemove.text")); // NOI18N
        cmdNodesRemove.setName("cmdNodesRemove"); // NOI18N
        cmdNodesRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdNodesRemoveActionPerformed(evt);
            }
        });
        panPalette.add(cmdNodesRemove);

        jScrollPaneInsertionRules.setName("jScrollPaneInsertionRules"); // NOI18N

        jPanel3.setName("jPanel3"); // NOI18N
        jPanel3.setLayout(new javax.swing.BoxLayout(jPanel3, javax.swing.BoxLayout.PAGE_AXIS));

        panInsertionRules.setName("panInsertionRules"); // NOI18N
        panInsertionRules.setLayout(new javax.swing.BoxLayout(panInsertionRules, javax.swing.BoxLayout.PAGE_AXIS));

        jLabel2.setBackground(resourceMap.getColor("jLabel2.background")); // NOI18N
        jLabel2.setFont(resourceMap.getFont("jLabel2.font")); // NOI18N
        jLabel2.setForeground(resourceMap.getColor("jLabel2.foreground")); // NOI18N
        jLabel2.setText(resourceMap.getString("jLabel2.text")); // NOI18N
        jLabel2.setName("jLabel2"); // NOI18N
        jLabel2.setOpaque(true);
        panInsertionRules.add(jLabel2);

        jPanel3.add(panInsertionRules);

        panInsertionRulesBU.setName("panInsertionRulesBU"); // NOI18N
        panInsertionRulesBU.setLayout(new javax.swing.BoxLayout(panInsertionRulesBU, javax.swing.BoxLayout.PAGE_AXIS));

        jLabel3.setBackground(resourceMap.getColor("jLabel2.background")); // NOI18N
        jLabel3.setFont(resourceMap.getFont("jLabel2.font")); // NOI18N
        jLabel3.setForeground(resourceMap.getColor("jLabel2.foreground")); // NOI18N
        jLabel3.setText(resourceMap.getString("jLabel3.text")); // NOI18N
        jLabel3.setName("jLabel3"); // NOI18N
        jLabel3.setOpaque(true);
        panInsertionRulesBU.add(jLabel3);

        panInsertionRuleButtonsCustomized.setFocusCycleRoot(true);
        panInsertionRuleButtonsCustomized.setName("panInsertionRuleButtonsCustomized"); // NOI18N
        panInsertionRuleButtonsCustomized.setLayout(new javax.swing.BoxLayout(panInsertionRuleButtonsCustomized, javax.swing.BoxLayout.PAGE_AXIS));
        panInsertionRulesBU.add(panInsertionRuleButtonsCustomized);

        jPanel3.add(panInsertionRulesBU);

        jScrollPaneInsertionRules.setViewportView(jPanel3);

        panPalette.add(jScrollPaneInsertionRules);

        panAide.setName("panAide"); // NOI18N
        panAide.setLayout(new java.awt.BorderLayout());

        jScrollPane2.setName("jScrollPane2"); // NOI18N

        jEditorPaneHelp.setEditable(false);
        jEditorPaneHelp.setText(resourceMap.getString("jEditorPaneHelp.text")); // NOI18N
        jEditorPaneHelp.setName("jEditorPaneHelp"); // NOI18N
        jScrollPane2.setViewportView(jEditorPaneHelp);

        panAide.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        panPalette.add(panAide);

        mainPanel.add(panPalette);

        jPanel1.setName("jPanel1"); // NOI18N
        jPanel1.setLayout(new javax.swing.BoxLayout(jPanel1, javax.swing.BoxLayout.PAGE_AXIS));

        jPanel2.setMaximumSize(new java.awt.Dimension(32767, 64));
        jPanel2.setMinimumSize(new java.awt.Dimension(277, 64));
        jPanel2.setName("jPanel2"); // NOI18N
        jPanel2.setPreferredSize(new java.awt.Dimension(260, 64));
        jPanel2.setLayout(new javax.swing.BoxLayout(jPanel2, javax.swing.BoxLayout.LINE_AXIS));

        jLabel1.setIcon(resourceMap.getIcon("jLabel1.icon")); // NOI18N
        jLabel1.setText(resourceMap.getString("jLabel1.text")); // NOI18N
        jLabel1.setName("jLabel1"); // NOI18N
        jPanel2.add(jLabel1);

        panHypothesePrincipales.setName("panHypothesePrincipales"); // NOI18N
        jPanel2.add(panHypothesePrincipales);

        panHypothesesADecharger.setName("panHypothesesADecharger"); // NOI18N
        panHypothesesADecharger.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        jPanel2.add(panHypothesesADecharger);

        panMission.setName("panMission"); // NOI18N
        panMission.setLayout(new javax.swing.BoxLayout(panMission, javax.swing.BoxLayout.LINE_AXIS));

        cmdMission.setText(resourceMap.getString("cmdMission.text")); // NOI18N
        cmdMission.setName("cmdMission"); // NOI18N
        cmdMission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmdMissionActionPerformed(evt);
            }
        });
        panMission.add(cmdMission);

        lblMissionGagnee.setIcon(new ImageIcon(this.getClass().getResource("resources/anim_panda15.gif")));
        lblMissionGagnee.setText(resourceMap.getString("lblMissionGagnee.text")); // NOI18N
        lblMissionGagnee.setName("lblMissionGagnee"); // NOI18N
        panMission.add(lblMissionGagnee);

        jPanel2.add(panMission);

        jPanel1.add(jPanel2);

        jScrollPane1.setName("jScrollPane1"); // NOI18N

        proofPanel.setName("proofPanel"); // NOI18N
        proofPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                proofPanelMouseClicked(evt);
            }
        });

        org.jdesktop.layout.GroupLayout proofPanelLayout = new org.jdesktop.layout.GroupLayout(proofPanel);
        proofPanel.setLayout(proofPanelLayout);
        proofPanelLayout.setHorizontalGroup(
            proofPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 351, Short.MAX_VALUE)
        );
        proofPanelLayout.setVerticalGroup(
            proofPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(0, 279, Short.MAX_VALUE)
        );

        jScrollPane1.setViewportView(proofPanel);

        jPanel1.add(jScrollPane1);

        mainPanel.add(jPanel1);

        menuBar.setName("menuBar"); // NOI18N

        fileMenu.setText(resourceMap.getString("fileMenu.text")); // NOI18N
        fileMenu.setName("fileMenu"); // NOI18N

        jMenuItem1.setText(resourceMap.getString("jMenuItem1.text")); // NOI18N
        jMenuItem1.setName("jMenuItem1"); // NOI18N
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        fileMenu.add(jMenuItem1);

        mnuLoad.setText(resourceMap.getString("mnuLoad.text")); // NOI18N
        mnuLoad.setName("mnuLoad"); // NOI18N
        mnuLoad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuLoadActionPerformed(evt);
            }
        });
        fileMenu.add(mnuLoad);

        mnuSave.setText(resourceMap.getString("mnuSave.text")); // NOI18N
        mnuSave.setName("mnuSave"); // NOI18N
        mnuSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuSaveActionPerformed(evt);
            }
        });
        fileMenu.add(mnuSave);

        mnuLaTEXCode.setText(resourceMap.getString("mnuLaTEXCode.text")); // NOI18N
        mnuLaTEXCode.setName("mnuLaTEXCode"); // NOI18N
        mnuLaTEXCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuLaTEXCodeActionPerformed(evt);
            }
        });
        fileMenu.add(mnuLaTEXCode);

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(panda.MrnatureApp.class).getContext().getActionMap(MrnatureView.class, this);
        exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
        exitMenuItem.setName("exitMenuItem"); // NOI18N
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        jMenu1.setText(resourceMap.getString("jMenu1.text")); // NOI18N
        jMenu1.setName("jMenu1"); // NOI18N

        mnuUndo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Z, java.awt.event.InputEvent.CTRL_MASK));
        mnuUndo.setText(resourceMap.getString("mnuUndo.text")); // NOI18N
        mnuUndo.setName("mnuUndo"); // NOI18N
        mnuUndo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuUndoActionPerformed(evt);
            }
        });
        jMenu1.add(mnuUndo);

        mnuRedo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_Y, java.awt.event.InputEvent.CTRL_MASK));
        mnuRedo.setText(resourceMap.getString("mnuRedo.text")); // NOI18N
        mnuRedo.setName("mnuRedo"); // NOI18N
        mnuRedo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuRedoActionPerformed(evt);
            }
        });
        jMenu1.add(mnuRedo);

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem3.setText(resourceMap.getString("jMenuItem3.text")); // NOI18N
        jMenuItem3.setName("jMenuItem3"); // NOI18N
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem3);

        jMenuItem4.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_V, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem4.setText(resourceMap.getString("jMenuItem4.text")); // NOI18N
        jMenuItem4.setName("jMenuItem4"); // NOI18N
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem4);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_DELETE, 0));
        jMenuItem2.setText(resourceMap.getString("jMenuItem2.text")); // NOI18N
        jMenuItem2.setName("jMenuItem2"); // NOI18N
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        menuBar.add(jMenu1);

        mnuNiveau1.setText(resourceMap.getString("mnuNiveau1.text")); // NOI18N
        mnuNiveau1.setName("mnuNiveau1"); // NOI18N
        menuBar.add(mnuNiveau1);

        mnuNiveau2.setText(resourceMap.getString("mnuNiveau2.text")); // NOI18N
        mnuNiveau2.setName("mnuNiveau2"); // NOI18N
        menuBar.add(mnuNiveau2);

        mnuNiveau3.setText(resourceMap.getString("mnuNiveau3.text")); // NOI18N
        mnuNiveau3.setName("mnuNiveau3"); // NOI18N
        menuBar.add(mnuNiveau3);

        mnuNiveau4.setText(resourceMap.getString("mnuNiveau4.text")); // NOI18N
        mnuNiveau4.setName("mnuNiveau4"); // NOI18N
        menuBar.add(mnuNiveau4);

        mnuNiveau5.setText(resourceMap.getString("mnuNiveau5.text")); // NOI18N
        mnuNiveau5.setName("mnuNiveau5"); // NOI18N
        menuBar.add(mnuNiveau5);

        jMenu2.setText(resourceMap.getString("jMenu2.text")); // NOI18N
        jMenu2.setName("jMenu2"); // NOI18N

        mnuProofRead.setText(resourceMap.getString("mnuProofRead.text")); // NOI18N
        mnuProofRead.setName("mnuProofRead"); // NOI18N
        mnuProofRead.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuProofReadActionPerformed(evt);
            }
        });
        jMenu2.add(mnuProofRead);

        menuBar.add(jMenu2);

        helpMenu.setText(resourceMap.getString("helpMenu.text")); // NOI18N
        helpMenu.setName("helpMenu"); // NOI18N

        aboutMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
        aboutMenuItem.setName("aboutMenuItem"); // NOI18N
        helpMenu.add(aboutMenuItem);

        mnuGeneralHelp.setText(resourceMap.getString("mnuGeneralHelp.text")); // NOI18N
        mnuGeneralHelp.setName("mnuGeneralHelp"); // NOI18N
        mnuGeneralHelp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuGeneralHelpActionPerformed(evt);
            }
        });
        helpMenu.add(mnuGeneralHelp);

        menuBar.add(helpMenu);

        statusPanel.setName("statusPanel"); // NOI18N

        statusPanelSeparator.setName("statusPanelSeparator"); // NOI18N

        statusMessageLabel.setName("statusMessageLabel"); // NOI18N

        statusAnimationLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        statusAnimationLabel.setName("statusAnimationLabel"); // NOI18N

        progressBar.setName("progressBar"); // NOI18N

        org.jdesktop.layout.GroupLayout statusPanelLayout = new org.jdesktop.layout.GroupLayout(statusPanel);
        statusPanel.setLayout(statusPanelLayout);
        statusPanelLayout.setHorizontalGroup(
            statusPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(statusPanelSeparator, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, 585, Short.MAX_VALUE)
            .add(statusPanelLayout.createSequentialGroup()
                .addContainerGap()
                .add(statusMessageLabel)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, 415, Short.MAX_VALUE)
                .add(progressBar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED)
                .add(statusAnimationLabel)
                .addContainerGap())
        );
        statusPanelLayout.setVerticalGroup(
            statusPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.LEADING)
            .add(statusPanelLayout.createSequentialGroup()
                .add(statusPanelSeparator, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, 2, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(org.jdesktop.layout.LayoutStyle.RELATED, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .add(statusPanelLayout.createParallelGroup(org.jdesktop.layout.GroupLayout.BASELINE)
                    .add(statusMessageLabel)
                    .add(statusAnimationLabel)
                    .add(progressBar, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE, org.jdesktop.layout.GroupLayout.DEFAULT_SIZE, org.jdesktop.layout.GroupLayout.PREFERRED_SIZE))
                .add(3, 3, 3))
        );

        setComponent(mainPanel);
        setMenuBar(menuBar);
        setStatusBar(statusPanel);
    }// </editor-fold>//GEN-END:initComponents

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        proofPanel.clear();
        panHypothesePrincipales.removeAll();
        setMission(null);
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        FormulaDialog f;
        f = new FormulaDialog(null, true,  proofPanel.getFormulasHypotheses(), java.util.ResourceBundle.getBundle("panda/resources/MrnatureView").getString("enterFormulaMessage"));

        f.setVisible(true);
        if(f.isOK())
        {
            proofPanel.commandExecute(new CommandAddNode(new ProofFormulaNodeNatDet(new Point(100, 100), f.getFormula())));
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cmdNodesRemoveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdNodesRemoveActionPerformed
        proofPanel.commandExecute(new CommandRemoveNodes(proofPanel.getSelectedNodes()));
    }//GEN-LAST:event_cmdNodesRemoveActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        proofPanel.commandExecute(new CommandRemoveNodes(proofPanel.getSelectedNodes()));
    }//GEN-LAST:event_jMenuItem2ActionPerformed




    private void proofPanelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_proofPanelMouseClicked
        
    }//GEN-LAST:event_proofPanelMouseClicked

    private void mnuLaTEXCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuLaTEXCodeActionPerformed
        LaTEXCodeDialog d = new LaTEXCodeDialog(getFrame(), true, proofPanel.getLaTEXCode());
        d.setVisible(true);
    }//GEN-LAST:event_mnuLaTEXCodeActionPerformed

    private void mnuRedoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuRedoActionPerformed
        proofPanel.commandReDo();
    }//GEN-LAST:event_mnuRedoActionPerformed

    private void mnuUndoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuUndoActionPerformed
        proofPanel.commandUnDo();
    }//GEN-LAST:event_mnuUndoActionPerformed

    private void cmdMissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmdMissionActionPerformed
       MissionDialog d = new MissionDialog(getFrame(), true, mission);
       d.setVisible(true);
    }//GEN-LAST:event_cmdMissionActionPerformed



    private FileFilter getFileFilter()
    {
        return new FileFilter() {

            @Override
            public boolean accept(File f) {
                return f.getName().endsWith(".panda");
            }

            @Override
            public String getDescription() {
                return "Panda proof (*.panda)";
            }
        };
    }


    
    private String demanderFichierNomPourSauvegarder()
    {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle(getStringFromRessource("mnuSave.text"));
        fc.setFileFilter(getFileFilter());
        if(fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
        {
            if(fc.getSelectedFile().getAbsolutePath().endsWith(".panda"))
            {
                return fc.getSelectedFile().getAbsolutePath();
            }
            else
            {
                return fc.getSelectedFile().getAbsolutePath() + ".panda";
            }

        }
        else
            return null;
    }



    private String demanderFichierNomPourOuvrir()
    {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle(getStringFromRessource("mnuLoad.text"));
        fc.setFileFilter(getFileFilter());
        if(fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
        {
            return fc.getSelectedFile().getAbsolutePath();

        }
        else
            return null;
    }



    private void mnuSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuSaveActionPerformed
       String fileName = demanderFichierNomPourSauvegarder();

       if(fileName != null)
        {
                try {
                    cursorTravail();
                    proofPanel.saveInFile(fileName);
                    cursorRepos();
                } catch (IOException ex)
                {
                    cursorRepos();
                }

         }



    }//GEN-LAST:event_mnuSaveActionPerformed

    private void mnuLoadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuLoadActionPerformed
        String fileName = demanderFichierNomPourOuvrir();

        if(fileName == null)
            return;
        
        try {
            proofPanel.openFromFile(fileName);
        } catch (JDOMException ex) {
            Logger.getLogger(MrnatureView.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(MrnatureView.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_mnuLoadActionPerformed

    private void mnuProofReadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuProofReadActionPerformed
        VoiceTopDown v = new VoiceTopDown(proofPanel);
        v.start();
    }//GEN-LAST:event_mnuProofReadActionPerformed

    private void mnuGeneralHelpActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuGeneralHelpActionPerformed
        Help.show("general.html");
    }//GEN-LAST:event_mnuGeneralHelpActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        elementCopy = proofPanel.getSelectedNode().saveRecursive();
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        proofPanel.commandExecute(new CommandTreeAdd(elementCopy));
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cmdMission;
    private javax.swing.JButton cmdNodesRemove;
    private javax.swing.JButton jButton1;
    private javax.swing.JEditorPane jEditorPaneHelp;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPaneInsertionRules;
    private javax.swing.JLabel lblMissionGagnee;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenuItem mnuGeneralHelp;
    private javax.swing.JMenuItem mnuLaTEXCode;
    private javax.swing.JMenuItem mnuLoad;
    private javax.swing.JMenu mnuNiveau1;
    private javax.swing.JMenu mnuNiveau2;
    private javax.swing.JMenu mnuNiveau3;
    private javax.swing.JMenu mnuNiveau4;
    private javax.swing.JMenu mnuNiveau5;
    private javax.swing.JMenuItem mnuProofRead;
    private javax.swing.JMenuItem mnuRedo;
    private javax.swing.JMenuItem mnuSave;
    private javax.swing.JMenuItem mnuUndo;
    private javax.swing.JPanel panAide;
    private javax.swing.JPanel panFormulas;
    private javax.swing.JPanel panHypothesePrincipales;
    private javax.swing.JPanel panHypothesesADecharger;
    private javax.swing.JPanel panInsertionRuleButtonsCustomized;
    private javax.swing.JPanel panInsertionRules;
    private javax.swing.JPanel panInsertionRulesBU;
    private javax.swing.JPanel panMission;
    private javax.swing.JPanel panPalette;
    private javax.swing.JProgressBar progressBar;
    private panda.ProofPanel proofPanel;
    private javax.swing.JLabel statusAnimationLabel;
    private javax.swing.JLabel statusMessageLabel;
    private javax.swing.JPanel statusPanel;
    // End of variables declaration//GEN-END:variables

    private final Timer messageTimer;
    private final Timer busyIconTimer;
    private final Icon idleIcon;
    private final Icon[] busyIcons = new Icon[15];
    private int busyIconIndex = 0;

    private JDialog aboutBox;


/**
 * regarde tous les composants du panel.
 * Si ce sont des InsertionRuleButton, alors teste si la règle est applicable
 * si oui, le bouton est affiché, sinon, le bouton est invisible.
 * Si tous les boutons sont invisibles, le panel est rendu invisible
 * Sinon, le panel est visible
 * @param panel
 */
    private void panelInsertionRuleButtonMettreAJour(JPanel panel)
    {
        if(proofPanel.getSelectedNodes().size() == 0)
        {
            panel.setVisible(false);
        }
        else
        {
            boolean rempli = false;
            

            for(Component c : panel.getComponents())
            {
//                if(c instanceof InsertionRuleButtonOneNode)
//                {
//                    boolean b = ((InsertionRuleButtonOneNode) c).testIfRuleApplicable(proofPanel.getSelectedNode());
//                    c.setVisible(b);
//
//                    if(b)
//                        rempli = true;
//                }

                if(c instanceof InsertionRuleButton)
                {
                    boolean b = ((InsertionRuleButton) c).testIfRuleApplicable(proofPanel.getSelectedNodes());
                    c.setVisible(b);

                    if(b)
                        rempli = true;
                }
            }
            panel.setVisible(rempli);
        }
    }


/**
 * met la palette à jour en fonction de ce qui est sélectionné dans proofPanel
 */
    private void panPaletteMettreAJour() {
        panelInsertionRuleButtonMettreAJour(panInsertionRules);
        panelInsertionRuleButtonMettreAJour(panInsertionRulesBU);

        /**
         * ajoute les boutons personnalisés comme les I-> BU et Inot BU
         * (un bouton I->BU par hypothèse)
         */
        panInsertionRuleButtonsCustomized.removeAll();
        if(proofPanel.getSelectedNode() != null)
        {
            ProofFormulaNode n = proofPanel.getSelectedNode();
            if(n.getFormula().isBottom() & n.noFather())
            {
                for(Formula f : ((ProofFormulaNodeNatDet) n).getHypothesesPrincipalesArbre())
                   try {
                    panInsertionRuleButtonsCustomized.add(setup(new InsertionRuleIntroNotBU(f)));
                } catch (Exception ex) {
                    Logger.getLogger(MrnatureView.class.getName()).log(Level.SEVERE, null, ex);
                }
            }


            if(n.noFather())
            {
                for(Formula f : ((ProofFormulaNodeNatDet) n).getHypothesesPrincipalesArbre())
                   try {
                    panInsertionRuleButtonsCustomized.add(setup(new InsertionRuleIntroImplyBU(f)));
                } catch (Exception ex) {
                    Logger.getLogger(MrnatureView.class.getName()).log(Level.SEVERE, null, ex);
                }




                if(!((ProofFormulaNodeNatDet) n).getFormula().getFreeVariables().isEmpty())
                    try {
                    panInsertionRuleButtonsCustomized.add(setup(new InsertionRuleIntroExistsBU()));
                } catch (Exception ex) {
                    Logger.getLogger(MrnatureView.class.getName()).log(Level.SEVERE, null, ex);
                }

                for(String var : ((ProofFormulaNodeNatDet) n).getFormula().getFreeVariables())
                {
                    boolean varBonne = true;
//                    for(Formula hyp : ((ProofFormulaNodeNatDet) n).getHypothesesPrincipalesArbre())
//                    {
//                        if(hyp.isFreeVariable(var))
//                            varBonne = false;
//                    }

                    if(varBonne)
                    try {
                        panInsertionRuleButtonsCustomized.add(setup(new InsertionRuleIntroForallBU(var)));
                    } catch (Exception ex) {
                        Logger.getLogger(MrnatureView.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }



                

            }
            
        }

        /**
         * s'il y a des boutons affichés (du à des règles -> BU ou not BU) alors
         * le panel des règles BU est affiché
         */
        if(panInsertionRuleButtonsCustomized.getComponentCount() > 0)
            panInsertionRulesBU.setVisible(true);


        jScrollPaneInsertionRules.setVisible(proofPanel.getSelectedNodes().size() > 0);
        panAide.setVisible(proofPanel.getSelectedNodes().size() == 0);
        panInsertionRuleButtonsCustomized.doLayout();


    }

    private void addFormulaExample(JMenu menu, String string) {
        menu.add(setupMenuItemExample(new MenuItemExample(string)));
        
    }


    private void setMission(Mission mission) {
         
          this.mission = mission;

          if(mission == null)
          {
              panMission.setVisible(false);
          }
          else
          {
              panMission.setVisible(true);
              panMissionMettreAJour();
          }
    }



    private void panMissionMettreAJour() {
        if(mission != null)
        {
            ProofFormulaNode node = proofPanel.getProofNode(mission.getHypothesisFormulas(), mission.getGoalFormula());

            if(node != null)
            {
                lblMissionGagnee.setVisible(true);
            }
            else
            {
                lblMissionGagnee.setVisible(false);
            }
        }
        else
            lblMissionGagnee.setVisible(false);
         
    }

    private void cursorTravail()
    {
        getFrame().setCursor(new Cursor(Cursor.WAIT_CURSOR));
    }

    private void cursorRepos()
    {
        getFrame().setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }
}
