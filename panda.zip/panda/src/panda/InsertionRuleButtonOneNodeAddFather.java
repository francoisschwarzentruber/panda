/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
abstract class InsertionRuleButtonOneNodeAddFather extends InsertionRuleButtonOneNode {

    InsertionRuleButtonOneNodeAddFather(String codeLaTEX)
    {
        super(codeLaTEX);

    }



    abstract Formula getFormulaOfFather(ProofFormulaNodeNatDet node);



    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        ProofFormulaNodeNatDet father = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(),
                                                                   getFormulaOfFather(node));

        proofPanel.commandExecute(new CommandCreateFatherForNode(father, node));
        
        proofPanel.setNodeSelected(father);
    }
    

}
