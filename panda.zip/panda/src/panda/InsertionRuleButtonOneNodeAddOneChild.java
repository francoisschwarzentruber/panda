/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
abstract public class InsertionRuleButtonOneNodeAddOneChild extends InsertionRuleButtonOneNode {
    InsertionRuleButtonOneNodeAddOneChild(String codeLaTEX)
    {
        super(codeLaTEX);
        
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        ProofFormulaNodeNatDet child = new ProofFormulaNodeNatDet(null, getFormulaChild(node));


        proofPanel.commandExecute(
                new CommandNodeAddNewChild(node, child));


        proofPanel.setNodeSelected(child);
    }



    abstract Formula getFormulaChild(ProofFormulaNodeNatDet node);

}
