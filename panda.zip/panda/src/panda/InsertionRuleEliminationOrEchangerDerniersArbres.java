/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;



/**
 *
 * @author François Schwarzentruber
 */
public class InsertionRuleEliminationOrEchangerDerniersArbres extends InsertionRuleButtonOneNode {

    public InsertionRuleEliminationOrEchangerDerniersArbres() {
          super(getStringFromRessource("switchLastTrees"));
    }

    


    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.isRuleEliminationOr();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        proofPanel.commandExecute(new CommandSwitchTwoSubTrees(node, 1, 2));
    }
}
