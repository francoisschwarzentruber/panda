/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import javax.swing.JMenuItem;



/**
 *
 * @author François Schwarzentruber
 */
public class InsertionRuleIntroOrEchangerAB extends InsertionRuleButtonOneNode {

    public InsertionRuleIntroOrEchangerAB() {
          super("\\text{changer } A \\vee B \\text{ en } B \\vee A");
    }

    


    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.isRuleIntroOr();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        Formula A = node.getFormula().getSubFormulaLeft();
        Formula B = node.getFormula().getSubFormulaRight();
        proofPanel.commandExecute(new CommandNodeChangeFormula(node, new Formula("(" + B + " or " + A + ")")));
    }
}
