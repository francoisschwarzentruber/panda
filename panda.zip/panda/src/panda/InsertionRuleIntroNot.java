/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroNot extends InsertionRuleButtonOneNode {
    public InsertionRuleIntroNot() {
        super("\\frac{\\begin{array}{c}(i) \\\\ \\vdots \\\\ \\newnode{\\bot} \\end{array}}{\\selectednode{\\neg A}} (I \\neg) (i)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return (node.getFormula().isNot()) & node.noChildren();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        ProofFormulaNodeNatDet child = new ProofFormulaNodeNatDet(null, new Formula("bottom"));
        proofPanel.commandExecute(new CommandNodeAddNewChild(node, child));
        proofPanel.setNodeSelected(child);
        

    }

}
