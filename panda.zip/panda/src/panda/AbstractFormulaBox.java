/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */






/*
 * AbstractFormulaBox.java
 *
 * Created on 14 sept. 2010, 01:34:15
 * 
 */

package panda;

import java.util.HashSet;
import java.util.Set;




/**
 * représente un widget pour entrer une formule logique.
 * Ce composant se spécialise en FormulaBox et TermBox
 * 
 * @author François Schwarzentruber
 */
abstract public class AbstractFormulaBox extends javax.swing.JPanel {

    /**
     * vaut le FormulaBox qui détient le focus
     */
    private static AbstractFormulaBox focusOwnerformulaBox = null;


/**
 *
 * @return le formuleBox qui a le focus (où on écrit avec le clavier)
 */
    static AbstractFormulaBox getFocusOwnerFormulaBox()
    {
        return focusOwnerformulaBox;
    }


    /**
     *
     * @param formula
     * @return le code LaTEX correspondant à la formule
     * @throws Exception (l'analyse peut rater)
     */
    static public String formulaSchemeStringToLatexCode(String formula) throws Exception
    {
        return formulaSchemeToLatexCode(new Formula(formula));
    }



/**
     * 
     * @param formula
     * @return le code LaTEX qui représente la formule
     * @throws Exception 
     */
    abstract protected String textToLatexCode(Formula formula) throws Exception;


    /**
     *
     * @param formula
     * @return le code LaTEX correspondant à la formule
     * @throws Exception (l'analyse peut rater)
     */
    static public String formulaSchemeToLatexCode(Formula formula) throws Exception
    {
        if(formula.getSchemeString().startsWith("<"))
        {
            return "?";
        }
        else if(formula.getSchemeString().equals("top"))
            return "\\top";
        else
         if(formula.getSchemeString().equals("bottom"))
            return "\\bot";
        else
        if(!formula.getSchemeString().startsWith("("))
        {
            return predicatToLaTEX(formula);
        }
        else 
        
        if(formula.isNot())
        {
            return "\\neg " + formulaSchemeToLatexCode(formula.getSubFormulaForNot());
        }
        else
        if(formula.getSubPart(1).getSchemeString().equals("and"))
        {
            if(formula.getNbSubParts() % 2 == 0)
                throw new Exception("Il manque au moins une sous-formule dans cette conjonction");
            
            String s = "\\left(" + formulaSchemeToLatexCode(formula.getSubPart(0));

            for(int i = 1; i < formula.getNbSubParts(); i+=2)
            {
                if(!formula.getSubPart(i).toString().equals("and"))
                    throw new Exception("J'attends un 'and'");
                
                s += " \\wedge " + formulaSchemeToLatexCode(formula.getSubPart(i+1));
            }
            s += "\\right)";
            return s;
        }
        if(formula.getSubPart(1).getSchemeString().equals("or"))
        {
            if(formula.getNbSubParts() % 2 == 0)
                throw new Exception("Il manque au moins une sous-formule dans cette conjonction");

            String s = "\\left(" + formulaSchemeToLatexCode(formula.getSubPart(0));

            for(int i = 1; i < formula.getNbSubParts(); i+=2)
            {
                if(!formula.getSubPart(i).toString().equals("or"))
                    throw new Exception("J'attends un 'or'");

                s += " \\vee " + formulaSchemeToLatexCode(formula.getSubPart(i+1));
            }
            s += "\\right)";
            return s;
        }
        if(formula.getSubPart(1).getSchemeString().equals("imply"))
        {
            return "\\left(" + formulaSchemeToLatexCode(formula.getSubPart(0))
                    + " \\rightarrow " + formulaSchemeToLatexCode(formula.getSubPart(2)) + "\\right)";
        }
        if(formula.getSubPart(1).getSchemeString().equals("equiv"))
        {
            return "\\left(" + formulaSchemeToLatexCode(formula.getSubPart(0))
                    + " \\leftrightarrow " + formulaSchemeToLatexCode(formula.getSubPart(2)) + "\\right)";
        }
        if(formula.isForAll())
        {
            return "\\forall " + variableToLatexCode(formula.getQuantifierVariable()) + ". " +
                    formulaSchemeToLatexCode(formula.getQuantifierSubFormula());
        }
        else
        if(formula.isExists())
        {
            return "\\exists " + variableToLatexCode(formula.getQuantifierVariable()) + ". " +
                    formulaSchemeToLatexCode(formula.getQuantifierSubFormula());
        }
        else    //propositions
        {
            return predicatToLaTEX(formula);
        }


    }




    /**
     *
     * @param term
     * @return le code LaTEX correspondant au terme
     */
    protected static String termToLaTeX(Formula term)
    {
        final Set<String> functionsBinairesInfixes = new HashSet<String>();
        
        functionsBinairesInfixes.add("+");
        functionsBinairesInfixes.add("-");
        functionsBinairesInfixes.add("*");
        
        
        
        if(term.isAtomic())
        {
            return "{" + term.getSchemeString() + "}";
        }
        else if(term.getNbSubParts() == 1)
        {
            return term.getSchemeString();
        }
        else if(term.getFunctionName().equals("^"))
        {
            return "\\left(" + termToLaTeX(term.getSubPart(1)) + "\\right)" + " ^ " + termToLaTeX(term.getSubPart(2));
        }
        else if(term.getFunctionName().equals("/"))
        {
            return "\\frac{" + termToLaTeX(term.getSubPart(1)) + "}{" + termToLaTeX(term.getSubPart(2)) + "}";
        }
        else if(term.getFunctionName().equals("sqrt"))
        {
            return "\\sqrt{" + termToLaTeX(term.getSubPart(1)) + "}";
        }
        else if(functionsBinairesInfixes.contains(term.getFunctionName().getSchemeString()))
        {
            return "\\left(" + termToLaTeX(term.getSubPart(1)) + term.getFunctionName() + termToLaTeX(term.getSubPart(2)) + "\\right)";
        }
        else
        {
            String s = "";
            s += term.getSubPart(0);
            s += "(";
            s += termToLaTeX(term.getSubPart(1));

            for(int i = 2; i < term.getNbSubParts(); i++)
            {
                s += ", ";
                s += termToLaTeX(term.getSubPart(i));
            }


            s += ")";

            return s;
        }
    }


/**
 *
 * @param predicatName
 * @return le nom d'un prédicat en code LaTEX
 */
    public static String predicatSymbolToLaTEX(String predicatName)
    {
         return "\\mathbf{" + predicatName + "}";
    }



    /**
     *
     * @param predicat
     * @return un prédicat en code latex
     */
    private static String predicatToLaTEX(Formula predicat) {
        final Set<String> predicatsBinairesInfixes = new HashSet<String>();
        
        predicatsBinairesInfixes.add("=");
        predicatsBinairesInfixes.add("<");
        predicatsBinairesInfixes.add(">");
        predicatsBinairesInfixes.add("\\in");
        predicatsBinairesInfixes.add("\\subseteq");
        
        
        
        if(predicat.isAtomic())
        {
            return predicatSymbolToLaTEX(predicat.getSchemeString());
        }
        else if(predicat.getNbSubParts() == 1)
        {
            return predicat.getSchemeString();
        }
        else if(predicatsBinairesInfixes.contains(predicat.getPredicatName().getSchemeString()))
        {
            return "(" + termToLaTeX(predicat.getSubPart(1)) + predicat.getPredicatName() +  termToLaTeX(predicat.getSubPart(2)) + ")";
        }
        else
        {
            String s = "";
            s += predicatSymbolToLaTEX(predicat.getSubPart(0).getSchemeString());
            s += "(";
            s += termToLaTeX(predicat.getSubPart(1));

            for(int i = 2; i < predicat.getNbSubParts(); i++)
            {
                s += ", ";
                s += termToLaTeX(predicat.getSubPart(i));
            }


            s += ")";

            return s;
        }
            
    }


    /**
     *
     * @param var
     * @return latex code for var.
     */
    private static String variableToLatexCode(String var) {
        if(var.startsWith("<"))
        {
            return "?";
        }
        else
            return var;
    }




    /** Creates new form FormulaBox */
    public AbstractFormulaBox() {
        initComponents();
        lblError.setVisible(false);
        lblAffichage.setText("");


    }




    /**
     * à cause des bugs... pour que oui, le focus soit bien donner à txtFormula
     */
    @Override
    public void requestFocus() {
        super.requestFocus();
        txtFormula.requestFocus();
    }






    

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtFormula = new panda.SchemeFormulaTextField();
        lblError = new javax.swing.JLabel();
        lblAffichage = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setName("Form"); // NOI18N
        addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                formFocusGained(evt);
            }
        });
        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.Y_AXIS));

        txtFormula.setAlignmentX(0.0F);
        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(panda.MrnatureApp.class).getContext().getResourceMap(AbstractFormulaBox.class);
        txtFormula.setFont(resourceMap.getFont("txtFormula.font")); // NOI18N
        txtFormula.setMaximumSize(new java.awt.Dimension(2147483647, 28));
        txtFormula.setName("txtFormula"); // NOI18N
        txtFormula.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtFormulaMouseClicked(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                txtFormulaMouseReleased(evt);
            }
        });
        txtFormula.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtFormulaFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtFormulaFocusLost(evt);
            }
        });
        txtFormula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtFormulaKeyReleased(evt);
            }
        });
        add(txtFormula);

        lblError.setForeground(resourceMap.getColor("lblError.foreground")); // NOI18N
        lblError.setName("lblError"); // NOI18N
        add(lblError);

        lblAffichage.setName("lblAffichage"); // NOI18N
        lblAffichage.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblAffichageMouseClicked(evt);
            }
        });
        add(lblAffichage);

        jLabel1.setMaximumSize(new java.awt.Dimension(33, 22));
        jLabel1.setMinimumSize(new java.awt.Dimension(33, 22));
        jLabel1.setName("jLabel1"); // NOI18N
        jLabel1.setPreferredSize(new java.awt.Dimension(33, 22));
        add(jLabel1);
    }// </editor-fold>//GEN-END:initComponents

    private void txtFormulaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtFormulaKeyReleased
        txtFormula.doRepaint();
        mettreAJourAffichageLatex();
    }//GEN-LAST:event_txtFormulaKeyReleased

    private void txtFormulaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtFormulaMouseClicked
        txtFormula.doRepaint();
        mettreAJourAffichageLatex();
    }//GEN-LAST:event_txtFormulaMouseClicked

    private void lblAffichageMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblAffichageMouseClicked
        System.out.println(getFormula().getSchemeString());
    }//GEN-LAST:event_lblAffichageMouseClicked

    private void txtFormulaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtFormulaFocusLost
        txtFormula.repaint();
    }//GEN-LAST:event_txtFormulaFocusLost

    private void formFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_formFocusGained
        focusOwnerformulaBox = this;
    }//GEN-LAST:event_formFocusGained

    private void txtFormulaFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtFormulaFocusGained
        focusOwnerformulaBox = this;
    }//GEN-LAST:event_txtFormulaFocusGained

    private void txtFormulaMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtFormulaMouseReleased
        txtFormula.doRepaint();
    }//GEN-LAST:event_txtFormulaMouseReleased



/**
 *
 * @return le première champ à sélectionner et à remplacer.
     * renvoie null si un tel champ n'existe pas
 * Exemple : "<agt>" etc.
 */
    private String premierChampACompleter()
    {
        String s = getText();

        int a = s.indexOf("<");

        if(a < 0)
            return null;


        int b = s.indexOf(">", a);

        return s.substring(a, b+1);
    }
    /**
     *
     * @return renvoie l'indice dans le texte où il y a un problème de parenthèse fermante en trop
     * si renvoie -2 c'est qu'on conditionText'appercoit à la fin qu'il y a trop de parenthèse ouverte
     * si renvoie -1 alors c'est bon.
     *
     */
    private int indiceAvecErreurParenthese()
    {
        String s = getText();

        int compteur = 0;
        for(int i = 0; i < s.length(); i++)
        {
            if(s.charAt(i) == '(')
                compteur += 1;

            if(s.charAt(i) == ')')
                compteur -= 1;

            if(compteur < 0)
                return i;
        }

        if(compteur > 0)
            return -2;
        
        return -1;
    }



    /**
     * met à jour l'affichage LaTEX.
     * En cas d'erreur, affiche un message d'erreur
     */
    private void mettreAJourAffichageLatex()
    {
        lblError.setVisible(false);
        txtFormula.noError();
        lblAffichage.setText("");

        int i = indiceAvecErreurParenthese();
        if(i >= 0)
        {
            afficherMessageErreur("parenthèse fermante en trop au caractère n°" + i);
            txtFormula.error(i);
            return;
        }
        else if (i == -2)
        {
            afficherMessageErreur("parenthèse ouvrante en trop mais je ne sais pas où");
            return;
        }



        String s = premierChampACompleter();

        if(s != null)
        {
            afficherMessageConseil("Remplace " + s + " par quelquechose !");
        }
        
        try
        {
            if(!txtFormula.getText().isEmpty())
            {
                Formula formula = (new Formula("(" + txtFormula.getText() + ")"));

                 if(formula.getNbSubParts() > 1)
                 {
                     txtFormula.errorAll();
                     throw new Exception("Tu dois mettre des parenthèses autour tout ça ! Là, je lis '"
                              + formula.getSubPart(0).toString() + "' puis '"
                              + formula.getSubPart(1).toString() + "' et je ne comprends pas");
                 }
                 lblAffichage.setIcon(LaTEX.latexCodeToImageIcon(textToLatexCode(formula.getSubPart(0))));
                 lblAffichage.setVisible(true);
            }
            else
            {
                lblAffichage.setIcon(null);
            }
        }
        catch(Exception e)
        {
            afficherMessageErreur(e.getMessage());

        }
        
    }



/**
 *
 * @return true ssi la formule écrite est correcte (pas d'erreurs de syntaxe)
 */
    public boolean isOK()
    {
        return !txtFormula.getText().isEmpty() & !lblError.isVisible();
    }

/**
 * affiche le message d'erreur pour signaler, souvent, une erreur de syntaxe
 * @param s
 */
    private void afficherMessageErreur(String s)
    {
        lblAffichage.setVisible(false);
        lblError.setVisible(true);
        lblError.setText("Error: " + s);
    }


    /**
     * affiche un conseil
     * @param s
     */
    private void afficherMessageConseil(String s)
    {
        lblError.setVisible(true);
        lblError.setText("Conseil : " + s);
    }

    /**
     *
     * @return le texte écrit par l'utilisateur
     */
    public String getText()
    {
        return txtFormula.getText();
    }



    /**
     *
     * @return la formule (expandée)
     *         null si le champ est vide
     */
    public Formula getFormula()
    {
        if(getText().isEmpty())
            return null;
        else
            return new Formula(getText());
    }

    


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel lblAffichage;
    private javax.swing.JLabel lblError;
    private panda.SchemeFormulaTextField txtFormula;
    // End of variables declaration//GEN-END:variables

    
    
    /**
     * define the formula inside the formulaBox
     * @param formulaSchemeCode 
     */
    public void setText(String formulaSchemeCode) {
        txtFormula.setText(formulaSchemeCode);
        mettreAJourAffichageLatex();
    }




    /**
     * insère le texte à la position du curseur courant
     * @param texte
     */
    public void insert(String texte) {
        txtFormula.replaceSelection(texte);
        mettreAJourAffichageLatex();
    }

    @Override
    public boolean isFocusOwner() {
        return super.isFocusOwner() || txtFormula.isFocusOwner();
    }

    
    /**
     * 
     * @return true iff the text of the formulaBox is empty
     */
    public boolean isEmpty() {
        return getText().isEmpty();
    }

/**
     * Sélectionne le texte
     */
    void selectAll() {
           txtFormula.selectAll();
    }


}
