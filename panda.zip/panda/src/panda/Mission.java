/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.Set;
import javax.swing.Icon;

/**
 * A mission represents a goal to prove. There are a set of hypothesis and
 * a goalFormula.
 * @author Ancmin
 */
public class Mission {

    private final Set<Formula>  hypothesisFormulas;
    private final Formula goalFormula;


    public Mission(Set<Formula> hypothesisFormulas, Formula goalFormula) {
        this.hypothesisFormulas = hypothesisFormulas;
        this.goalFormula = goalFormula;
    }

    public Set<Formula> getHypothesisFormulas() {
        return hypothesisFormulas;
    }

    public Formula getGoalFormula() {
        return goalFormula;
    }


    public Icon getIcon()
    {
        String latexCode = "";
        for(Formula phi : hypothesisFormulas)
        {
            if(latexCode.length() > 0)
                latexCode += ", ";
            latexCode += phi.getLaTEXCode();
        }

        latexCode += "\\colorbox{white}{\\vdash}";

        latexCode += goalFormula.getLaTEXCode();

        return LaTEX.latexCodeToImageIcon(latexCode);
    }

}
