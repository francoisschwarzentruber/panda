/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroImply extends InsertionRuleButtonOneNodeAddOneChild {
    public InsertionRuleIntroImply() {
        super("\\frac{\\newnode{B}}{\\selectednode{A \\rightarrow B}} (I \\rightarrow) (i)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.getFormula().isImply() & node.noChildren();
    }

    @Override
    Formula getFormulaChild(ProofFormulaNodeNatDet node) {
        return node.getFormula().getSubFormulaRight();
    }


}
