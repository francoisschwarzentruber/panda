/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.HashSet;
import java.util.Set;
import javax.swing.Icon;
import javax.swing.JMenuItem;



/**
 * This class represents a menu item for an example of a goalFormula to prove.
 * @author François Schwarzentruber
 */
public class MenuItemExample extends JMenuItem {

    private final Formula goalFormula;
    private final Set<Formula> hypothesisFormulas;



    public Set<Formula> getHypothesisFormulas()
    {
        return hypothesisFormulas;
    }

    public Formula getGoalFormula() {
        return goalFormula;
    }


    static String schemeFormulaToLaTEXCode(String schemeFormula)
    {
        try {
            return FormulaBox.formulaSchemeStringToLatexCode(schemeFormula);
        } catch (Exception ex) {
            return null;
        }
    }

   static Icon schemeFormulaToIcon(String schemeFormula)
   {
       return LaTEX.latexCodeToImageIcon(schemeFormulaToLaTEXCode(schemeFormula));
   }





   private void setupIcon()
   {
       setIcon((new Mission(hypothesisFormulas, goalFormula)).getIcon());

   }

   /**
    * the creation is standard : the menu item shows a LaTEX rendering
    * @param schemeFormula
    */
    MenuItemExample(String schemeFormula)
    {
        super();
        goalFormula = new Formula(schemeFormula);
        hypothesisFormulas = new HashSet<Formula>();

        setupIcon();
        
    }


    /**
    * the creation is standard : the menu item shows a LaTEX rendering
    * @param schemeFormula
    */
    MenuItemExample(String hyp1, String hyp2, String schemeFormula)
    {
        super();
        goalFormula = new Formula(schemeFormula);
        hypothesisFormulas = new HashSet<Formula>();
        hypothesisFormulas.add(new Formula(hyp1));
        hypothesisFormulas.add(new Formula(hyp2));
        setupIcon();

    }


    /**
    * the creation is standard : the menu item shows a LaTEX rendering
    * @param schemeFormula
    */
    MenuItemExample(String hyp1, String hyp2, String hyp3, String schemeFormula)
    {
        super();
        goalFormula = new Formula(schemeFormula);
        hypothesisFormulas = new HashSet<Formula>();
        hypothesisFormulas.add(new Formula(hyp1));
        hypothesisFormulas.add(new Formula(hyp2));
        hypothesisFormulas.add(new Formula(hyp3));
        setupIcon();

    }



    /**
    * the creation is standard : the menu item shows a LaTEX rendering
    * @param schemeFormula
    */
    MenuItemExample(String hyp1, String schemeFormula)
    {
        super();
        goalFormula = new Formula(schemeFormula);
        hypothesisFormulas = new HashSet<Formula>();
        hypothesisFormulas.add(new Formula(hyp1));
        setupIcon();

    }


}
