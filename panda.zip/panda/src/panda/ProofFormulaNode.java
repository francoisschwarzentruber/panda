/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import org.jdom.Element;

/**
 * represents a node in a proof.
 * This class is about basic drawing of such a node etc.
 * This class is abstract because it can be used for other type of deduction
 * than natural deduction.
 * @author Ancmin
 */
abstract public class ProofFormulaNode {

    /**
     * the formula
     */
    private Formula formula;


    /**
     * the image representing the formula (rendered by LaTEX)
     */
    private Icon iconFormulaLaTEX;

    /**
     * the point of where the point on the middle-top should be
     * (when the animation is over)
     */
    private Point pointMilieuHaut;

    /**
     * a pointer of the father of this node
     */
    private ProofFormulaNode father = null;

    /**
     * pointers of children
     */
    protected ArrayList<ProofFormulaNode> children = new ArrayList<ProofFormulaNode>();

/**
 * extra-space between two nodes
 */
    private final int ecartChildrenNodes = 48;


    /**
     * number of steps in the animation
     */
    static private final int animIndiceMax = 8;

    /**
     * current step in the animation
     */
    private int animIndice = 0;

    /**
     * point at the beginning of the animation
     */
    private Point avantPointMilieuHaut;


    /**
     * true iff the tree is hidden
     */
    private boolean treeHidden = false;


    /**
     * image of a "real" tree to represent a hidden tree
     */
    private ImageIcon imgTree = new ImageIcon(this.getClass().getResource("resources/arbre.png"));


/**
 *
 * @return true iff the animation is not over
 */
    public boolean isAnimated()
    {
        return animIndice > 0;
    }


/**
 * should be called to animate the node (if there is an animation to do...
 * that is to say call isAnimated() )
 */
    public void animate()
    {
        if(isAnimated())
             animIndice--;
    }


    /**
     * constructor of a node
     * pointMilieuHaut = the point middle-top of the rectangle of the formula
     * formula = the formula inside the node
     * @param pointMilieuHaut
     * @param formula
     */
    ProofFormulaNode(Point pointMilieuHaut, Formula formula)
    {
        if(pointMilieuHaut == null)
        {
            this.pointMilieuHaut = null;
            this.avantPointMilieuHaut = null;
        }
        else
        {
            this.pointMilieuHaut = pointMilieuHaut;
            this.avantPointMilieuHaut = new Point( pointMilieuHaut.x, pointMilieuHaut.y);
        }
        
        setFormula(formula);
        
    }


    /**
     *
     * @param point
     * @return true if the point p is in the rectangle of the formula
     */
    public boolean isOverFormula(Point point)
    {
        return getRectangleFormula().contains(point);
    }

    public Formula getFormula() {
        return formula;
    }


    /**
     *
     * @return the rectangle where the formula is written
     */
    public Rectangle getRectangleFormula()
    {
        return new Rectangle(getPointMilieuHautAnimation().x - iconFormulaLaTEX.getIconWidth() / 2,
                             getPointMilieuHautAnimation().y,
                             iconFormulaLaTEX.getIconWidth(),
                             iconFormulaLaTEX.getIconHeight() );
    }


   
/**
 *
 * @return where the point middle-top should be (at the end of the animation)
 */
    public Point getPointMilieuHaut() {
       return pointMilieuHaut;
    }

/**
 *
 * @return where the point middle-bottom should be (at the end of the animation)
 */
    public Point getPointMilieuBas() {
      return new Point(pointMilieuHaut.x, pointMilieuHaut.y + iconFormulaLaTEX.getIconHeight());
    }

/**
 * déplace le noeud directement (sans aucune animation)
 * @param p
 */
    public void setPointMilieuHautImmediat(Point p) {
        this.avantPointMilieuHaut = new Point(p.x, p.y);
        this.pointMilieuHaut = new Point(p.x, p.y);
        animIndice = 0;
    }

    /**
     * déplace le noeud (il y aura une animation)
     * @param p
     */
    public void setPointMilieuHaut(Point p) {
        if(pointMilieuHaut == null)
        {
            animIndice = 0;
            this.avantPointMilieuHaut = new Point(p.x, p.y);
        }
        else
        {
            this.avantPointMilieuHaut = getPointMilieuHautAnimation();
            if(this.avantPointMilieuHaut.distanceSq(p) == 0)
                animIndice = 0;
            else
                animIndice = animIndiceMax;
        }
        this.pointMilieuHaut = p;
        positionsCompute();
    }


    /**
     * set the formula written in the node
     * @param formula
     */
    public void setFormula(Formula formula) {
        this.formula = formula;
        try {
            this.iconFormulaLaTEX = LaTEX.latexCodeToImageIcon(getFormulaLaTEXCode());
        } catch (Exception ex) {
            Logger.getLogger(ProofFormulaNode.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    /**
     * define father to be the father of the current node
     * @param node
     */
    public void setFather(ProofFormulaNode father)
    {
        this.father = father;
    }
    

    /**
     * add node as a child of this node
     * @param node
     */
    public void addChild(ProofFormulaNode node)
    {
        if(!children.contains(node))
        {
            if(node.getFather() != null)
                node.getFather().removeChild(node);
            
            children.add(node);
            node.setFather(this);
            
        }
    }


    /**
     *
     * @return la longueur du trait du noeud
     * (prend en compte les fils de manière récursives)
     */
    public int getWidth()
    {
        int widthSum = 0;
        
        if(!isTreeHidden())
        {
            for(ProofFormulaNode node : children)
                widthSum += node.getWidth() + ecartChildrenNodes;

            widthSum -= ecartChildrenNodes;
        }

        if(widthSum < iconFormulaLaTEX.getIconWidth())
            return (int) iconFormulaLaTEX.getIconWidth();
        else
            return widthSum;
    }



    /**
     *
     * @param child
     * @return vrai ssi
     * le noeud courant est bien positionné pour être le père de child
     */
    boolean askToBeFatherOf(ProofFormulaNode child)
    {
        if(getRectangleTrait().intersects(child.getRectangleFormulaBas()))
            return true;
        else
            return false;
    }


    /**
     *
     * @return a rectangle to a zone in the bottom of the formula (used to detect colision making connection
     * between one node and a child)
     */
    public Rectangle getRectangleFormulaBas()
    {
        return new Rectangle(getXMilieu() - getFormulaWidth() / 2, getYBottom() - 2, getFormulaWidth(), 4);
    }
    

    /**
     *
     * @return a rectangle represented the zone where there is the upper line of proof
     */
    public Rectangle getRectangleTrait() {
        return new Rectangle(pointMilieuHaut.x - getWidth() / 2, pointMilieuHaut.y - 3, getWidth(), 6);
    }



/**
 * computes recursively the position of all children of the current node
 */
    public void positionsCompute()
    {
        if(children.size() == 1)
        {
            ProofFormulaNode child = children.get(0);
            child.setPointMilieuBas(new Point(getXMilieu(), getYFormulaTop()));
        }
        else
        {


            int x = getXLeft();
            for(ProofFormulaNode child : children)
            {
                child.setPointMilieuBas(new Point(x + child.getWidth() / 2, getYFormulaTop()));
                x += child.getWidth() + ecartChildrenNodes;
            }
        }
    }



    public int getXLeft() {
        return pointMilieuHaut.x - getWidth() / 2;
    }

    public int getXRight() {
        return pointMilieuHaut.x + getWidth() / 2;
    }

    private void setPointMilieuBas(Point point) {
        setPointMilieuHaut(new Point(point.x , point.y - iconFormulaLaTEX.getIconHeight()));
    }

    public int getYFormulaTop() {
        return pointMilieuHaut.y;
    }


    /**
     *
     * @return the father of the node (that is to say the node which is on the bottom
     * of this node) (if it exists) (if not, returns null)
     */
    public ProofFormulaNode getFather() {
        return father;
    }

    public ArrayList<ProofFormulaNode> getChildren() {
        return children;
    }

    
    /**
     * ajoute tous les enfants et les petits-enfants  et récursivement les
     * petit petit enfants etc. à l'ensemble nodes
     * @param nodes
     */
    public void addChildrenAndGrandChildrenEtc(Set<ProofFormulaNode> nodes)
    {
        nodes.addAll(children);
        for(ProofFormulaNode node : children)
        {
            node.addChildrenAndGrandChildrenEtc(nodes);
        }
    }
    

/**
 *
 * @return l'ensemble des enfants, et récursivement les petits-enfants etc.
 */
    public Set<ProofFormulaNode> getChildrenAndGrandChildrenEtc()
    {
        Set<ProofFormulaNode> nodes = new HashSet<ProofFormulaNode>();
        addChildrenAndGrandChildrenEtc(nodes);
        return nodes;
    }
    

    public void deconnectFromFather()
    {
        if(getFather() != null)
        {
            getFather().removeChild(this);
            setFather(null);

        }
    }



/**
 * déconnecte tous les fils de ce noeud
 * déconnecte aussi ce noeud du père
 */
    public void deconnectFromAll()
    {
        deconnectFromFather();

/*ici, je n'appelle pas children.remove(child) pour des raisons de trucs
 * Java bizarre.. ça marche pas avec la boucle for
 * Donc je fais tout simplement children.clear(); à la fin !
 */
        for(ProofFormulaNode child : children)
        {
            child.setFather(null);
        }
        
        children.clear();
    }



/**
 * supprime un noeud de la liste des fils
 * par ailleurs indique que ce noeud n'a plus de père
 * recalcule aussi les positions de tous les noeuds de l'arbre auquel
 * ce noeud appartient
 * @param currentNode
 */
    public void removeChild(ProofFormulaNode currentNode) {
        while(children.contains(currentNode))
              children.remove(currentNode);
        currentNode.setFather(null);
        getAncestor().positionsCompute();
    }


    /**
     * dessine un trait de preuve en grosse épaisseur (ça correspond au trait qui est AU DESSUS
     * de la formule de ce noeud)
     * (les fils d'un noeud étant au dessus)
     * (utilisée par l'interface quand on connecte deux noeuds ensemble)
     * @param g
     */
    public void drawTraitGros(Graphics g) {
        g.setColor(Color.BLUE);
        ((Graphics2D) g).setStroke(new BasicStroke(3.0f));
        drawTrait(g);
        
    }


    /**
     * dessine le trait de preuve (ça correspond au trait qui est AU DESSUS
     * de la formule de ce noeud)
     * (les fils d'un noeud étant au dessus)
     * @param g
     */
    protected void drawTrait(Graphics g) {
        
        g.drawLine(pointMilieuHaut.x - getWidth() / 2, pointMilieuHaut.y,
                   pointMilieuHaut.x + getWidth() / 2, pointMilieuHaut.y);
    }


/**
 *
 * @return le point en haut au milieu (c'est à dire le point en haut au milieu de la formule)
 * en cours d'animation
 * C'est à dire... ce n'est pas le point qu'on a défini avec setPointMilieuHaut mais
 * le point réellement affiché par l'animation
 */
    private Point getPointMilieuHautAnimation()
    {
        float lambda = ((float) animIndice) / ((float) animIndiceMax);
        int x = Math.round(avantPointMilieuHaut.x * lambda + pointMilieuHaut.x * ( 1 - lambda));
        int y = Math.round(avantPointMilieuHaut.y * lambda + pointMilieuHaut.y * ( 1 - lambda));
        return new Point(x, y);
    }


    /**
     * affiche le noeud et que le noeud (pas l'arbre de preuve du noeud qui est au dessus)
     * @param g
     */
     public void drawNode(Graphics g) {
        int x = getPointMilieuHautAnimation().x;
        int y = getPointMilieuHautAnimation().y;
//        if(isAnimated())
//           g.drawRect(x, y, 100, 10);

        iconFormulaLaTEX.paintIcon(null, g, x - iconFormulaLaTEX.getIconWidth() / 2, y);
        ((Graphics2D) g).setStroke(new BasicStroke(1.0f));
        if(getNbChildren() > 0)
             drawTrait(g);
    }



/**
 * affiche le noeud et son arbre de preuve SAUF si l'arbre est caché
 */
    public void drawNodeAndTree(Graphics g)
    {
        drawNode(g);

        if(isTreeHidden() & hasChildren())
        {   int w = 100;
            int h = 100;
            g.drawImage(imgTree.getImage(), getXMilieu() - w / 2, getYFormulaTop() - h, w, h, null);
        }
        else
        {
            for(ProofFormulaNode node : children)
            {
                node.drawNodeAndTree(g);
            }
        }
    }



    /**
     * Dessine un mini-cadre pour dire que ce noeud est sous la souris
     * @param g
     */
    void drawAsCurrent(Graphics g) {
        g.setColor(new Color(0.5f, 0.5f, 0.5f));
        g.drawRoundRect(getRectangleFormula().x, getRectangleFormula().y,
                   getRectangleFormula().width, getRectangleFormula().height, 5, 5);
        g.setColor(Color.BLACK);
        drawNode(g);
    }





    public void drawAsSelected(Graphics g) {
        drawNode(g);

        float f[] = {0.5f, 0.5f};
        g.setColor(new Color(1.0f, 0.8f, 0.8f));
        ((Graphics2D) g)
                .setStroke(new BasicStroke(
                                           1.0f,
                                           BasicStroke.CAP_BUTT,
                                           BasicStroke.JOIN_MITER,
                                           1.0f,
                                           f,
                                            0.0f));
        
        fillPolygon(g);
        g.setColor(new Color(1.0f, 0.3f, 0.3f));
        ((Graphics2D) g).setStroke(new BasicStroke(3.0f));
        g.drawRoundRect(getRectangleFormula().x-2, getRectangleFormula().y-2,
                   getRectangleFormula().width+4, getRectangleFormula().height+4, 5, 5);
        
        g.setColor(Color.BLACK);
        
    }



    public int getNbChildren()
    {
        return children.size();
    }


    public ProofFormulaNode getChild(int i)
    {
        return children.get(i);
    }


    /**
     * dans le cas où il n'y a que deux fils, ça les échange !
     */
    protected void echangerChildren2() {
        ProofFormulaNode child1 = getChild(0);
        ProofFormulaNode child0 = getChild(1);

        children.set(0, child0);
        children.set(1, child1);
    }


    public boolean hasFather() {
        return getFather() != null;
    }


    public boolean noChildren() {
        return getNbChildren() == 0;
    }

    public boolean noFather() {
        return getFather() == null;
    }

    public int getYBottom() {
        return pointMilieuHaut.y + iconFormulaLaTEX.getIconHeight();
    }

    public int getXMilieu() {
        return pointMilieuHaut.x;
    }


    public void addChildren(ArrayList<ProofFormulaNode> futureChildren) {
        for(ProofFormulaNode child : futureChildren)
        {
            addChild(child);
        }
    }



/**
 *
 * @return le polygone (rose) qui contourne toute la preuve
 */
    public ArrayList<Point> getPolygon()
    {
        ArrayList<Point> pts = new ArrayList<Point>();

        
        pts.add(new Point(getXLeft(), getYFormulaTop()));


        if(isTreeHidden())
        {
            pts.add(new Point(getXMilieu(), getYFormulaTop() - 100));
            
        }
        else
        {
            for(ProofFormulaNode child : children)
                pts.addAll(child.getPolygon());
        }
        
        pts.add(new Point(getXRight(), getYFormulaTop()));

        return pts;
    }



    private void fillPolygon(Graphics g)
    {
        ArrayList<Point> pts = getPolygon();

        pts.add(new Point(getXRightFormula(), getYBottom()));
        pts.add(new Point(getXLeftFormula(), getYBottom()));


        int[] xPoints = new int[pts.size()];
        int[] yPoints = new int[pts.size()];

        for(int i = 0; i < pts.size(); i++)
        {
            xPoints[i] = pts.get(i).x;
            yPoints[i] = pts.get(i).y;
        }

        g.fillPolygon(xPoints, yPoints, pts.size());
    }


    private int getXLeftFormula() {
        return getXMilieu() - getFormulaWidth() / 2;
    }

    private int getXRightFormula() {
        return getXMilieu() + getFormulaWidth() / 2;
    }



    /**
     * échange les fils d'index i et j
     * @param i
     * @param j
     */
    public void echangerChildren2(int i, int j) {
        ProofFormulaNode jNode = getChild(j);
        children.set(j, getChild(i));
        children.set(i, jNode);
        positionsCompute();
    }

    private int getFormulaWidth() {
        return iconFormulaLaTEX.getIconWidth();
    }


    /**
     *
     * @return the oldest ancestor in the proof tree
     */
    private ProofFormulaNode getAncestor() {
        if(noFather())
            return this;
        else
            return getFather().getAncestor();
    }



/**
 * retourne le code LaTEX de la formule du noeud
 * @return
 */
    public String getFormulaLaTEXCode()
    {
        try {
            return FormulaBox.formulaSchemeToLatexCode(formula);
        } catch (Exception ex) {
            Logger.getLogger(ProofFormulaNode.class.getName()).log(Level.SEVERE, null, ex);
             return null;
        }
    }


    /**
     * 
     * @return le code LaTEX de l'arbre dont ce noeud est racine
     */
    public String getLaTEXCodeArbre()
    {
        if(noChildren())
        {
            return getFormulaLaTEXCode();
        }
        else
        {
            String s = "";

            for(ProofFormulaNode node : getChildren())
            {
                s += node.getLaTEXCodeArbre() + "\\hspace{5mm}";
            }
            s +=  "\\hspace{-5mm}";
            return "\\frac{" + s + "}{" + getFormulaLaTEXCode() + "}";
        }
    }


    /**
     * déplace ce noeud de dx en abscisse et dy en ordonnée
     * @param dx
     * @param dy
     */
    public void translate(int dx, int dy) {
        pointMilieuHaut.x += dx;
        pointMilieuHaut.y += dy;

        if(avantPointMilieuHaut != pointMilieuHaut)
        {
            avantPointMilieuHaut.x += dx;
            avantPointMilieuHaut.y += dy;
        }
        
        for(ProofFormulaNode child : children)
        {
            child.translate(dx, dy);
        }
    }


    /**
     *
     * @return the height in pixel of the rectangle where the formula is written
     */
    public int getFormulaRectangleHeight() {
        return iconFormulaLaTEX.getIconHeight();
    }


    /**
     *
     * @return vrai ssi l'arbre est caché
     */
    public boolean isTreeHidden() {
        return treeHidden;
    }



    /**
     * affiche TOUT l'arbre de preuve
     */
    void treeShowAll() {
        treeHidden = false;

        for(ProofFormulaNode node : children)
        {
            node.treeShowAll();
        }
    }


    /**
     * cache l'arbre
     */
    public void treeHide() {
        treeHidden = true;

        for(ProofFormulaNode node : children)
        {
            node.treeHide();
        }
    }


    /**
     *
     * @return true iff the node has some child
     */
    private boolean hasChildren() {
        return !children.isEmpty();
    }

    

    public Element saveRecursive()
    {
        Element element = new Element("proofnode");
        Element elementFormula = new Element("formula");
        elementFormula.setText(getFormula().getSchemeString());

        Element elementPosition = new Element("graphicalposition");
        Element elementPositionX = new Element("x");
        Element elementPositionY = new Element("y");

        elementPositionX.setText(String.valueOf(getPointMilieuHaut().x));
        elementPositionY.setText(String.valueOf(getPointMilieuHaut().y));

        elementPosition.addContent(elementPositionX);
        elementPosition.addContent(elementPositionY);

        
        Element elementChildren = new Element("children");

        for(ProofFormulaNode child : getChildren())
        {
            elementChildren.addContent(child.saveRecursive());
        }

        
        element.addContent(elementFormula);
        element.addContent(elementPosition);
        element.addContent(elementChildren);
        
        return element;
    }
}
