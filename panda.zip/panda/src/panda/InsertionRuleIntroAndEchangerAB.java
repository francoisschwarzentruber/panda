/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import javax.swing.JMenuItem;



/**
 *
 * @author François Schwarzentruber
 */
public class InsertionRuleIntroAndEchangerAB extends InsertionRuleButtonOneNode {

    public InsertionRuleIntroAndEchangerAB() {
          super(getStringFromRessource("switchAandBtoBandA"));
    }

    


    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.isRuleIntroAnd();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        Formula A = node.getFormula().getSubFormulaLeft();
        Formula B = node.getFormula().getSubFormulaRight();
        proofPanel.commandExecute(new CommandNodeChangeFormula(node, new Formula("(" + B + " and " + A + ")")));
    }
}
