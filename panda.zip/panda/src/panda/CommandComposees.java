/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 * Commande composée d'une séquence de commandes
 * @author Ancmin
 */
public class CommandComposees implements Command {

    private ArrayList<Command> commands = new ArrayList<Command>();


/**
 * ajoute une commande à la séquence de commandes déjà présentes
 * @param action
 */
    public void commandAdd(Command action)
    {
        commands.add(action);
    }

    public void execute(ProofPanel partitionDonnees) {
        for(int i = 0; i < commands.size(); i++)
        {
            commands.get(i).execute(partitionDonnees);
        }
    }

    public void undo(ProofPanel partitionDonnees) {
        for(int i = commands.size() - 1; i >= 0 ; i--)
        {
            commands.get(i).undo(partitionDonnees);
        }
    }




}
