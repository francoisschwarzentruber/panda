/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * ProofPanel.java
 *
 * Created on 16 oct. 2010, 00:30:55
 */

package panda;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;


public class ProofPanelWithHint extends ProofPanel {

    private ArrayList<ProofFormulaNode> hintsHypothesesDechargees = new ArrayList<ProofFormulaNode>();
    private ArrayList<ProofFormulaNode> hintsTD = new ArrayList<ProofFormulaNode>();
    private ArrayList<ProofFormulaNode> hintsBU = new ArrayList<ProofFormulaNode>();

    
    public ProofPanelWithHint() {
        ArrayList<MouseListener> A = new ArrayList<MouseListener>();
        for(int i = 0; i < getMouseListeners().length; i++)
        {
            A.add(getMouseListeners()[i]);
        }

         for(MouseListener m : A)
         {
              removeMouseListener(m);
         }

       

        addMouseListener(new MouseListener() {

            public void mouseClicked(MouseEvent e) {
                
            }

            public void mousePressed(MouseEvent e) {
               ProofFormulaNode selectedNode = getSelectedNode();
               for(ProofFormulaNode node : hintsBU)
                    if(node.isOverFormula(e.getPoint()))
                    {
                        commandExecute(new CommandCreateFatherForNode(node, getSelectedNode()));
                        setNodeSelected(node);
                    }
               for(ProofFormulaNode node : hintsTD)
                    if(node.isOverFormula(e.getPoint()))
                    {
                        commandExecute(new CommandNodeAddNewChild(getSelectedNode(), node));

                        //setNodeSelected(node);
                    }
               for(ProofFormulaNode node : hintsHypothesesDechargees)
                    if(node.isOverFormula(e.getPoint()))
                    {
                        commandExecute(new CommandAddNode(node));
                        setNodeSelected(selectedNode);
                    }
               selectionChange();
            }

            public void mouseReleased(MouseEvent e) {
            //    throw new UnsupportedOperationException("Not supported yet.");
            }

            public void mouseEntered(MouseEvent e) {
            //    throw new UnsupportedOperationException("Not supported yet.");
            }

            public void mouseExited(MouseEvent e) {
              //  throw new UnsupportedOperationException("Not supported yet.");
            }
        });



        addMouseMotionListener(new MouseMotionListener() {

            public void mouseDragged(MouseEvent e) {
                calculerHints();
            }

            public void mouseMoved(MouseEvent e) {

            }
        });

        for(MouseListener m : A)
         {
              addMouseListener(m);
         }
        
        
        zoomMouseListenerAdapt();
    }


    


    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);


        drawTransparent((Graphics2D) g);

        for(ProofFormulaNode node : hintsBU)
        {
            node.drawNode(g);
        }

        for(ProofFormulaNode node : hintsTD)
        {
            node.drawNode(g);
        }

        for(ProofFormulaNode node : hintsHypothesesDechargees)
        {
            node.drawNode(g);
            ((Graphics2D) g).setStroke(new BasicStroke(3.0f));

            for(int y = node.getYBottom(); y < node.getYBottom()+32; y+=8)
                g.drawLine(node.getXMilieu(), y, node.getXMilieu(), y+4);
            
        }
    }



    private void calculerHints()
    {
        hintsBU.clear();
        hintsTD.clear();
        hintsHypothesesDechargees.clear();

        ProofFormulaNodeNatDet node = getSelectedNode();


        if(node != null)
        {
            if(node.getFormula().isImply() & node.noChildren())
                  hintsTD.add(new ProofFormulaNodeNatDet(new Point(node.getXMilieu(),
                               node.getYFormulaTop() - node.getFormulaRectangleHeight()-10), node.getFormula().getSubFormulaRight()));


            if(node.getFormula().isNot() & node.noChildren())
                  hintsTD.add(new ProofFormulaNodeNatDet(new Point(node.getXMilieu(),
                               node.getYFormulaTop() - node.getFormulaRectangleHeight()-10), new Formula("bottom")));






            if(node.getFormula().isAnd() & node.noFather())
            {
                hintsBU.add(new ProofFormulaNodeNatDet(new Point(node.getXMilieu() - 50,
                               node.getYBottom() + 20), node.getFormula().getSubFormulaLeft()));
                hintsBU.add(new ProofFormulaNodeNatDet(new Point(node.getXMilieu() + 50,
                               node.getYBottom() + 40), node.getFormula().getSubFormulaRight()));

            }






            if(node.getFormula().isNotNot() & node.noFather())
                hintsBU.add(new ProofFormulaNodeNatDet(new Point(node.getXMilieu(),
                               node.getYBottom() + 20), node.getFormula().getSubFormulaForNot().getSubFormulaForNot()));

            if(node.isHypothesePrincipale())
            {
                int x = node.getXMilieu() - 100;
                for(Formula f : node.getHypothesesDechargeables())
                {
                    ProofFormulaNodeNatDet n = new ProofFormulaNodeNatDet(new Point(x, 0), f);
                    n.setPointMilieuHautImmediat(new Point(x + n.getWidth()/2, 0));
                    hintsHypothesesDechargees.add(n);
                    x += n.getWidth() + 15;
                }
            }


            if(node.getFormula().isOr() & node.noFather())
            {
                hintsHypothesesDechargees.add(new ProofFormulaNodeNatDet(new Point(node.getXMilieu() + 100,
                               node.getYBottom() - 100), node.getFormula().getSubFormulaLeft()));
                hintsHypothesesDechargees.add(new ProofFormulaNodeNatDet(new Point(node.getXMilieu() + 200,
                               node.getYBottom() - 100), node.getFormula().getSubFormulaRight()));
            }

        }






    }




    @Override
    protected void selectionChange() {
        super.selectionChange();

        calculerHints();
        
    }


    
    
    






}
