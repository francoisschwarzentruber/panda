/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroAnd extends InsertionRuleButtonOneNode {
    public InsertionRuleIntroAnd() {
        super("\\frac{\\newnode{A}\\hspace{5mm}\\newnode{B}}{\\selectednode{A \\wedge B}}(I \\wedge)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.getFormula().isAnd() & node.noChildren();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        if(!node.getFormula().isAnd())
            return;
        
        ProofFormulaNodeNatDet child1 = new ProofFormulaNodeNatDet(null, node.getFormula().getSubFormulaLeft());
        ProofFormulaNodeNatDet child2 = new ProofFormulaNodeNatDet(null, node.getFormula().getSubFormulaRight());

        proofPanel.commandExecute(new CommandNodeAddTwoNewChildren(node, child1, child2));
        proofPanel.setNodeSelected(child1);
    }

}
