/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.Stack;

/**
 * Cette classe représente un gestionnaire de commandes.
 * Il stocke les commandes déjà effectuées sur une preuve et permet
 * d'annuler et refaire des actions.
 * @author Ancmin
 */
public class CommandsManager {

    /**
     * panel où s'effectue les preuves
     */
    private final ProofPanel proofPanel;
    
    /**
     * les commandes déjà effectuées (et annulables)
     */
    private final Stack<Command> commandsPast = new Stack<Command>();
    
    /**
     * les commandes qu'on a annulé et qu'on peut refaire
     */
    private final Stack<Command> commandsFuture = new Stack<Command>();


    /**
     * construit un gestionnaire de commandes qui marche avec
     * le panneau de preuves proofPanel
     * @param proofPanel
     */
    public CommandsManager(final ProofPanel proofPanel) {
        this.proofPanel = proofPanel;
    }

    /**
     * exécute la commande command et enregistre cette action comme étant faite
     * (supprime aussi toutes les actions à refaire préalablement sauvegardées)
     * @param command
     */
    public void execute(final Command command)
    {
        command.execute(proofPanel);
        commandsPast.push(command);
        commandsFuture.clear();
    }



/**
 * annule la dernière action
 */
    public void undoLastCommand()
    {
        if(commandsPast.empty())
            return;
        
        Command c = commandsPast.pop();
        c.undo(proofPanel);
        commandsFuture.push(c);
    }


    /**
     * exécute l'action suivante
     */
    public void redoNextCommand()
    {
        if(commandsFuture.empty())
            return;

        
        Command c = commandsFuture.pop();
        c.execute(proofPanel);
        commandsPast.push(c);
    }




    /**
     * supprime toutes les listes des commandes effectuées
     */
    public void clear() {
        commandsFuture.clear();
        commandsPast.clear();
    }



}
