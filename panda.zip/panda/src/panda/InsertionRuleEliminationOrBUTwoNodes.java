/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.awt.Point;
import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationOrBUTwoNodes extends InsertionRuleButton {
    public InsertionRuleEliminationOrBUTwoNodes() {
        super("\\frac{\\selectednode{A \\vee B} \\hspace{0mm}" +
                "\\begin{array}{c}A(i) \\\\ \\vdots\\\\\\newnode{C}\\end{array} \\hspace{0mm}" +
                "\\begin{array}{c}B(j) \\\\ \\vdots\\\\ \\newnode{C}\\end{array}} {\\selectednode{C}} (E \\vee)(i)(j)");
    }


    ProofFormulaNode nodeOr;
    ProofFormulaNode nodeConclusion;


    /**
     *
     * @param Or
     * @param Conclu
     * @return vrai si le noeud Or est un ou sans père, le noeud conclu sans fils, qui n'est pas un ou alors
     * qui est en dessous du noeud Or
     *
     */
    boolean isMatchOrConclu(ProofFormulaNode Or, ProofFormulaNode Conclu)
    {
        Formula f0 = Or.getFormula();
        Formula f1 = Conclu.getFormula();

        return f0.isOr() &
                Or.noFather() &
                ((!f1.isOr()  | Conclu.getYFormulaTop() > Or.getYFormulaTop())
                   & Conclu.noChildren());
        
    }



    @Override
    boolean testIfRuleApplicable(ArrayList<ProofFormulaNode> nodes) {
        if(nodes.size() != 2)
            return false;
       
        

       
        if(isMatchOrConclu(nodes.get(0), nodes.get(1)))
        {
            nodeOr = nodes.get(0);
            nodeConclusion = nodes.get(1);
            return true;
        }

        if(isMatchOrConclu(nodes.get(1), nodes.get(0)))
        {
            nodeOr = nodes.get(1);
            nodeConclusion = nodes.get(0);
            return true;
        }

        return false;
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ArrayList<ProofFormulaNode> nodes) {
        Formula fConclusion = nodeConclusion.getFormula();
        ProofFormulaNodeNatDet C1 = new ProofFormulaNodeNatDet(nodeConclusion.getPointMilieuHaut(), fConclusion);
        ProofFormulaNodeNatDet C2 = new ProofFormulaNodeNatDet(nodeConclusion.getPointMilieuHaut(), fConclusion);

        CommandComposees c = new CommandComposees();

        c.commandAdd(new CommandNodeAddChild(nodeConclusion, nodeOr, nodeOr.getPointMilieuHaut()));
        c.commandAdd(new CommandNodeAddNewChild(nodeConclusion, C1));
        c.commandAdd(new CommandNodeAddNewChild(nodeConclusion, C2));

        proofPanel.commandExecute(c);
    }

   
}
