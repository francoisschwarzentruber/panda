/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.awt.Color;

/**
 * Un bouton dont l'image est l'image générée par LaTEX d'une formule
 * @author Ancmin
 */
public class ButtonFormula extends ButtonLaTEXImage {

    public ButtonFormula(Formula formula) throws Exception {
        super(FormulaBox.formulaSchemeToLatexCode(formula));
        setBackground(Color.GREEN);
    }


}
