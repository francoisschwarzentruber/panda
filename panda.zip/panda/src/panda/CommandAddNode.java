/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class CommandAddNode implements Command {

    private final ProofFormulaNode nodeToAdd;

    public CommandAddNode(ProofFormulaNode nodeToAdd) {
        this.nodeToAdd = nodeToAdd;
    }

    


    public void execute(ProofPanel proofPanel) {
        proofPanel.nodeAdd(nodeToAdd);
    }

    public void undo(ProofPanel proofPanel) {
       proofPanel.nodeRemove(nodeToAdd);
    }





}
