/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationImplyBU extends InsertionRuleButtonOneNode {
    public InsertionRuleEliminationImplyBU() {
        super("\\frac{\\selectednode{A \\rightarrow B} \\hspace{5mm} \\newnode{A}}{\\newnode{B}} (E \\rightarrow)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.noFather() & node.getFormula().isImply();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        ProofFormulaNodeNatDet father = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), node.getFormula().getSubFormulaRight());
        ProofFormulaNodeNatDet child2 = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), node.getFormula().getSubFormulaLeft());

        CommandComposees c = new CommandComposees();

        c.commandAdd(new CommandNodeAddChild(father, node, node.getPointMilieuHaut()));
        c.commandAdd(new CommandNodeAddChild(father, child2, child2.getPointMilieuHaut()));

        c.commandAdd(new CommandAddNode(father));
        c.commandAdd(new CommandAddNode(child2));

        proofPanel.commandExecute(c);
        
    }

}
