/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroForallBU extends InsertionRuleButtonOneNode {
    final String variable;

    public InsertionRuleIntroForallBU(String variable) throws Exception {
        super("\\frac{\\selectednode{A}}{\\newnode{\\forall " + variable + ". A}} (I \\forall)");
        this.variable = variable;
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.noFather();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        ProofFormulaNodeNatDet father = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), new Formula("(forall " + variable + node.getFormula() + ")"));
        proofPanel.commandExecute(new CommandCreateFatherForNode(father, node));
        proofPanel.setNodeSelected(father);
        
    }

}
