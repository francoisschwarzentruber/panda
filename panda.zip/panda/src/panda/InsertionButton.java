/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * SATResults.java
 *
 * Created on 26 sept. 2010, 02:57:12
 */

package panda;


import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe représente un bouton qui permet d'insérer du texteScheme
 * dans un champ Scheme
 * @author François Schwarzentruber
 */
public class InsertionButton extends ButtonLaTEXImage  {

    private final String texteScheme;
   

    /**
     * insère le texteScheme texteScheme dans le champ Scheme sélectionné
     * @param texteScheme
     */
    private void inserer(String texteScheme)
    {
         FormulaBox.getFocusOwnerFormulaBox().insert(texteScheme);


    }



    static String schemeToLaTEX(String texteScheme)
    {
        try {
            return FormulaBox.formulaSchemeStringToLatexCode(texteScheme);
        } catch (Exception ex) {
            Logger.getLogger(InsertionButton.class.getName()).log(Level.SEVERE, null, ex);
            return "";
        }
    }
    
    public InsertionButton(String atexteScheme) {
        super(schemeToLaTEX(atexteScheme));

        this.texteScheme = atexteScheme;

        addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inserer(texteScheme);
            }
        });
        this.setFocusable(false);
        this.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        //this.setName("bigor"); // NOI18N
        this.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
       // this.setMaximumSize(new Dimension(this.getIcon().getIconWidth(),this.getIcon().getIconHeight()));
     //   this.setPreferredSize(new Dimension(this.getIcon().getIconWidth(),this.getIcon().getIconHeight()));
    }

    
    public InsertionButton(String texteScheme, String aide) {
        this(texteScheme);
        setToolTipText(texteScheme);
        
    }



}
