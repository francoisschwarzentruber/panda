/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroEquivBU extends InsertionRuleButton {
public InsertionRuleIntroEquivBU() {
        super("\\frac{\\selectednode{A \\rightarrow B}\\hspace{5mm}\\selectednode{B \\rightarrow A}}{\\newnode{A \\leftrightarrow B}}(I \\leftrightarrow)");
    }

    Formula A;
    Formula B;


    @Override
    boolean testIfRuleApplicable(ArrayList<ProofFormulaNode> nodes) {
        if(nodes.size() != 2)
            return false;

        if(!areAllNoFather(nodes))
            return false;


        Formula f0 = nodes.get(0).getFormula();
        Formula f1 = nodes.get(1).getFormula();

        if(!f0.isImply() || !f1.isImply())
            return false;

        if(!f0.getSubFormulaLeft().equals(f1.getSubFormulaRight()))
            return false;

        if(!f1.getSubFormulaLeft().equals(f0.getSubFormulaRight()))
            return false;

        A = f0.getSubFormulaLeft();
        B = f0.getSubFormulaRight();


        return true;


    }

    @Override
    void ruleApply(ProofPanel proofPanel, ArrayList<ProofFormulaNode> nodes) {
        proofPanel.createCommonFatherBarycentre(nodes, new Formula("(" + A + " equiv " + B + ")"));
    }

}
