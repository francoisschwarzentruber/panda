/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationOrBUThreeNodes extends InsertionRuleButton {
    public InsertionRuleEliminationOrBUThreeNodes() {
        super("\\frac{\\selectednode{A \\vee B} \\hspace{0mm}" +
                "\\begin{array}{c}A(i) \\\\ \\vdots\\\\\\selectednode{C}\\end{array} \\hspace{0mm}" +
                "\\begin{array}{c}B(j) \\\\ \\vdots\\\\ \\selectednode{C}\\end{array}} {\\newnode{C}} (E \\vee)(i)(j)");
    }


    Formula C;

    @Override
    boolean testIfRuleApplicable(ArrayList<ProofFormulaNode> nodes) {
        if(nodes.size() != 3)
            return false;
        if(!areAllNoFather(nodes))
            return false;
        Formula f0 = nodes.get(0).getFormula();
            Formula f1 = nodes.get(1).getFormula();
            Formula f2 = nodes.get(2).getFormula();

            if(f0.equals(f1))
            {
                Formula t = f2;
                f2 = f1;
                f1 = f0;
                f0 = t;
            }

            if(f0.equals(f2))
            {
                f0 = f1;
                f1 = f2;
            }

            //f0 devrait contenir le "ou"

            if(f0.isOr() & f1.equals(f2))
            {
                C = f2;
                return true;
            }

            return false;

        
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ArrayList<ProofFormulaNode> nodes) {
        proofPanel.createCommonFatherBarycentre(nodes, C);
    }

   
}
