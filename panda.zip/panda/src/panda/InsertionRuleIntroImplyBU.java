/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroImplyBU extends InsertionRuleButtonOneNode {
    final Formula formulaA;

    public InsertionRuleIntroImplyBU(Formula formulaA) throws Exception {
        super("\\frac{\\selectednode{B}}{\\newnode{" +
                FormulaBox.formulaSchemeToLatexCode(formulaA) +
                " \\rightarrow B}} (I \\rightarrow) (i)");
        this.formulaA = formulaA;
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.noFather();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        ProofFormulaNodeNatDet father = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), new Formula("(" + formulaA + " imply " + node.getFormula() + ")"));
        proofPanel.commandExecute(new CommandCreateFatherForNode(father, node));
        proofPanel.setNodeSelected(father);
        
    }

}
