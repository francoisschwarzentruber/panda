/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationAndD extends InsertionRuleButtonOneNode {

    public InsertionRuleEliminationAndD() {
        super("\\frac{\\newnode{A \\wedge B} \\hspace{0.5cm}}{\\selectednode{B}} (E \\wedge)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.noChildren();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        FormulaDialog d = new FormulaDialog(null, true, proofPanel.getFormulasHypotheses(), java.util.ResourceBundle.getBundle("panda/resources/InsertionRuleButton").getString("giveA"));

        d.setVisible(true);

        if(!d.isOK())
            return;

        ProofFormulaNodeNatDet child = new ProofFormulaNodeNatDet(null, new Formula("(" + d.getFormula() + " and " + node.getFormula() + ")"));

        proofPanel.commandExecute(new CommandNodeAddNewChild(node, child));
        proofPanel.setNodeSelected(child);
        
        
    }

}
