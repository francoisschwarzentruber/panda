/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationExists extends InsertionRuleButtonOneNode {
    public InsertionRuleEliminationExists() {
        super("\\frac{\\newnode{\\exists x . A} \\hspace{0mm}" +
                "\\begin{array}{c}A(i) \\\\ \\vdots\\\\\\newnode{C}\\end{array}}" +
                " {\\selectednode{C}} (E \\exists)(i)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        if(node.noChildren())
             return true;
        else if (node.getNbChildren() == 1)
        {
            return node.getChild(0).getFormula().isExists();
        }
        else
            return false;

    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {


        CommandComposees c = new CommandComposees();

        if(node.noChildren())
        {
            FormulaDialog d = new FormulaDialog(null, true, proofPanel.getFormulasHypotheses(),
                    java.util.ResourceBundle.getBundle("panda/resources/InsertionRuleButton").getString("giveExistential"));
            d.setVisible(true);

            if(!d.isOK())
                return;

            while(!d.getFormula().isExists())
            {
                d.setVisible(true);

                if(!d.isOK())
                    return;
            }
            

            ProofFormulaNodeNatDet childExists = new ProofFormulaNodeNatDet(null, d.getFormula());
            c.commandAdd(new CommandNodeAddNewChild(node, childExists));
            
        }
       
        
        ProofFormulaNodeNatDet child1 = new ProofFormulaNodeNatDet(null, node.getFormula());

        c.commandAdd(new CommandNodeAddNewChild(node, child1));

        proofPanel.commandExecute(c);
        proofPanel.setNodeSelected(child1);
        
    }

}
