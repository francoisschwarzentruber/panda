/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationBottomBU extends InsertionRuleButtonOneNode {
    public InsertionRuleEliminationBottomBU() {
        super("\\frac{\\selectednode{\\bot}}{\\newnode{A}} (E \\bot)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.noFather() & node.getFormula().isBottom();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        FormulaDialog d = new FormulaDialog(null, true, proofPanel.getFormulasHypotheses(), "Donne la formule à déduire de bottom : ");

        d.setVisible(true);

        if(!d.isOK())
            return;
        
        ProofFormulaNodeNatDet father = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), d.getFormula());
        proofPanel.commandExecute(new CommandCreateFatherForNode(father, node));
        proofPanel.setNodeSelected(father);

    }

}
