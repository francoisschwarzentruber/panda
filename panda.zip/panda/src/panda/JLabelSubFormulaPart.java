/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.awt.Color;

/**
 * JLabel qui contient une partie d'une formule (afin de pouvoir cliquer dessus et interagir...)
 * (notamment un sous-terme
 * @author François Schwarzentruber
 */
public class JLabelSubFormulaPart extends JLabelLaTEXImage {

    
    /**
     * code Scheme correspondant à la portion de la formule
     */
    private final String schemeCode;
    
    
    /**
     * Label qui contient la première partie de cette partie de la formule
     * Exemple : si ce label correspond à "," dans "p(x, y)" alors ce label est 
     * celui qui affiche "p(".
     */
    private final JLabelSubFormulaPart firstLabel;


    public JLabelSubFormulaPart(String schemeCode, String laTEXCode, JLabelSubFormulaPart firstLabel) {
        super(laTEXCode);
        this.schemeCode = schemeCode;
        this.firstLabel = firstLabel;

    }

    public String getSchemeCode() {
        return schemeCode;
    }

    public JLabelSubFormulaPart getFirstLabel() {
        if(firstLabel == null)
            return this;
        else
        return firstLabel;
    }


    

    public void select()
    {
        setBackground(Color.CYAN);
        setOpaque(true);
    }


    public void deSelect()
    {
        setBackground(Color.LIGHT_GRAY);
        setOpaque(false);
    }

    boolean isSelected() {
        return isOpaque();
    }


}
