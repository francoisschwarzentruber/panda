/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.awt.Point;

/**
 *
 * @author Ancmin
 */
class CommandNodeAddChild implements Command {

    private final ProofFormulaNode child;
    private final ProofFormulaNode newfather;
    private final ProofFormulaNode lastfather;
    private final Point lastPosition;

    public CommandNodeAddChild(ProofFormulaNode father, ProofFormulaNode child, Point childLastPosition) {
        this.child = child;
        this.lastfather = child.getFather();
        this.lastPosition = childLastPosition;
        this.newfather = father;

    }


    public CommandNodeAddChild(ProofFormulaNode father, ProofFormulaNode child) {
        this.child = child;
        this.lastfather = child.getFather();
        this.lastPosition = child.getPointMilieuHaut();
        this.newfather = father;

    }

    public void execute(ProofPanel proofPanel) {
        newfather.addChild(child);
    }

    public void undo(ProofPanel proofPanel) {
        child.deconnectFromFather();

        if(lastfather != null)
            lastfather.addChild(child);
        else if(lastPosition != null)
            child.setPointMilieuHaut(lastPosition);
    }

}
