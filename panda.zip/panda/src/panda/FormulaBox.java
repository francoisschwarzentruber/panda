package panda;


/**
 * composant qui permet d'entrer des formules
 * @author Ancmin
 */
public class FormulaBox extends AbstractFormulaBox {

    @Override
    protected String textToLatexCode(Formula formula) throws Exception {
        return formulaSchemeToLatexCode(formula);
    }


}
