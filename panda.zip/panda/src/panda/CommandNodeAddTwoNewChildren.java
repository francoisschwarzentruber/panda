/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class CommandNodeAddTwoNewChildren extends CommandComposees {
    
    /**
     * Command that ADD child TO THE PROOF and add child as child to father
     * @param child
     * @param father
     */
    public CommandNodeAddTwoNewChildren(ProofFormulaNode father, ProofFormulaNode child1, ProofFormulaNode child2) {
        commandAdd(new CommandNodeAddChild(father, child1, null));
        commandAdd(new CommandNodeAddChild(father, child2, null));
        commandAdd(new CommandAddNode(child1));
        commandAdd(new CommandAddNode(child2));
    }


    


    
    

}
