/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationOr extends InsertionRuleButtonOneNode {
    public InsertionRuleEliminationOr() {
        super("\\frac{\\newnode{A \\vee B} \\hspace{0mm}" +
                "\\begin{array}{c}A(i) \\\\ \\vdots\\\\\\newnode{C}\\end{array} \\hspace{0mm}" +
                "\\begin{array}{c}B(j) \\\\ \\vdots\\\\\\newnode{C}\\end{array}} {\\selectednode{C}} (E \\vee)(i)(j)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        if(node.noChildren())
             return true;
        else if (node.getNbChildren() == 1)
        {
            return node.getChild(0).getFormula().isOr();
        }
        else
            return false;

    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {


        CommandComposees c = new CommandComposees();

        if(node.noChildren())
        {
            FormulaDialog d = new FormulaDialog(null, true, proofPanel.getFormulasHypotheses(), java.util.ResourceBundle.getBundle("panda/resources/InsertionRuleButton").getString("giveOr"));
            d.setVisible(true);

            if(!d.isOK())
                return;

            while(!d.getFormula().isOr())
            {
                d.setVisible(true);

                if(!d.isOK())
                    return;
            }
            

            ProofFormulaNodeNatDet childOr = new ProofFormulaNodeNatDet(null, d.getFormula());
            c.commandAdd(new CommandNodeAddNewChild(node, childOr));
            
        }
       
        
        ProofFormulaNodeNatDet child1 = new ProofFormulaNodeNatDet(null, node.getFormula());
        ProofFormulaNodeNatDet child2 = new ProofFormulaNodeNatDet(null, node.getFormula());

        c.commandAdd(new CommandNodeAddTwoNewChildren(node, child1, child2));

        proofPanel.commandExecute(c);
        proofPanel.setNodeSelected(child1);
        
    }

}
