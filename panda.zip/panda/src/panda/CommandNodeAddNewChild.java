/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class CommandNodeAddNewChild extends CommandComposees {
    
    /**
     * Command that ADD child TO THE PROOF and add child as child to father
     * @param child
     * @param father
     */
    public CommandNodeAddNewChild(ProofFormulaNode father, ProofFormulaNode child) {
        commandAdd(new CommandNodeAddChild(father, child, null));
        commandAdd(new CommandAddNode(child));
    }


    


    
    

}
