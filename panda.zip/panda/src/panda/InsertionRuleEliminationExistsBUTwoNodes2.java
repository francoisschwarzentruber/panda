/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationExistsBUTwoNodes2 extends InsertionRuleButton {
    public InsertionRuleEliminationExistsBUTwoNodes2() {
        super("\\frac{\\selectednode{\\exists x . A} \\hspace{0mm}" +
                "\\begin{array}{c}A(i) \\\\ \\vdots\\\\\\selectednode{C}\\end{array}}" +
                " {\\newnode{C}} (E \\exists)(i)");
    }


    ProofFormulaNode nodeExists;
    ProofFormulaNode nodeConclusion;


    /**
     *
     * @param exists
     * @param Conclu
     * @return vrai si le noeud exists est un noeud existentiel sans père,
     * le noeud conclu est aussi sans père
     *
     * En cas de concurrence, le noeud existentiel est le plus à gauche.
     *
     */
    boolean isMatchExistsConclu(ProofFormulaNode exists, ProofFormulaNode Conclu)
    {
        Formula f0 = exists.getFormula();
        Formula f1 = Conclu.getFormula();

        /**si on a affaire à deux formules existencielles
         * "ça matche avec celle qui est la plus à gauche"
         * c'est à dire que le noeud "existentiel" doit être à gauche
         */
        if(f0.isExists() & exists.noFather() & f1.isExists() & Conclu.noFather())
        {
            return exists.getXMilieu() < Conclu.getXMilieu();
        }
        else
            return f0.isExists() &
                   exists.noFather() &
                   Conclu.noFather();
        
    }



    @Override
    boolean testIfRuleApplicable(ArrayList<ProofFormulaNode> nodes) {
        if(nodes.size() != 2)
            return false;

       
        if(isMatchExistsConclu(nodes.get(0), nodes.get(1)))
        {
            nodeExists = nodes.get(0);
            nodeConclusion = nodes.get(1);
            return true;
        }

        if(isMatchExistsConclu(nodes.get(1), nodes.get(0)))
        {
            nodeExists = nodes.get(1);
            nodeConclusion = nodes.get(0);
            return true;
        }

        return false;
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ArrayList<ProofFormulaNode> nodes) {
        proofPanel.createCommonFatherBarycentre(nodes, nodeConclusion.getFormula());
    }

   
}
