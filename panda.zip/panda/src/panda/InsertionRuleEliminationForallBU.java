/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationForallBU extends InsertionRuleButtonOneNode {
    public InsertionRuleEliminationForallBU() {
        super("\\frac{\\selectednode{\\forall x. A}}{\\newnode{A[t/x]}} (E \\forall)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {

        if(!node.noFather())
            return false;

        if(!node.getFormula().isForAll())
            return false;

        return true;
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        String x = node.getFormula().getQuantifierVariable();


        TermDialog d = new TermDialog(null, true,  "Par quoi substitues-tu la variable '" + x  + "' :", x);
        d.setVisible(true);

        if(!d.isOK())
            return;

        Formula t = d.getFormula();
        ProofFormulaNodeNatDet father = 
                new ProofFormulaNodeNatDet(node.getPointMilieuHaut(),
                                           node.getFormula().getQuantifierSubFormula().substituer(x, t));
        proofPanel.commandExecute(new CommandCreateFatherForNode(father, node));

        proofPanel.setNodeSelected(father);

    }

}
