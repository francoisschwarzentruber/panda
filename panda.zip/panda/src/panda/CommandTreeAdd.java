/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package panda;

import java.awt.Point;
import org.jdom.Element;

/**
 *
 * @author Ancmin
 */
class CommandTreeAdd extends CommandComposees {

    private final ProofFormulaNode nodeRoot;
    
    public CommandTreeAdd(Element element) {
        Formula formula = new Formula(element.getChild("formula").getText());

        int x = Integer.parseInt(element.getChild("graphicalposition").getChild("x").getText());
        int y = Integer.parseInt(element.getChild("graphicalposition").getChild("y").getText());
        Point pointMilieu = new Point(x, y);

        nodeRoot = new ProofFormulaNodeNatDet(pointMilieu, formula);
        for(Object elementChild : element.getChild("children").getChildren())
        {
            CommandTreeAdd commandTreeAdd = new CommandTreeAdd((Element) elementChild);
            commandAdd(commandTreeAdd);
            commandAdd(new CommandNodeAddChild(nodeRoot, commandTreeAdd.getNodeRoot()));
        }

        commandAdd(new CommandAddNode(nodeRoot));
        

    }

    public ProofFormulaNode getNodeRoot() {
        return nodeRoot;
    }
    
    
    
    
}
