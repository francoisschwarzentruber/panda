/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationExistsBUTwoNodes extends InsertionRuleButton {
    public InsertionRuleEliminationExistsBUTwoNodes() {
        super("\\frac{\\selectednode{\\exists x . A} \\hspace{0mm}" +
                "\\begin{array}{c}A(i) \\\\ \\vdots\\\\\\newnode{C}\\end{array}}" +
                " {\\selectednode{C}} (E \\exists)(i)");
    }


    ProofFormulaNode nodeExists;
    ProofFormulaNode nodeConclusion;


    /**
     *
     * @param Or
     * @param exists
     * @return vrai si le noeud exists est un noeud existentiel sans père,
     * le noeud conclu sans fils, qui n'est pas un noeud existentiel alors
     * qui est en dessous du noeud Or
     *
     */
    boolean isMatchExistsConclu(ProofFormulaNode exists, ProofFormulaNode Conclu)
    {
        Formula f0 = exists.getFormula();
        Formula f1 = Conclu.getFormula();

        return f0.isExists() &
                exists.noFather() &
                ((!f1.isExists()  | Conclu.getYFormulaTop() > exists.getYFormulaTop())
                   & Conclu.noChildren());
        
    }



    @Override
    boolean testIfRuleApplicable(ArrayList<ProofFormulaNode> nodes) {
        if(nodes.size() != 2)
            return false;
       
        

       
        if(isMatchExistsConclu(nodes.get(0), nodes.get(1)))
        {
            nodeExists = nodes.get(0);
            nodeConclusion = nodes.get(1);
            return true;
        }

        if(isMatchExistsConclu(nodes.get(1), nodes.get(0)))
        {
            nodeExists = nodes.get(1);
            nodeConclusion = nodes.get(0);
            return true;
        }

        return false;
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ArrayList<ProofFormulaNode> nodes) {
        Formula fConclusion = nodeConclusion.getFormula();
        ProofFormulaNodeNatDet C1 = new ProofFormulaNodeNatDet(nodeConclusion.getPointMilieuHaut(), fConclusion);

        CommandComposees c = new CommandComposees();
        
        c.commandAdd(new CommandNodeAddChild(nodeConclusion, nodeExists, nodeExists.getPointMilieuHaut()));
        c.commandAdd(new CommandNodeAddChild(nodeConclusion, C1, C1.getPointMilieuHaut()));

        c.commandAdd(new CommandAddNode(C1));


        proofPanel.commandExecute(c);


    }

   
}
