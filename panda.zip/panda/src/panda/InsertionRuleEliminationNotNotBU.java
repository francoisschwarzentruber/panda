/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationNotNotBU extends InsertionRuleButtonOneNodeAddFather {
    public InsertionRuleEliminationNotNotBU() {
        super("\\frac{\\selectednode{\\neg \\neg A}}{\\newnode{A}} (E \\neg \\neg)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {

        if(!node.noFather())
            return false;

        if(!node.getFormula().isNot())
            return false;

        return node.getFormula().getSubFormulaForNot().isNot();
    }

    @Override
    Formula getFormulaOfFather(ProofFormulaNodeNatDet node) {
        return node.getFormula().getSubFormulaForNot().getSubFormulaForNot();
    }



}
