/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationOrBUNodeOr extends InsertionRuleButtonOneNode {
    public InsertionRuleEliminationOrBUNodeOr() {
        super("\\frac{\\selectednode{A \\vee B} \\hspace{0mm}" +
                "\\begin{array}{c}A(i) \\\\ \\vdots\\\\\\newnode{C}\\end{array} \\hspace{0mm}" +
                "\\begin{array}{c}B(j) \\\\ \\vdots\\\\ \\newnode{C}\\end{array}} {\\newnode{C}} (E \\vee)(i)(j)");
    }





    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.getFormula().isOr() & node.noFather();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        FormulaDialog d = new FormulaDialog(null, true, proofPanel.getFormulasHypotheses(), java.util.ResourceBundle.getBundle("panda/resources/InsertionRuleButton").getString("giveConclusion"));
        d.setVisible(true);

        if(!d.isOK())
           return;



       Formula fConclusion = d.getFormula();

        CommandComposees c = new CommandComposees();

        ProofFormulaNodeNatDet C1 = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), fConclusion);
        ProofFormulaNodeNatDet C2 = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), fConclusion);
        ProofFormulaNodeNatDet conclusion = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), fConclusion);


        c.commandAdd(new CommandAddNode(C1));
        c.commandAdd(new CommandAddNode(C2));
        c.commandAdd(new CommandAddNode(conclusion));

        c.commandAdd(new CommandNodeAddChild(conclusion, node, node.getPointMilieuHaut()));
        c.commandAdd(new CommandNodeAddChild(conclusion, C1, C1.getPointMilieuHaut()));
        c.commandAdd(new CommandNodeAddChild(conclusion, C2, C2.getPointMilieuHaut()));

        proofPanel.commandExecute(c);
    }

   
}
