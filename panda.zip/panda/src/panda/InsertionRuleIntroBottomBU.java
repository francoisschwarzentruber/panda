/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroBottomBU extends InsertionRuleButtonOneNode {
    public InsertionRuleIntroBottomBU() {
        super("\\frac{\\newnode{A}\\hspace{5mm}\\selectednode{\\neg A}}{\\newnode{\\bot}}(I \\bot)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.getFormula().isNot() & node.noFather();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        ProofFormulaNodeNatDet father = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), new Formula("bottom"));
        ProofFormulaNodeNatDet child1 = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), node.getFormula().getSubFormulaForNot());

        CommandComposees c = new CommandComposees();

        c.commandAdd(new CommandAddNode(father));
        c.commandAdd(new CommandAddNode(child1));

        c.commandAdd(new CommandNodeAddChild(father, child1));
        c.commandAdd(new CommandNodeAddChild(father, node));

        proofPanel.commandExecute(c);
        proofPanel.setNodeSelected(father);
        
    }

}
