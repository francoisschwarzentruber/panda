/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationAndDBU extends InsertionRuleButtonOneNodeAddFather {

    public InsertionRuleEliminationAndDBU() {
        super("\\frac{\\selectednode{A \\wedge B} \\hspace{0.5cm}}{\\newnode{A}} (E \\wedge)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.noFather() & node.getFormula().isAnd();
    }

    @Override
    Formula getFormulaOfFather(ProofFormulaNodeNatDet node) {
        return node.getFormula().getSubFormulaLeft();
    }

    

}
