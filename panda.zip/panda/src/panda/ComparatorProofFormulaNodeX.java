/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 * for sorting ProofFormulaNode by their horizontal position
 * @author Ancmin
 */
class ComparatorProofFormulaNodeX implements java.util.Comparator {

    public ComparatorProofFormulaNodeX() {
    }

    public int compare(Object o1, Object o2) {
        if(!(o1 instanceof ProofFormulaNode))
            return -1;
        if(!(o2 instanceof ProofFormulaNode))
            return -1;

        ProofFormulaNode n1 = (ProofFormulaNode) o1;
        ProofFormulaNode n2 = (ProofFormulaNode) o2;

        if(n1 == n2)
            return 0;
        
        if(n1.getXMilieu() <= n2.getXMilieu())
            return -1;
        else
            return 1;
        
    }

}
