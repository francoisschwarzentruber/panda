/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationNotNot extends InsertionRuleButtonOneNodeAddOneChild {
    public InsertionRuleEliminationNotNot() {
        super("\\frac{\\newnode{\\neg \\neg A}}{\\selectednode{A}} (E \\neg \\neg)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.noChildren();
    }

    @Override
    Formula getFormulaChild(ProofFormulaNodeNatDet node) {
        return new Formula("(not (not " + node.getFormula() + "))");
    }

    

}
