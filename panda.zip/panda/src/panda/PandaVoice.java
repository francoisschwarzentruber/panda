package panda;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * This class is used for speaking texts!
 * @author Ancmin
 */
public class PandaVoice {
    static VoiceManager voiceManager = null;
    static Voice voice = null;

    
    private  static void load()
    {
        voiceManager = VoiceManager.getInstance();
        
        voice = voiceManager.getVoice("kevin16");

        voice.allocate();
      //  voice.setRate(70);
    }

     public static void speak(String s)
    {
        if(voice == null)
            load();

        voice.speak(s);


    }


}
