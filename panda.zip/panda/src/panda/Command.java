/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 * Représente une commande.
 * Par exemple : - ajouter un noeud
 *               - supprimer un noeud
 *               - ajouter un père commun à plusieurs noeuds
 * etc.
 * @author Ancmin
 */
public interface Command {

    /**
     * procédure qui exécute la commande
     * @param proofPanel
     */
    public void execute(ProofPanel proofPanel);

    /**
     * procédure qui annule la commande. Exécute "commande^{-1}". :)
     * @param proofPanel
     */
    public void undo(ProofPanel proofPanel);


    
}
