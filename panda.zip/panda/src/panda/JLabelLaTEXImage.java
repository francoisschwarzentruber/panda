/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import javax.swing.JLabel;

/**
 * Label qui contient un affichage provenant d'un code latex
 * @author François Schwarzentruber
 */
public class JLabelLaTEXImage extends JLabel {

    /**
     * Example new ButtonLaTEXImage("p \\vee q")
     * ("\\" and "\" because of Java...)
     * @param codeLaTEX
     */
    JLabelLaTEXImage(String codeLaTEX)
    {

        try
        {
            this.setText("");
            this.setIcon(LaTEX.latexCodeToImageIcon(codeLaTEX));
        }
        
        catch(Exception e)
        {
            System.out.println("Erreur de création du label. Problème avec le code LaTEX suivant : "+ codeLaTEX);
        }
    }


}
