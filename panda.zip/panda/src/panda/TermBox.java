package panda;


/**
 * composant qui permet d'entrer des termes
 * @author Ancmin
 */
public class TermBox extends AbstractFormulaBox {

    @Override
    protected String textToLatexCode(Formula formula) throws Exception {
        return termToLaTeX(formula);
    }

}
