/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;

/**
 * représente une animation qui a lieu quand on connecte, déconnecte, supprime, ajoute un noeud
 * @author François Schwarzentruber
 */
public class AnimatedRectangle  {
    private final Rectangle rectangle;
    private int anim = 0;
    private int animMax = 6;

    public AnimatedRectangle(Rectangle rectangle) {
        this.rectangle = rectangle;
    }


    public boolean isAnimationFinished()
    {
        return anim > animMax;
    }

    public void draw(Graphics g)
    {
        rectangle.grow(4, 4);

        final int x1 = rectangle.x;
        final int x2 = rectangle.x + rectangle.width;

        final int y1 = rectangle.y;
        final int y2 = rectangle.y + rectangle.height;

        final double xc = rectangle.getCenterX();
        final double yc = rectangle.getCenterY();

        final float f = ((float) anim) / ((float) animMax);
        //float f = 0.0f;
        g.setColor(new Color(f,f,f));
        ((Graphics2D) g).setStroke(new BasicStroke(1.0f));

        final int l = 8;

        int x = x1;
        while(x < x2)
        {
            double angle = Math.atan2(y1 - yc, x - xc);
            
            g.drawLine(x, y1, x + (int) (l * Math.cos(angle)), y1 + (int) (l * Math.sin(angle)));

            angle = Math.atan2(y2 - yc, x - xc);
            g.drawLine(x, y2, x + (int) (l * Math.cos(angle)), y2 + (int) (l * Math.sin(angle)));
            x += 8;
        }

        int y = y1;
        while(y < y2)
        {
            double angle = Math.atan2(y - yc, x1 - xc);


            g.drawLine(x1, y, x1+ (int) (l * Math.cos(angle)), y + (int) (l * Math.sin(angle)));

            angle = Math.atan2(y - yc, x2 - xc);


            g.drawLine(x2, y, x2 + (int) (l * Math.cos(angle)), y + (int) (l * Math.sin(angle)));
            y += 8;
        }
        
        anim++;
    }
    
}
