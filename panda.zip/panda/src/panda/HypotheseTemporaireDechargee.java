/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 * this class represents a temporary hypothesis.
 * @author Ancmin
 */
public class HypotheseTemporaireDechargee {
    private final int numeroHypothese;
    private final Formula formula;

    HypotheseTemporaireDechargee(int numeroHypothese, Formula formula)
    {
        this.numeroHypothese = numeroHypothese;
        this.formula = formula;
    }

    public Formula getFormula() {
        return formula;
    }

    public int getNumeroHypothese() {
        return numeroHypothese;
    }


    
}
