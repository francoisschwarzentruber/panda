/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationAndGBU extends InsertionRuleButtonOneNodeAddFather {

    public InsertionRuleEliminationAndGBU() {
        super("\\frac{\\selectednode{A \\wedge B} \\hspace{0.5cm}}{\\newnode{B}} (E \\wedge)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.noFather() & node.getFormula().isAnd();
    }

    @Override
    Formula getFormulaOfFather(ProofFormulaNodeNatDet node) {
        return node.getFormula().getSubFormulaRight();
    }



}
