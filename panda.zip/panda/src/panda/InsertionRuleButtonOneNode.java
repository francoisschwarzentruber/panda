/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 * This class is a button for applying a rule when one node is selected.
 * @author Ancmin
 */
abstract public class InsertionRuleButtonOneNode extends InsertionRuleButton {

    InsertionRuleButtonOneNode(String codeLaTEX)
    {
        super(codeLaTEX);
        
    }


    /**
     *
     * @param nodes
     * @return true iff there is only one node in nodes and this node satisfies the
     * condition for applying the rule
     * (see testIfRuleApplicable(ProofFormulaNodeNatDet node);
     */
    boolean testIfRuleApplicable(ArrayList<ProofFormulaNode> nodes)
    {
        if(nodes.size() != 1)
            return false;
        else
            return testIfRuleApplicable((ProofFormulaNodeNatDet) nodes.get(0));
    }



    /**
     * apply the rule
     * @param proofPanel
     * @param nodes
     */
    void ruleApply(ProofPanel proofPanel, ArrayList<ProofFormulaNode> nodes)
    {
        if(nodes.size() != 1)
            System.out.println("error in a button for applying a rule: one button is ok whereas there is not exactly ONE selected node");
        else
            ruleApply(proofPanel, (ProofFormulaNodeNatDet) nodes.get(0));


    }



    /**
     *
     * @param node
     * @return true iff the node satisfies the condition for applying the rule
     */
    abstract boolean testIfRuleApplicable(ProofFormulaNodeNatDet node);



/**
 * apply the rule on node
 * @param proofPanel
 * @param node
 */
    abstract void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node);
    



}
