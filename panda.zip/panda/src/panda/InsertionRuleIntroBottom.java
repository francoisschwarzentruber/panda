/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroBottom extends InsertionRuleButtonOneNode {
    public InsertionRuleIntroBottom() {
        super("\\frac{\\newnode{A}\\hspace{5mm}\\newnode{\\neg A}}{\\selectednode{\\bot}}(I \\bot)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.getFormula().isBottom() & node.noChildren();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        if(!node.getFormula().isBottom())
            return;

        FormulaDialog d = new FormulaDialog(null, true, proofPanel.getFormulasHypotheses(), "Donne la formule A : ");

        d.setVisible(true);

        if(!d.isOK())
            return;


        ProofFormulaNodeNatDet child1 = new ProofFormulaNodeNatDet(null, d.getFormula());
        ProofFormulaNodeNatDet child2 = new ProofFormulaNodeNatDet(null, new Formula("(not " + d.getFormula() + ")"));

        proofPanel.commandExecute(new CommandNodeAddTwoNewChildren(node, child1, child2));

        proofPanel.setNodeSelected(child1);
        
    }

}
