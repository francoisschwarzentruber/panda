/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * PanelFormulaSubFormulas.java
 *
 * Created on 7 avr. 2011, 17:33:48
 */

package panda;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * contient une formule où les sous-formules sont cliquables
 * @author François Schwarzentruber
 */
public class PanelFormulaSubFormulas extends javax.swing.JPanel {

    final Formula formula;

    /** Creates new form PanelFormulaSubFormulas */
    public PanelFormulaSubFormulas(Formula formula) {
        initComponents();
        this.formula = formula;
        try {
            treatFormula(formula);
        } catch (Exception ex) {
            Logger.getLogger(PanelFormulaSubFormulas.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    private JLabelSubFormulaPart firstLabel(String schemeCode, String latexCode)
    {
        JLabelSubFormulaPart label = new JLabelSubFormulaPart(schemeCode, latexCode, null);
        setup(label);
        add(label);
        return label;
    }


    private void addLabel(String schemeCode, String latexCode, JLabelSubFormulaPart firstLabel)
    {
        JLabelSubFormulaPart label = new JLabelSubFormulaPart(schemeCode, latexCode, firstLabel);
        setup(label);
        add(label);
    }


    private JLabelSubFormulaPart firstLabelTerm(String schemeCode, String latexCode)
    {
        JLabelSubFormulaPart label = new JLabelSubFormulaPart(schemeCode, latexCode, null);
        add(label);
        setup(label);
        return label;
    }


    private void addLabelTerm(String schemeCode, String latexCode, JLabelSubFormulaPart firstLabel)
    {
        JLabelSubFormulaPart label = new JLabelSubFormulaPart(schemeCode, latexCode, firstLabel);
        setup(label);
        add(label);
    }



    private void treatFormula(Formula formula) throws Exception
    {
        if(formula.getSchemeString().startsWith("<"))
        {
            firstLabel(formula.getSchemeString(), "?");
        }
        else if(formula.getSchemeString().equals("top"))
            firstLabel("top", "\\top");
        else
         if(formula.getSchemeString().equals("bottom"))
            firstLabel("bottom", "\\bot");
        else
        if(!formula.getSchemeString().startsWith("("))
        {
            firstLabel(formula.getSchemeString(), formula.getLaTEXCode());
        }
        else

        if(formula.isNot())
        {
            JLabelSubFormulaPart first = firstLabel("(not ", "\\neg");
            treatFormula(formula.getSubFormulaForNot());
            addLabel(")", "", first);
        }
        else
        if(formula.getSubPart(1).getSchemeString().equals("and"))
        {
            if(formula.getNbSubParts() % 2 == 0)
                throw new Exception("Il manque au moins une sous-formule dans cette conjonction");

            JLabelSubFormulaPart first = firstLabel("(", "(");
            treatFormula(formula.getSubPart(0));

            for(int i = 1; i < formula.getNbSubParts(); i+=2)
            {
                if(!formula.getSubPart(i).toString().equals("and"))
                    throw new Exception("J'attends un 'and'");

                addLabel(" and ", " \\wedge ", first);
                treatFormula(formula.getSubPart(i+1));
            }
            addLabel(")", ")", first);
        }
        else
        if(formula.getSubPart(1).getSchemeString().equals("or"))
        {
            if(formula.getNbSubParts() % 2 == 0)
                throw new Exception("Il manque au moins une sous-formule dans cette disjonction");

            JLabelSubFormulaPart first = firstLabel("(", "(");
            treatFormula(formula.getSubPart(0));

            for(int i = 1; i < formula.getNbSubParts(); i+=2)
            {
                if(!formula.getSubPart(i).toString().equals("or"))
                    throw new Exception("J'attends un 'or'");

                addLabel(" or ", " \\vee ", first);
                treatFormula(formula.getSubPart(i+1));
            }
            addLabel(")", ")", first);
        }
        else
        if(formula.getSubPart(1).getSchemeString().equals("imply"))
        {
            JLabelSubFormulaPart first = firstLabel("(", "(");
            treatFormula(formula.getSubPart(0));
            addLabel(" imply ", " \\rightarrow ", first);
            treatFormula(formula.getSubPart(2));
            addLabel(")", ")", first);
        }
        else
        if(formula.getSubPart(1).getSchemeString().equals("equiv"))
        {
            JLabelSubFormulaPart first = firstLabel("(", "(");
            treatFormula(formula.getSubPart(0));
            addLabel(" equiv ", " \\rightarrow ", first);
            treatFormula(formula.getSubPart(2));
            addLabel(")", ")", first);
        }
        else
        if(formula.isForAll())
        {
            JLabelSubFormulaPart first = firstLabel("(forall ", "\\forall ");
            addLabel(" " + formula.getQuantifierVariable() + " ",
                     " " + formula.getQuantifierVariable() + ". ", first);
            treatFormula(formula.getQuantifierSubFormula());
            addLabel(")", "", first);
        }
        else
        if(formula.isExists())
        {
           JLabelSubFormulaPart first = firstLabel("(exists ", "\\exists ");
            addLabel(" " + formula.getQuantifierVariable() + " ",
                     " " + formula.getQuantifierVariable() + ". ", first);
            treatFormula(formula.getQuantifierSubFormula());
            addLabel(")", "", first);
        }
        else    //propositions
        {
            treatPredicat(formula);

        }
     }






        private void treatPredicat(Formula predicat) {
        if(predicat.isAtomic())
        {
            firstLabel(predicat.getSchemeString(),
                       FormulaBox.predicatSymbolToLaTEX(predicat.getSchemeString()));

        }
        else if(predicat.getNbSubParts() == 1)
        {
            firstLabel(predicat.getSchemeString(),
                       FormulaBox.predicatSymbolToLaTEX(predicat.getSchemeString()));
        }
        else
        {
            JLabelSubFormulaPart first = firstLabel(
                    "(" + predicat.getSubPart(0).getSchemeString(),
                    FormulaBox.predicatSymbolToLaTEX(predicat.getSubPart(0).getSchemeString()));

            addLabelTerm(" ", "(", first);
            treatTerm(predicat.getSubPart(1));

            for(int i = 2; i < predicat.getNbSubParts(); i++)
            {
                addLabel(" ", ", ", first);
                treatTerm(predicat.getSubPart(i));
            }


            addLabel(")", ")", first);

        }

    }


     /**
     *
     * @param term
     * @return le code LaTEX correspondant au terme
     */
    protected void treatTerm(Formula term)
    {
        if(term.isAtomic())
        {
            firstLabelTerm(term.getSchemeString(),
                       term.getSchemeString());
        }
        else if(term.getNbSubParts() == 1)
        {
            firstLabelTerm(term.getSchemeString(),
                       term.getSchemeString());
        }
        else
        {
            JLabelSubFormulaPart first = firstLabelTerm(
                    "(" + term.getSubPart(0).getSchemeString(),
                    FormulaBox.predicatSymbolToLaTEX(term.getSubPart(0).getSchemeString()));

            addLabelTerm(" ", "(", first);
            treatTerm(term.getSubPart(1));

            for(int i = 2; i < term.getNbSubParts(); i++)
            {
                addLabelTerm(" ", ", ", first);
                treatTerm(term.getSubPart(i));
            }


            addLabelTerm(")", ")", first);
        }
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setName("Form"); // NOI18N
        setLayout(new javax.swing.BoxLayout(this, javax.swing.BoxLayout.LINE_AXIS));
    }// </editor-fold>//GEN-END:initComponents

    private void setup(final JLabelSubFormulaPart label) {
        final PanelFormulaSubFormulas panel = this;

        label.addMouseListener(new MouseListener() {

            public void mouseClicked(MouseEvent e) {
                if(label.isSelected())
                {
                    deselectPlage(label);
                }
                else
                {

                    JLabelSubFormulaPart firstLabel = label.getFirstLabel();
                    JLabelSubFormulaPart lastLabel = getLastLabel(firstLabel);

                    for(Component c : getComponents())
                    {
                        if(c.getX() >= firstLabel.getX() & c.getX() <= lastLabel.getX())
                        {
                            ((JLabelSubFormulaPart) c).select();
                        }
                    }
                }

                for(MouseListener ml : panel.getMouseListeners())
                {
                    ml.mouseClicked(e);
                }
            }

            public void mousePressed(MouseEvent e) {
                
            }

            public void mouseReleased(MouseEvent e) {
                
            }

            public void mouseEntered(MouseEvent e) {
                
            }

            public void mouseExited(MouseEvent e) {
                
            }




        });
    }



    private JLabelSubFormulaPart getLastLabel(final JLabelSubFormulaPart firstLabel) {
        JLabelSubFormulaPart lastLabel = firstLabel;
        for(Component c : getComponents())
        {
            if((c.getX() > lastLabel.getX()) &
                (((JLabelSubFormulaPart) c).getFirstLabel() == firstLabel))
                lastLabel = (JLabelSubFormulaPart) c;
        }

        return lastLabel;
    }



    int getI(JLabelSubFormulaPart label)
    {
        for(int i = 0;  i < getComponentCount(); i++)
        {
            if(getComponent(i) == label)
                return i;
        }
        return -1;
    }


    JLabelSubFormulaPart getJLabelSubFormulaPart(int i)
    {
        return (JLabelSubFormulaPart) getComponent(i);
    }

    private void deselectPlage(JLabelSubFormulaPart label) {
       for(int i = getI(label);  i < getComponentCount(); i++)
       {
           if(getJLabelSubFormulaPart(i).isSelected())
                getJLabelSubFormulaPart(i).deSelect();
           else
               break;
       }

       for(int i = getI(label)-1;  i >= 0; i--)
       {
           if(getJLabelSubFormulaPart(i).isSelected())
                getJLabelSubFormulaPart(i).deSelect();
           else
               break;
       }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

    private int getPositionSchemeCode(int i)
    {
        int pos = 0;
        for(int j = 0; j < i; j++)
        {
            pos += getJLabelSubFormulaPart(j).getSchemeCode().length();
        }
        return pos;
    }


    public ArrayList<SubFormula> getSubFormulas()
    {
        ArrayList<SubFormula> A = new ArrayList<SubFormula>();

        int i = 0;
        while(i < getComponentCount())
        {
            if(getJLabelSubFormulaPart(i).isSelected())
            {
                int ifinal = getI(
                getLastLabel(getJLabelSubFormulaPart(i)));
                
                final String subFormulaString = getSubFormulaString(i, ifinal);

                A.add(new SubFormula(formula.getSchemeString(), subFormulaString, getPositionSchemeCode(i)));
                i = ifinal + 1;
            }
            else
                i++;

        }

        return A;
        
    }

    private String getSubFormulaString(int idebut, int ifinal) {
        String s = "";
        for(int i = idebut ;  i <= ifinal; i++)
        {
            s += getJLabelSubFormulaPart(i).getSchemeCode();
        }
        return s;
    }

    public String getFormulaSchemeString() {
        return getSubFormulaString(0, getComponentCount()-1);
    }






    
}
