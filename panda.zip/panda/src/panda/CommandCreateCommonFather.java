/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
class CommandCreateCommonFather extends CommandComposees {

    /**
     * crée la commande "ajouter commonFather et le déclarer comme père de tous les noeuds
     * de futureChildren"
     * @param commonFather
     * @param futureChildren
     */
    public CommandCreateCommonFather(ProofFormulaNode commonFather,
                                     ArrayList<ProofFormulaNode> futureChildren) {
            commandAdd(new CommandAddNode(commonFather));

            for(ProofFormulaNode child : futureChildren)
            {
                commandAdd(new CommandNodeAddChild(commonFather, child, child.getPointMilieuHaut()));
            }


    }

}
