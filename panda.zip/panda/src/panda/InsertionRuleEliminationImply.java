/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationImply extends InsertionRuleButtonOneNode {
    public InsertionRuleEliminationImply() {
        super("\\frac{\\newnode{A \\rightarrow B} \\hspace{5mm} \\newnode{A}}{\\selectednode{B}} (E \\rightarrow)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.noChildren() || ((node.getNbChildren() == 1) & !node.isOK());
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        if(node.getNbChildren() == 0)
        {
            FormulaDialog d = new FormulaDialog(null, true, proofPanel.getFormulasHypotheses(), "Donne la formule A : ");

            d.setVisible(true);

            if(!d.isOK())
                return;

            ProofFormulaNodeNatDet childImply = new ProofFormulaNodeNatDet(null, new Formula("(" + d.getFormula() + " imply " + node.getFormula()+")"));
            ProofFormulaNodeNatDet child2 = new ProofFormulaNodeNatDet(null, d.getFormula());

            proofPanel.commandExecute(new CommandNodeAddTwoNewChildren(node, childImply, child2));

            proofPanel.setNodeSelected(childImply);
        }
        else if(node.getNbChildren() == 1)
        {
            if(node.getChild(0).getFormula().isImply())
                if(node.getFormula().equals(node.getChild(0).getFormula().getSubFormulaRight()))
                {
                    completerA(proofPanel, node);
                    return;
                }
                completerAimplyB(proofPanel, node);

        }
    }

    private void completerA(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        Formula A = node.getFormula().getSubFormulaLeft();
        ProofFormulaNodeNatDet child = new ProofFormulaNodeNatDet(null, A);
        proofPanel.commandExecute(new CommandNodeAddNewChild(node, child));
    }

    
    private void completerAimplyB(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        Formula B = node.getFormula();
        Formula A = node.getChild(0).getFormula();

        ProofFormulaNodeNatDet childImply = new ProofFormulaNodeNatDet(null, new Formula("(" + A + " imply " + B + ")"));
        proofPanel.commandExecute(new CommandNodeAddNewChild(node, childImply));

    }

}
