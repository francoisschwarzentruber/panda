/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroAndBUTwoNodes extends InsertionRuleButton {
    public InsertionRuleIntroAndBUTwoNodes() {
        super("\\frac{\\selectednode{A}\\hspace{5mm}\\selectednode{B}}{\\newnode{A \\wedge B}}(I \\wedge)");
    }

    Formula A;
    Formula B;


    @Override
    boolean testIfRuleApplicable(ArrayList<ProofFormulaNode> nodes) {
        if(nodes.size() != 2)
            return false;

        if(!areAllNoFather(nodes))
            return false;

        
        Formula f0 = nodes.get(0).getFormula();
        Formula f1 = nodes.get(1).getFormula();
        
        A = f0;
        B = f1;


        return true;

        
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ArrayList<ProofFormulaNode> nodes) {
        proofPanel.createCommonFatherBarycentre(nodes, new Formula("(" + A + " and " + B + ")"));
    }

   
}
