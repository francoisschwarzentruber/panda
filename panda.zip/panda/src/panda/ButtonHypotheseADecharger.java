/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.awt.Color;

/**
 * A button for an temporary hypothesis.
 * @author Ancmin
 */
public class ButtonHypotheseADecharger extends ButtonLaTEXImage {

    public ButtonHypotheseADecharger(HypotheseTemporaireDechargee hypothese) throws Exception {
        super(hypothese.getNumeroHypothese() + ". " + FormulaBox.formulaSchemeToLatexCode(hypothese.getFormula()));
        setBackground(new Color(0.7f, 0.7f, 1.0f));
    }


}
