/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 * This command changes the formula in a given node.
 * @author Ancmin
 */
class CommandNodeChangeFormula implements Command {

    private final Formula newFormula;
    private final Formula lastFormula; //we save the lastformula in order to be
    //able to cancel
    private final ProofFormulaNode node;

    public CommandNodeChangeFormula(ProofFormulaNode node, Formula formula) {
        this.node = node;
        this.newFormula = formula;
        this.lastFormula = this.node.getFormula();
        
    }

    public void execute(ProofPanel proofPanel) {
        node.setFormula(newFormula);
    }

    public void undo(ProofPanel proofPanel) {
        node.setFormula(lastFormula);
    }

}
