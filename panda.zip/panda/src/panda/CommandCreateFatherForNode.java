/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class CommandCreateFatherForNode extends CommandComposees {

/**
 * crée la commande qui ajoute le père dans la preuve et qui le connecte
 * au noeud child déjà existant
 * @param father
 * @param child
 */
    CommandCreateFatherForNode(ProofFormulaNode father, ProofFormulaNode child)
    {
        commandAdd(new CommandAddNode(father));
        commandAdd(new CommandNodeAddChild(father, child, child.getPointMilieuHaut()));
    }
}
