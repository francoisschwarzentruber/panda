/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroForall extends InsertionRuleButtonOneNode {
    public InsertionRuleIntroForall() {
        super("\\frac{\\newnode{A}}{\\selectednode{\\forall x. A}} (I \\forall)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.getFormula().isForAll() & node.noChildren();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        ProofFormulaNodeNatDet child = new ProofFormulaNodeNatDet(null, node.getFormula().getQuantifierSubFormula());

        proofPanel.commandExecute(new CommandNodeAddNewChild(node, child));
        proofPanel.setNodeSelected(child);
        
    }

}
