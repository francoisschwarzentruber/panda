/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 * règle E \exists avec uniquement une formule existencielle
 * @author Ancmin
 */
public class InsertionRuleEliminationExistsBUNodeExists extends InsertionRuleButtonOneNode {
    public InsertionRuleEliminationExistsBUNodeExists() {
        super("\\frac{\\selectednode{\\exists x . A} \\hspace{0mm}" +
                "\\begin{array}{c}A(i) \\\\ \\vdots\\\\\\newnode{C}\\end{array}}" +
                " {\\newnode{C}} (E \\exists)(i)");
    }





    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.getFormula().isExists() & node.noFather();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        FormulaDialog d = new FormulaDialog(null, true, proofPanel.getFormulasHypotheses(), 
                java.util.ResourceBundle.getBundle("panda/resources/InsertionRuleButton").getString("giveConclusion"));
        d.setVisible(true);

        if(!d.isOK())
           return;



       Formula conclusionFormula = d.getFormula();

        CommandComposees c = new CommandComposees();

        ProofFormulaNodeNatDet C1 = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), conclusionFormula);
        ProofFormulaNodeNatDet conclu = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), conclusionFormula);

        c.commandAdd(new CommandAddNode(C1));
        c.commandAdd(new CommandAddNode(conclu));

        c.commandAdd(new CommandNodeAddChild(conclu, node, node.getPointMilieuHaut()));
        c.commandAdd(new CommandNodeAddChild(conclu, C1, C1.getPointMilieuHaut()));

        


        proofPanel.commandExecute(c);
    }

   
}
