/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.awt.Color;

/**
 * bouton pour une hypothèse
 * @author Ancmin
 */
class ButtonHypothesePeutEtreDechargeable extends ButtonLaTEXImage {
/**
 * crée un bouton pour une hypothèse
 * @param formula
 * @throws Exception
 */
    public ButtonHypothesePeutEtreDechargeable(Formula formula) throws Exception {
        super(FormulaBox.formulaSchemeToLatexCode(formula));
        setBackground(new Color(1.0f, 0.5f, 0.5f));
    }


}
