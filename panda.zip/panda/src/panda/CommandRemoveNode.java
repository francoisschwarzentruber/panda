/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class CommandRemoveNode implements Command {

    private final ProofFormulaNode nodeToRemove;

    public CommandRemoveNode(ProofFormulaNode nodeToRemove) {
        this.nodeToRemove = nodeToRemove;
    }

    

    public void execute(ProofPanel proofPanel) {
        proofPanel.nodeRemove(nodeToRemove);
    }

    public void undo(ProofPanel proofPanel) {
        proofPanel.nodeAdd(nodeToRemove);
    }

}
