/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroBottomBUTwoNodes extends InsertionRuleButton {
    public InsertionRuleIntroBottomBUTwoNodes() {
        super("\\frac{\\selectednode{A}\\hspace{5mm}\\selectednode{\\neg A}}{\\newnode{\\bot}}(I \\bot)");
    }



    @Override
    boolean testIfRuleApplicable(ArrayList<ProofFormulaNode> nodes) {
        if(nodes.size() != 2)
            return false;
        if(!areAllNoFather(nodes))
            return false;
        Formula f0 = nodes.get(0).getFormula();
        Formula f1 = nodes.get(1).getFormula();
        
        if(f0.isNot())
                if(f1.equals(f0.getSubFormulaForNot()))
                {
                    return true;
                }

            if(f1.isNot())
                if(f0.equals(f1.getSubFormulaForNot()))
                {
                   return true;
                }


        return false;

        
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ArrayList<ProofFormulaNode> nodes) {
        proofPanel.createCommonFatherBarycentre(nodes, new Formula("bottom"));
    }

   
}
