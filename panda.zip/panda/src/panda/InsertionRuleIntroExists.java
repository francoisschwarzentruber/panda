/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroExists extends InsertionRuleButtonOneNode {
    public InsertionRuleIntroExists() {
        super("\\frac{\\newnode{A[t/x]}}{\\selectednode{\\exists x. A}} (I \\exists)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.getFormula().isExists() & node.noChildren();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        String x = node.getFormula().getQuantifierVariable();

        TermDialog d = new TermDialog(null, true, "Par quoi substitues-tu la variable '" + x  + "' :", x);
        d.setVisible(true);

        if(!d.isOK())
            return;

        Formula t = d.getFormula();

            
        ProofFormulaNodeNatDet child = new ProofFormulaNodeNatDet(null, node.getFormula().getQuantifierSubFormula().substituer(x, t));

        proofPanel.commandExecute(new CommandNodeAddNewChild(node, child));
        proofPanel.setNodeSelected(child);
        
    }

}
