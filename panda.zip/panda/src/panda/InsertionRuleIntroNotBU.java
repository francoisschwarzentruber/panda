/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroNotBU extends InsertionRuleButtonOneNode {
    final Formula formulaA;


    public InsertionRuleIntroNotBU(Formula A) throws Exception {
        super("\\frac{\\begin{array}{c}(i) \\\\ \\vdots \\\\ \\selectednode{\\bot} \\end{array}}{\\newnode{\\neg " +
                FormulaBox.formulaSchemeToLatexCode(A) +
                "}} (I \\neg) (i)");
        formulaA = A;
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return (node.getFormula().isBottom()) & node.noFather();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        ProofFormulaNodeNatDet father = new ProofFormulaNodeNatDet(node.getPointMilieuHaut(), new Formula("(not " + formulaA + ")"));
        proofPanel.commandExecute(new CommandCreateFatherForNode(father, node));
        proofPanel.setNodeSelected(father);
        

    }

}
