/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.HashSet;
import java.util.Set;
import jscheme.JScheme;
import jscheme.SchemePair;

/**
 * This class represents a formula.
 * rem : it uses the library JScheme in order to parse formulas written in Scheme style.
 * @author François Schwarzentruber
 */
public class Formula {

    /**
     * moteur Scheme pour parser les formules
     */
    final static private JScheme jscheme = new JScheme();

    /**
     * représentation "scheme" de la formule (fourni par jscheme)
     */
    private final Object schemeFormula;

//    static public Formula createAnd(Formula f1, Formula f2) {
//        String s1, s2;
//
//        if(f1 == null)
//            return f2;
//        else
//            s1 = f1.getSchemeString();
//
//        if(f2 == null)
//            return f1;
//        else
//            s2 = f2.getSchemeString();
//
//
//        if(s1.isEmpty())
//            s1 = "top";
//
//        if(s2.isEmpty())
//            s2 = "top";
//
//        return new Formula("(" + s1 + " and " + s2 +")");
//    }



    
    

    public Formula(String schemeStyleFormulaText) {
        schemeFormula = jscheme.eval("'" + schemeStyleFormulaText);

    }


    

    private Formula(Object objectJScheme) {
        schemeFormula = objectJScheme;

    }


    /**
     *
     * @param i
     * @return the subpart n° i
     * this function is low level. In (p and (q or e)), p is getSubPart(0),
     * "and" getSubPart(1) and "(q or e)" is getSubPart(2)
     */
    public Formula getSubPart(int i)
    {
        return new Formula(((SchemePair) ((SchemePair) schemeFormula).listTail(i)).first());
        
    }



    /**
     *
     * @return the number of subparts of the formula
     * example : (p and (e or q)) gives 3 (p, and, and (e or q))
     */
    public int getNbSubParts()
    {
        return ((SchemePair) schemeFormula).length();
    }



    /**
     *
     * @return le code Scheme par exemple "(p or q)"
     */
    public String getSchemeString()
    {
        return schemeFormula.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if(obj instanceof Formula)
              return getSchemeString().equals(((Formula) obj).getSchemeString());
        else if (obj instanceof String)
            return getSchemeString().equals(obj);
        else
            return false;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + (this.schemeFormula != null ? this.schemeFormula.hashCode() : 0);
        return hash;
    }

    @Override
    public String toString() {
        return getSchemeString();
    }


/**
 *
 * @return vrai ssi la formule courante est un prédicat
     * 
     * exemple pour (p and q) retourne non
     * pour "p" retourne oui
     * pour "(forall x phi)" retourne non
     * pour "(p (q x) j)" retourne oui
 */
    public boolean isPredicat()
    {
        return !isAnd() & !isOr() & !isExists() & !isForAll() & !isImply() & !isNot();
    }

/**
     * 
     * @return vrai ssi la formule courante est une formule quantifiée (un "pour tout" ou un "il existe")
     */
    public boolean isQuantifiedFormula()
    {
        return isExists() || isForAll();
    }

    /**
     * 
     * @return vrai ssi la formule est une conjunction, une disjonction ou une implication
     */
    public boolean isAndOrOrOrImply()
    {
        return isAnd() || isOr() || isImply();
    }
    

    /**
     *
     * @return vrai ssi la formule n'est absolument plus décomposable
     * exemple : "x", "p", "i" --> oui
     * "(p i j)" --> non
     * "(a and (exists x psi))" --> non
     */
    public boolean isAtomic()
    {
        return !getSchemeString().startsWith("(");
    }




    /**
     *
     * @param operatorName
     * @return true iff the formula is of the form (... operatorName ...)
     */
    private boolean isBinaryOperator(String operatorName)
    {
        if(isAtomic())
            return false;

        if(getNbSubParts() != 3)
            return false;
        else
            return getSubPart(1).getSchemeString().equals(operatorName);
    }


/**
 *
 * @param operatorName
 * @return true iff the formula is of the form (operatorName ...)
 */
    private boolean isUnaryPrefixOperator(String operatorName)
    {
        if(isAtomic())
            return false;

        if(getNbSubParts() != 2)
            return false;
        else
            return getSubPart(0).getSchemeString().equals(operatorName);
    }


/**
     * 
     * @return vrai ssi la formule est une implication
     */
    public boolean isImply() {
        return isBinaryOperator("imply");
    }



    public Formula getSubFormulaRight()
    {
        if(isBinaryOperator("equiv"))
            return new Formula("(" + getSubPart(2) + " imply " + getSubPart(0) + ")");
        else
        return getSubPart(2);
    }


    public Formula getSubFormulaLeft()
    {
        if(isBinaryOperator("equiv"))
            return new Formula("(" + getSubPart(0) + " imply " + getSubPart(2) + ")");
        else
            return getSubPart(0);
    }

    public boolean isAnd() {
        return isBinaryOperator("and") || isBinaryOperator("equiv");
    }


    public boolean isOr() {
        return isBinaryOperator("or");
    }


    public boolean isNot() {
        return isUnaryPrefixOperator("not");
    }

    /**
     *
     * @return A if the formula is of the form (not A) (and if not, may crash)
     */
    public Formula getSubFormulaForNot() {
        return getSubPart(1);
    }

    boolean isBottom() {
        return getSchemeString().equals("bottom");
    }

    boolean isForAll() {
        if(isAtomic())
            return false;
        else if( getNbSubParts() != 3)
            return false;
        else if(!getSubPart(0).getSchemeString().equals("forall"))
            return false;
        else if(!getSubPart(1).isAtomic())
            return false;
        else
            return true;

    }


    boolean isExists() {
        if(isAtomic())
            return false;
        else if( getNbSubParts() != 3)
            return false;
        else if(!getSubPart(0).getSchemeString().equals("exists"))
            return false;
        else if(!getSubPart(1).isAtomic())
            return false;
        else
            return true;

    }


    /**
     *
     * @return x if the formula is of the form Qx A where Q is a quantifier
     * (if not, may crash)
     */
    public String getQuantifierVariable() {
        return getSubPart(1).getSchemeString();
    }



    /**
     *
     * @return A if the formula is of the form Qx A where Q is a quantifier
     * (if not, may crash)
     */
    public Formula getQuantifierSubFormula() {
        return getSubPart(2);
    }



    /**
     *
     * @param variable
     * @return true iff there is an occurrence of variable in the formula which is free
     */
    public boolean isFreeVariable(String variable) {
        if(isAnd() | isOr() | isImply())
            return getSubFormulaLeft().isFreeVariable(variable) | getSubFormulaRight().isFreeVariable(variable);
        else if(isNot())
            return getSubFormulaForNot().isFreeVariable(variable);
        else if(isForAll() | isExists())
        {
            if(getQuantifierVariable().equals(variable))
                return false;
            else
                return getQuantifierSubFormula().isFreeVariable(variable);
        }
        else
            return appears(variable);

    }



/**
     * 
     * @return les variables libres de la formule
     * exemple : "(p x y)" renvoie {x, y}
     * "(exists x (p x y))" renvoie {y}
     */
    public Set<String> getFreeVariables()
    {
        Set<String> V = getVariables();
        Set<String> VF = new HashSet<String>();

        for(String var : V)
        {
            if(isFreeVariable(var))
                VF.add(var);
        }
        return VF;
    }

    /**
     * 
     * @return l'ensemble des variables qui apparaissent dans la formule
     * exemple : "(p x y)" renvoie {x, y}
     * "(exists x (p x y))" renvoie {x y}
     */
    public Set<String> getVariables()
    {
         if(isAnd() | isOr() | isImply())
         {
            Set<String> S = getSubFormulaLeft().getVariables();
            S.addAll(getSubFormulaRight().getVariables());
            return S;
         }
        else if(isNot())
            return getSubFormulaForNot().getVariables();
        else if(isForAll() | isExists())
        {
            Set<String> S = new HashSet();
            S.add(getQuantifierVariable());
            S.addAll(getQuantifierSubFormula().getVariables());
            return S;
            
        }
        else if(isAtomic())
        {
            Set<String> S = new HashSet();
            return S;
        }
        else
        {
            Set<String> S = new HashSet();
             for(int i = 1; i < getNbSubParts(); i++)
            {
                S.addAll(getTermVariables(getSubPart(i)));
            }
            return S;

        }

    }

    
    /**
     * 
     * @param variable
     * @return vrai ssi le mot variable apparait comme partie atomique de la formule
     */
    private boolean appears(String variable) {
        if(isAtomic())
            return getSchemeString().equals(variable);
        else
        {
            for(int i = 0; i < getNbSubParts(); i++)
            {
                if(getSubPart(i).appears(variable))
                    return true;
            }
            return false;
        }
    }




/**
     * 
     * @param variable
     * @param subFormula
     * @return le terme dans lequel les occurences (forcément libres) de la variable variable sont remplacée par le terme subFormula
     */
    public Formula termSubstituer(String variable, Formula subFormula)
    {
        if(isAtomic())
        {
            if(getSchemeString().equals(variable))
                return subFormula;
            else
                return this;
        }
        else
        {
            String s = "(" + getSubPart(0) + " ";
            for(int i = 1;  i < getNbSubParts(); i++)
            {
                s += getSubPart(i).termSubstituer(variable, subFormula) + " ";
            }
            s += ")";

            return new Formula(s);
        }
    }


    /**
     *
     * @param variable
     * @param subFormula
     * @return la formule dans laquelle on a substitué toutes les occurences libres de la variable variable
     * par la sous-forme subFormula
     * 
     */
    public Formula substituer(String variable, Formula subFormula)
    {
        if(isAndOrOrOrImply())
        {
            return new Formula("(" + getSubFormulaLeft().substituer(variable, subFormula) + " " +
                    getBinaryOperator() + " " + getSubFormulaRight().substituer(variable, subFormula) + ")");
        }
        else if(isNot())
        {
            return new Formula("(not " + getSubFormulaForNot().substituer(variable, subFormula) + ")");
        }
        else if(isQuantifiedFormula())
        {
            /**
             * on ne remplace pas si la variable est exactement la variable quantifiée
             */
            if(getQuantifierVariable().equals(variable))
                return this;
            else
                return new Formula("(" + getQuantifier() + " " + getQuantifierVariable() + " " +
                                getQuantifierSubFormula().substituer(variable, subFormula) + ")");
        }
        else if(isAtomic())
            return this;
        else
        {
            String s = "(" + getSubPart(0) + " ";
            for(int i = 1;  i < getNbSubParts(); i++)
            {
                s += getSubPart(i).termSubstituer(variable, subFormula) + " ";
            }
            s += ")";
            return new Formula(s);
        }
    }







    public Formula unifiable(Formula pattern, String variable)
    {
        Formula term = brutalUnifiable(pattern, variable);

        if(term == null)
            return null;
        else if(equals(pattern.substituer(variable, term)))
                return term;
        else return null;
    }


/**
 * 
 * @param pattern
 * @param variable
 * @return the term t if the current formula is pattern[t/variable]
 *      "" if the current formula does not contain variable so that any substitution
 *               can work
 *      null if it is not brutalUnifiable
 */
    public Formula brutalUnifiable(Formula pattern, String variable)
    {
        if(pattern.isForAll() | pattern.isExists())
        {
            if(!(isForAll() | isExists()))
            {
                return null;
            }

            if(!getSubPart(0).equals(getSubPart(0)))
                return null;

            if(!getSubPart(1).equals(getSubPart(1)))
                return null;

            if(getSubPart(1).getSchemeString().equals(variable))
            {
                if(getSubPart(2).equals(pattern.getSubPart(2)))
                    return new Formula("<?>");
                else
                    return null;
            }
            else
                return getSubPart(2).brutalUnifiable(pattern.getSubPart(2), variable);
        }
        else
        if(pattern.isAtomic())
        {
            if(pattern.getSchemeString().equals(variable))
            {
                return this;
            }
            else
            {
                if(pattern.equals(this))
                    return new Formula("<?>");
                else
                    return null;
            }
                
        }
        else if(isAtomic())
            return null;
        else if(pattern.getNbSubParts() != getNbSubParts())
            return null;
        else if(pattern.getNbSubParts() == 0)
        {
            return new Formula("<?>");
        }
        {
            Formula t = getSubPart(0).brutalUnifiable(pattern.getSubPart(0), variable);

            if(t == null)
                return null;
            
            for(int i = 0;  i < getNbSubParts(); i++)
            {
                Formula t2 = getSubPart(i).brutalUnifiable(pattern.getSubPart(i), variable);

                if(t2 == null)
                    return null;
                if(t.isUndefined())
                    t = t2;
                else if(!t2.isUndefined()) // t et t2
                {
                    if(!t.equals(t2))
                        return null;
                }
                
            }

            return t;
        }
    }



    /**
     *
     * @return true iff the formula is undefined, that is to say it is of the form
     * <???> or <phi>, <psi> etc. "(p or q)" is defined, "(p or <phi>)" is also... defined.
     * but not <phi>.
     */
    public boolean isUndefined() {
        return getSchemeString().startsWith("<");
    }




    /**
     *
     * @param variable
     * @param t
     * @return true if the substitution of the variable variable by t is ok
     */
    public boolean isSaine(String variable, Formula t) {
        return isSaine(variable, t, new HashSet<String>());
        
    }




/**
     * 
     * @param term
     * @return toutes les variables apparaissant dans le terme term
     */
    private static Set<String> getTermVariables(Formula term)
    {
        Set<String> S = new HashSet<String>();
        putVariables(term, S);
        return S;
    }

    private boolean isSaine(String variable, Formula t, Set<String> setVariablesPortees) {

        if(isForAll() | isExists())
        {
            Set<String> S = new HashSet<String>(setVariablesPortees);
            S.add(getQuantifierVariable());
            return getQuantifierSubFormula().isSaine(variable, t, S);
        }
        else
        if(isAtomic())
        {
            if(getSchemeString().equals(variable))
            {
                return !setVariablesPortees.removeAll(getTermVariables(t));
            }
            else
            {
                return true;
            }

        }
        else
        {
            for(int i = 0;  i < getNbSubParts(); i++)
            {
                if(!getSubPart(i).isSaine(variable, t, setVariablesPortees))
                    return false;

            }

            return true;
        }
    }

    
    /**
     * ajoute toutes les variables apparaissant dans le terme term dans l'ensemble S
     * @param term
     * @param S 
     */
    private static void putVariables(Formula term, Set<String> S) {
        if(term.isAtomic())
            S.add(term.getSchemeString());
        else
        {
            for(int i = 1;  i < term.getNbSubParts(); i++)
            {
                putVariables(term.getSubPart(i), S);

            }
        }
    }

    boolean isNotNot() {
        if(!isNot())
            return false;
        else
            return getSubFormulaForNot().isNot();
    }

    public String getLaTEXCode() {
        try {
            return FormulaBox.formulaSchemeToLatexCode(this);
        } catch (Exception ex) {
            return null;
        }
    }

    private String getBinaryOperator() {
        return getSubPart(1).getSchemeString();
    }

    private String getQuantifier() {
        return getSubPart(0).getSchemeString();
    }

    public Formula getPredicatName() {
        return getSubPart(0);
    }

    public Formula getFunctionName() {
        return getSubPart(0);
    }


    public boolean isEgalite()
    {
        if(isAtomic())
            return false;

        if(getNbSubParts() != 3)
            return false;
        
        return getSubPart(0).equals("=");
    }

    
    
    public Formula getEgaliteLeft()
    {
        return getSubPart(1);
    }
    
    
    public Formula getEgaliteRight()
    {
        return getSubPart(2);
    }

    
    public boolean equalsTo(Formula formulaOne, Formula expression1, Formula expression2) {
        if(isAndOrOrOrImply())
        {
            if(!formulaOne.isAndOrOrOrImply())
                return false;
            
            return getBinaryOperator().equals(formulaOne.getBinaryOperator()) & 
                   getSubFormulaLeft().equalsTo(formulaOne.getSubFormulaLeft(), expression1, expression2) &
                   getSubFormulaRight().equalsTo(formulaOne.getSubFormulaRight(), expression1, expression2);
        }
        else if(isNot())
        {
            if(!formulaOne.isNot())
                return false;
            
            return getSubFormulaForNot().equalsTo(formulaOne.getSubFormulaForNot(), expression1, expression2);
        }
        else if(isQuantifiedFormula())
        {
            if(!formulaOne.isQuantifiedFormula())
                return false;
            
            if(!getQuantifier().equals(formulaOne.getQuantifier()))
                return false;
            
            if(!getQuantifierVariable().equals(formulaOne.getQuantifierVariable()))
                return false;
                
            return getQuantifierSubFormula().equalsTo(formulaOne.getQuantifierSubFormula(), expression1, expression2);
            
        }
        else if(isAtomic())
            return equals(formulaOne);
        else
        {
            if(getNbSubParts() != formulaOne.getNbSubParts())
                return false;
            
            if(!getSubPart(0).equals(formulaOne.getSubPart(0)))
                return false;
            
            for(int i = 1;  i < getNbSubParts(); i++)
            {
                if(!getSubPart(i).termEqualsTo(formulaOne.getSubPart(i), expression1, expression2))
                    return false;
            }
            
            return true;
        }
    }

    private boolean termEqualsTo(Formula termOne, Formula expression1, Formula expression2) {
        if(this.equals(expression2) || this.equals(expression1))
            return termOne.equals(expression1) || termOne.equals(expression2);
        

        if(isAtomic() || termOne.isAtomic())
        {
            return equals(termOne);
        }
        
        if(getNbSubParts() != termOne.getNbSubParts())
                return false;
            
        if(!getSubPart(0).equals(termOne.getSubPart(0)))
            return false;

        for(int i = 1;  i < getNbSubParts(); i++)
        {
            if(!getSubPart(i).termEqualsTo(termOne.getSubPart(i), expression1, expression2))
                return false;
        }

        return true;
    }

    boolean isFrom() {
        if(isAtomic())
            return false;
        else if( getNbSubParts() != 2)
            return false;
        else if(!getSubPart(0).getSchemeString().equals("from"))
            return false;
        else
            return true;
    }
    
    
    String getFromWhat()
    {
        return getSubPart(1).getSchemeString();
    }
    
    
    String schemeEval()
    {
        return jscheme.eval(schemeFormula).toString();
    }
    
    
    
}
