/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.awt.Point;

/**
 *
 * @author Ancmin
 */
class CommandNodeDeconnectFromFather implements Command {

    final private ProofFormulaNode currentNode;
    final private Point lastPositioncurrentNode;
    final private Point pointMilieuHaut;
    final private ProofFormulaNode lastFather;

    public CommandNodeDeconnectFromFather(ProofFormulaNode currentNode, Point lastPositioncurrentNode, Point pointMilieuHaut) {
        this.currentNode = currentNode;
        this.lastPositioncurrentNode = (Point) lastPositioncurrentNode.clone();
        this.pointMilieuHaut = (Point) pointMilieuHaut.clone();
        this.lastFather = currentNode.getFather();
    }
    



    

    public void execute(ProofPanel proofPanel) {
        currentNode.deconnectFromFather();
        currentNode.setPointMilieuHaut(pointMilieuHaut);
    }

    public void undo(ProofPanel proofPanel) {
        if(lastFather != null)
        {
            lastFather.addChild(currentNode);
        }
        else
        {
            currentNode.setPointMilieuHaut(lastPositioncurrentNode);
        }
    }



    


    

}
