/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleEliminationImplyBUTwoNodes extends InsertionRuleButton {
    public InsertionRuleEliminationImplyBUTwoNodes() {
        super("\\frac{\\selectednode{A \\rightarrow B} \\hspace{5mm} \\selectednode{A}}{\\newnode{B}} (E \\rightarrow)");
    }

    Formula AimplyB;
    Formula A;


    @Override
    boolean testIfRuleApplicable(ArrayList<ProofFormulaNode> nodes) {


        if(nodes.size() != 2)
            return false;

        if(!areAllNoFather(nodes))
            return false;

        Formula f0 = nodes.get(0).getFormula();
        Formula f1 = nodes.get(1).getFormula();
        
        if(f0.isImply())
                if(f1.equals(f0.getSubFormulaLeft()))
                {
                    AimplyB = f0;
                    A = f1;
                    return true;
                }


        if(f1.isImply())
                if(f0.equals(f1.getSubFormulaLeft()))
                {
                    AimplyB = f1;
                    A = f0;
                    return true;
                }
        return false;

        
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ArrayList<ProofFormulaNode> nodes) {
        proofPanel.createCommonFatherBarycentre(nodes, AimplyB.getSubFormulaRight());
    }

   
}
