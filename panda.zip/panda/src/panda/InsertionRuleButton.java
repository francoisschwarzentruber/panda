/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 * Cette classe représente un bouton qui peut réagir lorsque plusieurs noeuds
 * sont sélectionnées
 * @author Ancmin
 */
abstract public class InsertionRuleButton extends ButtonLaTEXImage {

    InsertionRuleButton(String codeLaTEX)
    {
        super("\\definecolor{rose}{rgb}{1.0,0.5,0.5}" +
             // "\\newcommand{\\newnode}[1]{\\colorbox{cyan}{#1}}" +
                "\\newcommand{\\newnode}[1]{\\mathbf{#1}}" +
              "\\newcommand{\\selectednode}[1]{\\fcolorbox{rose}{white}{#1}}" +

                 codeLaTEX);
        
    }


    static protected String getStringFromRessource(String key)
    {
           return java.util.ResourceBundle.getBundle("panda/resources/InsertionRuleButton").getString(key);
    }
/**
 *
 * @param selectedNodes
 * @return true iff all node in selectedNodes have no father
 */
    protected boolean areAllNoFather(ArrayList<ProofFormulaNode> nodes)
    {
        for(ProofFormulaNode node : nodes)
        {
            if(node.hasFather())
                return false;
        }
        return true;
    }


    /**
     *
     * @param selectedNodes
     * @return true if the selectedNodes satisfies the condition of applying the rule
     */
    abstract boolean testIfRuleApplicable(ArrayList<ProofFormulaNode> selectedNodes);

    /**
     * apply the rule on selectedNodes
     * @param proofPanel
     * @param selectedNodes
     */
    abstract void ruleApply(ProofPanel proofPanel, ArrayList<ProofFormulaNode> selectedNodes);
    



}
