/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import java.util.ArrayList;

/**
 *
 * @author Ancmin
 */
class CommandRemoveNodes extends CommandComposees {

    public CommandRemoveNodes(ArrayList<ProofFormulaNode> selectedNodes) {
        for(ProofFormulaNode node : selectedNodes)
        {
            commandAdd(new CommandRemoveNode(node));
        }
    }

}
