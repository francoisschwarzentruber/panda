/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package panda;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import javax.swing.Icon;
import jscheme.JScheme;
import jsint.Scheme;

/**
 * This class represents a node in a proof tree of natural deduction.
 * @author Ancmin
 */
public class ProofFormulaNodeNatDet extends ProofFormulaNode {

    private static Icon imgRuleEliminationAnd = LaTEX.latexCodeToMiniImageIcon("(E \\wedge)");
    private static Icon imgRuleEliminationImply = LaTEX.latexCodeToMiniImageIcon("(E \\rightarrow)");
    private static Icon imgRuleEliminationNotNot = LaTEX.latexCodeToMiniImageIcon("(E \\neg \\neg)");
    private static Icon imgRuleEliminationBottom = LaTEX.latexCodeToMiniImageIcon("(E \\bot)");
    private static Icon imgRuleEliminationOr = LaTEX.latexCodeToMiniImageIcon("(E \\vee)");
    private static Icon imgRuleIntroAnd = LaTEX.latexCodeToMiniImageIcon("(I \\wedge)");
    private static Icon imgRuleIntroOr = LaTEX.latexCodeToMiniImageIcon("(I \\vee)");
    private static Icon imgRuleIntroBottom = LaTEX.latexCodeToMiniImageIcon("(I \\bot)");
    private static Icon imgRuleIntroImply = LaTEX.latexCodeToMiniImageIcon("(I \\rightarrow)");
    private static Icon imgRuleIntroNot = LaTEX.latexCodeToMiniImageIcon("(I \\neg)");
    private static Icon imgRuleEliminationForall = LaTEX.latexCodeToMiniImageIcon("(E \\forall)");
    private static Icon imgRuleEliminationExists = LaTEX.latexCodeToMiniImageIcon("(E \\exists)");
    private static Icon imgRuleIntroForall = LaTEX.latexCodeToMiniImageIcon("(I \\forall)");
    private static Icon imgRuleIntroExists = LaTEX.latexCodeToMiniImageIcon("(I \\exists)");
    private static Icon imgRuleEqualityReflexivity = LaTEX.latexCodeToMiniImageIcon("(=_{reflexivity})");
    private static Icon imgRuleEqualityCongruence = LaTEX.latexCodeToMiniImageIcon("(=_{congruence})");
    private static Icon imgRuleFrom = LaTEX.latexCodeToMiniImageIcon("Ax");
    
    private int numHypotheseTemporaire = -1; //si le noeud est une feuille hypothèses, cette variable
    //dit si c'est une variable temporaire déchargée et c'est son numéro
    
    private static int numHypotheseTemporaireGenerateur = 0;
    private static Color colorHypotheseTemporaire = new Color(0.0f, 0.0f, 0.7f);
    private static Color colorError = new Color(1.0f, 0.0f, 0.0f);
    private static Font fontHypotheseTemporaire = new Font("Verdana", 0, 12);
    private ArrayList<Integer> hypothesesDechargeesIciNumeros = new ArrayList<Integer>();

    /**
     * réinitialise la numérotation des hypothèses temporaires pour tous les noeuds
     * (histoire que ça recommence bien de 1)
     */
    public static void numerotationHypotheseTemporaireInitialiser() {
        numHypotheseTemporaireGenerateur = 0;
    }

    /**
     *
     * @return a new number for a temporary hypothesis
     */
    private static int getNumHypotheseTemporaireNouvelle() {
        numHypotheseTemporaireGenerateur++;
        return numHypotheseTemporaireGenerateur;

    }

    public int getNumHypotheseTemporaire() {
        return numHypotheseTemporaire;
    }





    public ProofFormulaNodeNatDet(Point pointMilieuHaut, Formula formula) {
        super(pointMilieuHaut, formula);
    }

    /**
     *
     * @return l'image de la règle appliquée (image du rendering LaTEX)
     * ex : (E\\bot) etc.
     * si ce qu'il y a écrit ne matche avec aucune règle de la déduction naturelle
     * alors cette fonction retourne null
     *
     */
    private Icon getImageRule() {

        if (isRuleEliminationAnd()) {
            return imgRuleEliminationAnd;
        } else if (isRuleEliminationImply()) {
            return imgRuleEliminationImply;
        } else if (isRuleEliminationNotNot()) {
            return imgRuleEliminationNotNot;
        } else if (isRuleEliminationBottom()) {
            return imgRuleEliminationBottom;
        } else if (isRuleEliminationOr()) {
            return imgRuleEliminationOr;
        } else if (isRuleIntroAnd()) {
            return imgRuleIntroAnd;
        } else if (isRuleIntroOr()) {
            return imgRuleIntroOr;
        } else if (isRuleIntroBottom()) {
            return imgRuleIntroBottom;
        } else if (isRuleIntroImply()) {
            return imgRuleIntroImply;
        } else if (isRuleIntroNot()) {
            return imgRuleIntroNot;
        } else if (isRuleEliminationForall()) {
            return imgRuleEliminationForall;
        } else if (isRuleEliminationExists()) {
            return imgRuleEliminationExists;
        } else if (isRuleIntroForall()) {
            return imgRuleIntroForall;
        } else if (isRuleIntroExists()) {
            return imgRuleIntroExists;
        }
          else if (isRuleEqualityReflexivity()) {
            return imgRuleEqualityReflexivity;
          }
        else if (isRuleEqualityCongruence()) {
            return imgRuleEqualityCongruence;
        } else if(isRuleFrom())
        {
            return imgRuleFrom;
        }
        else {
            return null;
        }
    }

    /**
     *
     * @return true si le noeud est une hypothèse (ie pas de fils, pas de formules
     * au dessus) et que ce n'est pas une règle
     * true que ce sont une hypothèse verte (principale) ou déchargée
     */
    public boolean isHypothese() {
        return (getNbChildren() == 0) && !isRule();
    }

    /**
     *
     * @return true si c'est une hypothèse temporaire déchargée
     */
    public boolean isHypotheseTemporaire() {
        return (getNbChildren() == 0) & (numHypotheseTemporaire > -1);
    }

    /**
     * ajoute un fils au noeud. Cette fonction s'occupe aussi d'échanger les fils
     * si jamais ils ne sont pas dans le bon ordre
     * (exemple :
     *       C              C               A ou B
     *       -------------------------------------
     *                         C
     *
     * devient
     *
     *       A ou B               C              C
     *       -------------------------------------
     *                         C
     *
     *
     * @param node
     */
    @Override
    public void addChild(ProofFormulaNode node) {
        super.addChild(node);

        if ((getNbChildren() == 2)) {
            if (getFormula().isBottom() & getChild(0).getFormula().isNot()) {
                if (getChild(0).getFormula().getSubFormulaForNot().equals(getChild(1).getFormula())) {
                    echangerChildren2();
                }
            }

            if (getChild(1).getFormula().isImply()) {
                if (getChild(1).getFormula().getSubFormulaLeft().equals(getChild(0).getFormula())
                        & (getChild(1).getFormula().getSubFormulaRight().equals(getFormula()))) {
                    echangerChildren2();
                }
            }


            if (getChild(1).getFormula().isExists() & !getChild(0).getFormula().isExists()) {
                echangerChildren2();
            }




        }



        if ((getNbChildren() == 3)) {
            ProofFormulaNode C0 = getChild(0);
            ProofFormulaNode C1 = getChild(1);
            ProofFormulaNode C2 = getChild(2);

            if (C0.getFormula().equals(C1.getFormula())) {
                children.clear();
                addChild(C2);
                addChild(C0);
                addChild(C1);
            }

            if (C0.getFormula().equals(C2.getFormula())) {
                children.clear();
                addChild(C1);
                addChild(C0);
                addChild(C2);
            }
        }


        positionsCompute();

    }

    public void hypothesesTemporairesInitialiser() {
        numHypotheseTemporaire = -1;
    }

    /**
     * va se promener dans tous les sous-arbres du noeud courant, à la recherche de "formula" comme hypothèse.
     * Dès qu'il trouve formula, cette fonction marche le noeud-feuille en question avec le numéro
     * d'hypothèse numeroHypothese
     * @param formula
     * @param numeroHypothese
     */
    public void marquerHypothesesTemporairesSousArbres(Formula formula, int numeroHypothese) {
        if (isHypothese()) {
            if (getFormula().equals(formula)) {
                numHypotheseTemporaire = numeroHypothese;
            }
        } else {
            for (ProofFormulaNode child : getChildren()) {
                ((ProofFormulaNodeNatDet) child).marquerHypothesesTemporairesSousArbres(formula, numeroHypothese);
            }
        }
    }

    /**
     * affiche le noeud courant... s'occupe aussi d'afficher les messages d'erreur
     * si jamais ce n'est pas bon etc.
     * @param g
     */
    @Override
    public void drawNode(Graphics g) {
        if (isHypothese() & !isHypotheseTemporaire()) {
            g.setColor(new Color(0.5f, 1.0f, 0.5f));
            g.fillRect(getRectangleFormula().x,
                    getRectangleFormula().y,
                    getRectangleFormula().width,
                    getRectangleFormula().height);
            g.setColor(Color.BLACK);
        }




        super.drawNode(g);

        if (isHypotheseTemporaire()) {
            g.setFont(fontHypotheseTemporaire);
            g.setColor(colorHypotheseTemporaire);
            g.drawLine(getXRight(), getYFormulaTop(), getXLeft(), getYBottom());
            g.drawString("(" + numHypotheseTemporaire + ")", getXRight(), getYFormulaTop());
        }

        g.setColor(Color.BLACK);

        if (getImageRule() != null) {
            getImageRule().paintIcon(null, g, getXRight(), getYFormulaTop() - getImageRule().getIconHeight());

            String s = "";
            for (int i : hypothesesDechargeesIciNumeros) {
                s += "(" + i + ")";
            }

            g.setFont(fontHypotheseTemporaire);
            g.setColor(colorHypotheseTemporaire);
            g.drawString(s, getXRight() + getImageRule().getIconWidth(), getYFormulaTop());
            g.drawString(getMessageCheck(), getXRight() + getImageRule().getIconWidth(), getYFormulaTop());
            g.setColor(Color.BLACK);

        } else if (!isHypothese()) {
            g.setColor(colorError);
            ((Graphics2D) g).setStroke(new BasicStroke(2.0f));
            drawTrait(g);
            g.setFont(fontHypotheseTemporaire);
            g.drawString("???", getXRight(), getYFormulaTop());
            g.setColor(Color.BLACK);

        }
    }

    /**
     *
     * @return true iff the node matches with the Elimination And
     */
    public boolean isRuleEliminationAnd() {
        if (getNbChildren() != 1) {
            return false;
        }

        Formula AandB = getChild(0).getFormula();
        if (!AandB.isAnd()) {
            return false;
        }

        if (AandB.getSubFormulaLeft().equals(getFormula())) {
            return true;
        }

        if (AandB.getSubFormulaRight().equals(getFormula())) {
            return true;
        }

        return false;
    }

    public boolean isRuleEliminationImply() {
        if (getNbChildren() != 2) {
            return false;
        }

        Formula AimplyB = getChild(0).getFormula();
        Formula A = getChild(1).getFormula();
        Formula B = getFormula();

        if (!AimplyB.isImply()) {
            return false;
        }

        if (!B.equals(AimplyB.getSubFormulaRight())) {
            return false;
        }

        if (!A.equals(AimplyB.getSubFormulaLeft())) {
            return false;
        }

        return true;

    }

    public boolean isRuleEliminationNotNot() {
        if (getNbChildren() != 1) {
            return false;
        }

        Formula notnotA = getChild(0).getFormula();
        Formula A = getFormula();

        if (!notnotA.isNot()) {
            return false;
        }

        if (!notnotA.getSubFormulaForNot().isNot()) {
            return false;
        }

        if (!A.equals(notnotA.getSubFormulaForNot().getSubFormulaForNot())) {
            return false;
        }

        return true;


    }

    public boolean isRuleEliminationBottom() {
        if (getNbChildren() != 1) {
            return false;
        }

        if (!getChild(0).getFormula().isBottom()) {
            return false;
        }

        return !getFormula().isNot();

    }

    public boolean isRuleEliminationOr() {
        if (getNbChildren() != 3) {
            return false;
        }

        Formula AorB = getChild(0).getFormula();

        if (!AorB.isOr()) {
            return false;
        }

        if (!getFormula().equals(getChild(1).getFormula())) {
            return false;
        }

        if (!getFormula().equals(getChild(2).getFormula())) {
            return false;
        }

        return true;
    }

    public boolean isRuleIntroAnd() {
        if (!getFormula().isAnd()) {
            return false;
        }

        if (getNbChildren() != 2) {
            return false;
        }

        if (getChild(0).getFormula().equals(getFormula().getSubFormulaLeft())
                & getChild(1).getFormula().equals(getFormula().getSubFormulaRight())) {
            return true;
        }

        if (getChild(1).getFormula().equals(getFormula().getSubFormulaLeft())
                & getChild(0).getFormula().equals(getFormula().getSubFormulaRight())) {
            return true;
        }

        return false;
    }

    public boolean isRuleIntroOr() {
        if (!getFormula().isOr()) {
            return false;
        }

        if (getNbChildren() != 1) {
            return false;
        }

        if (getChild(0).getFormula().equals(getFormula().getSubFormulaLeft())) {
            return true;
        }

        if (getChild(0).getFormula().equals(getFormula().getSubFormulaRight())) {
            return true;
        }

        return false;
    }

    public boolean isRuleIntroBottom() {
        if (!getFormula().isBottom()) {
            return false;
        }

        if (getNbChildren() != 2) {
            return false;
        }

        Formula A = getChild(0).getFormula();
        Formula notA = getChild(1).getFormula();

        if (!notA.isNot()) {
            return false;
        }

        if (!A.equals(notA.getSubFormulaForNot())) {
            return false;
        }

        return true;
    }

    public boolean isRuleIntroImply() {
        if (!getFormula().isImply()) {
            return false;
        }

        if (getNbChildren() != 1) {
            return false;
        }

        if (!getChild(0).getFormula().equals(getFormula().getSubFormulaRight())) {
            return false;
        }

        return true;
    }

    public boolean isRuleIntroNot() {
        if (getNbChildren() != 1) {
            return false;
        }

        if (!getChild(0).getFormula().isBottom()) {
            return false;
        }

        return getFormula().isNot();

    }

    public boolean isRuleEliminationForall() {
        if (getNbChildren() != 1) {
            return false;
        }

        if (!getChild(0).getFormula().isForAll()) {
            return false;
        }

        Formula Atx = getFormula();
        String x = getChild(0).getFormula().getQuantifierVariable();
        Formula A = getChild(0).getFormula().getQuantifierSubFormula();

        if ((Atx.brutalUnifiable(A, x) == null)) {
            return false;
        }


        return true;
    }


    public boolean isRuleFrom()
    {
        if (getNbChildren() != 1) {
            return false;
        }
        
        if (!getChild(0).getFormula().isFrom()) {
            return false;
        }
        
        return true;
    }

    public boolean isRuleEliminationExists() {
        if (getNbChildren() != 2) {
            return false;
        }


        if (!getChild(0).getFormula().isExists()) {
            return false;
        }

        if (!getChild(1).getFormula().equals(getFormula())) {
            return false;
        }

        return true;
    }

    
    
    
    
    
    
    
    private boolean checkRuleFrom() {
        if(getChild(0).getFormula().getFromWhat().equals("eval"))
        {
            try
            {
                return getFormula().schemeEval().equals("true");
            }
            catch(Exception e)
            {
                return false;
            }
        }
        return false;
    }
    /**
     *
     * @return true if the extra condition for the elimination exists rule is ok.
     */
    public boolean checkRuleEliminationExists() {
        Formula existsA = getChild(0).getFormula();
        Formula A = existsA.getQuantifierSubFormula();
        String x = existsA.getQuantifierVariable();

        for (Formula hypothese : ((ProofFormulaNodeNatDet) getChild(1)).getHypothesesPrincipalesArbre()) {
            if (!hypothese.equals(A)) {
                if (hypothese.isFreeVariable(x)) {
                    return false;
                }
            }
        }


        if (getFormula().isFreeVariable(x)) {
            return false;
        }

        return true;
    }

    public boolean checkRuleIntroExists() {
        Formula A = getFormula().getQuantifierSubFormula();
        String x = getFormula().getQuantifierVariable();
        Formula Atx = getChild(0).getFormula();

        Formula t = Atx.unifiable(A, x);

        return (A.isSaine(x, t));
    }

    public boolean checkRuleEliminationForall() {
        Formula Atx = getFormula();
        String x = getChild(0).getFormula().getQuantifierVariable();
        Formula A = getChild(0).getFormula().getQuantifierSubFormula();

        Formula t = Atx.unifiable(A, x);

        return (A.isSaine(x, t));
    }

    public boolean isRuleIntroForall() {
        if (getNbChildren() != 1) {
            return false;
        }

        if (!getFormula().isForAll()) {
            return false;
        }

        if (!getFormula().getQuantifierSubFormula().equals(getChild(0).getFormula())) {
            return false;
        }




        //verifier la liberte
        return true;
    }

    public boolean checkRuleIntroForall() {
        for (Formula hypothese : ((ProofFormulaNodeNatDet) getChild(0)).getHypothesesPrincipalesArbre()) {
            if (hypothese.isFreeVariable(getFormula().getQuantifierVariable())) {
                return false;
            }
        }

        return true;
    }

    public boolean isRuleIntroExists() {
        if (getNbChildren() != 1) {
            return false;
        }

        if (!getFormula().isExists()) {
            return false;
        }

        Formula A = getFormula().getQuantifierSubFormula();
        String x = getFormula().getQuantifierVariable();
        Formula Atx = getChild(0).getFormula();

        if ((Atx.unifiable(A, x) == null)) {
            return false;
        }



        return true;
    }
    
    
    
    
    
    
    
    
    
    public boolean isRuleEqualityReflexivity()
    {
        if(!getFormula().isEgalite())
            return false;
        
        return getFormula().getEgaliteLeft().equals(getFormula().getEgaliteRight());
    }
    
    

    public void calculerHypothesesTemporaires() {
        hypothesesDechargeesIciNumeros.clear();

        if (isRuleEliminationOr()) {
            Formula AorB = getChild(0).getFormula();

            hypothesesDechargeesIciNumeros.add(getNumHypotheseTemporaireNouvelle());
            hypothesesDechargeesIciNumeros.add(getNumHypotheseTemporaireNouvelle());

            ((ProofFormulaNodeNatDet) getChild(1)).marquerHypothesesTemporairesSousArbres(AorB.getSubFormulaLeft(),
                    hypothesesDechargeesIciNumeros.get(0));
            ((ProofFormulaNodeNatDet) getChild(2)).marquerHypothesesTemporairesSousArbres(AorB.getSubFormulaRight(),
                    hypothesesDechargeesIciNumeros.get(1));

        } else if (isRuleEliminationExists()) {
            Formula A = getChild(0).getFormula().getQuantifierSubFormula();

            hypothesesDechargeesIciNumeros.add(getNumHypotheseTemporaireNouvelle());

            ((ProofFormulaNodeNatDet) getChild(1)).marquerHypothesesTemporairesSousArbres(A,
                    hypothesesDechargeesIciNumeros.get(0));


        } else if (isRuleIntroImply()) {
            hypothesesDechargeesIciNumeros.add(getNumHypotheseTemporaireNouvelle());

            marquerHypothesesTemporairesSousArbres(getFormula().getSubFormulaLeft(), hypothesesDechargeesIciNumeros.get(0));



        } else if (isRuleIntroNot()) {
            hypothesesDechargeesIciNumeros.add(getNumHypotheseTemporaireNouvelle());

            marquerHypothesesTemporairesSousArbres(getFormula().getSubFormulaForNot(), hypothesesDechargeesIciNumeros.get(0));



        }






        for (ProofFormulaNode child : getChildren()) {
            ((ProofFormulaNodeNatDet) child).calculerHypothesesTemporaires();
        }
    }



    /**
     *
     * @return l'ensemble des hypothèses principales dans l'arbre en question
     *
     * Exemple :
     * Dans la "fausse" preuve ci-dessous
     *
     *                                 (p x)
     *                           ================
     *   (exists x (p x))        (forall x (p x))
     * ==========================================
     *          (forall x (p x))
     *
     * les hypothèses principales sont "(exists x (p x))".
     *
     *
     * Par contre, si on applique cette fonction à (*) alors la fonction
     * retourne (p x) comme hypothèse principale
     * 
     *
     *                               (p x)
     *                           ====================
     *   (exists x (p x))        (forall x (p x)) (*)
     * ==============================================
     *          (forall x (p x))
     *
     *
     *
     *
     *
     *
     *
     *
     */
    public Set<Formula> getHypothesesPrincipalesArbre() {
        if(isHypothese())
        {
            Set<Formula> Hyp = new HashSet<Formula>();
            Hyp.add(getFormula());
            return Hyp;
        }
        else
        {
            

            if (isRuleEliminationOr()) {
                Set<Formula> Hyp = new HashSet<Formula>();
                Formula AorB = getChild(0).getFormula();

                Set<Formula> Hyp1 = ((ProofFormulaNodeNatDet) getChild(1)).getHypothesesPrincipalesArbre();
                Hyp1.remove(AorB.getSubFormulaLeft());

                Set<Formula> Hyp2 = ((ProofFormulaNodeNatDet) getChild(2)).getHypothesesPrincipalesArbre();
                Hyp2.remove(AorB.getSubFormulaRight());
           
                Hyp.addAll(Hyp1);
                Hyp.addAll(Hyp2);

                return Hyp;

            } else if (isRuleEliminationExists()) {
                Set<Formula> Hyp = new HashSet<Formula>();
                Set<Formula> Hyp0 = ((ProofFormulaNodeNatDet) getChild(0)).getHypothesesPrincipalesArbre();
                Set<Formula> Hyp1 = ((ProofFormulaNodeNatDet) getChild(1)).getHypothesesPrincipalesArbre();

                Formula A = getChild(0).getFormula().getQuantifierSubFormula();

                Hyp1.remove(A);

                Hyp.addAll(Hyp0);
                Hyp.addAll(Hyp1);

                return Hyp;


            } else if (isRuleIntroImply()) {
                Set<Formula> Hyp0 = ((ProofFormulaNodeNatDet) getChild(0)).getHypothesesPrincipalesArbre();
                Hyp0.remove(getFormula().getSubFormulaLeft());
                return Hyp0;


            } else if (isRuleIntroNot()) {
                Set<Formula> Hyp0 = ((ProofFormulaNodeNatDet) getChild(0)).getHypothesesPrincipalesArbre();
                Hyp0.remove(getFormula().getSubFormulaForNot());
                return Hyp0;

            }
            else
            {
                Set<Formula> Hyp = new HashSet<Formula>();
                for(ProofFormulaNode child :getChildren())
                {
                      Hyp.addAll(((ProofFormulaNodeNatDet) child).getHypothesesPrincipalesArbre());
                }

                return Hyp;
            }




            
        }

    }


    

    private void getHypothesesArbre(Set<Formula> F) {
        if (isHypothese()) {
            F.add(getFormula());
        } else {
            for (ProofFormulaNode child : getChildren()) {
                ((ProofFormulaNodeNatDet) child).getHypothesesArbre(F);
            }
        }
    }



    
    /**
     *
     * @return l'ensemble des hypothèses de l'arbre dont ce noeud est la racine
     * L'ensemble contient les hypothèses qu'elles soient principales ou temporaires déchargées.
     */
    public Set<Formula> getHypothesesArbre() {
        Set<Formula> F = new HashSet<Formula>();
        getHypothesesArbre(F);
        return F;
    }


    /**
     *
     * @return l'ensemble des hypothèses déchargées ici dans ce noeud
     * Cette ensemble est de cardinal 0 la plus part du temps
     * 1 pour (I->) par exemple
     * 2 pour (E\/) par exemple
     */
    public ArrayList<Formula> getFormulasHypothesesDechargeesIciDansCeNoeud() {
        ArrayList<Formula> F = new ArrayList<Formula>();
        if (isRuleEliminationOr()) {
            F.add(getChild(0).getFormula().getSubFormulaLeft());
            F.add(getChild(0).getFormula().getSubFormulaRight());
        } else if (isRuleIntroImply()) {
            F.add(getFormula().getSubFormulaLeft());
        } else if (isRuleIntroNot()) {
            F.add(getFormula().getSubFormulaForNot());
        } else if (isRuleEliminationExists()) {
            F.add(getChild(0).getFormula().getQuantifierSubFormula());
        }


        return F;
    }


    /**
     *
     * @param hypothese
     * @return l'ensemble des hypothèses déchargées ici !!
     */
    public Set<HypotheseTemporaireDechargee> getHypothesesDechargeesIciDansCeNoeud()
    {
        Set<HypotheseTemporaireDechargee> S = new HashSet<HypotheseTemporaireDechargee>();
        ArrayList<Formula> F = getFormulasHypothesesDechargeesIciDansCeNoeud();
        for(int i = 0; i < F.size(); i++)
        {
            S.add(new HypotheseTemporaireDechargee(hypothesesDechargeesIciNumeros.get(i), F.get(i)));
        }
        return S;
        
    }


    /**
     *
     * @return - either the singleton containing the formula of the node if this node is an hypothesis
     * - or the hypotheses that are generated (déchargé) here
     */
    public Set<Formula> getHypothesesGeneres() {
        Set<Formula> F = new HashSet<Formula>();

        if (isHypothese()) {
            F.add(getFormula());
            return F;
        } else {
            getFormulasHypothesesDechargeesIciDansCeNoeud();
        }

        return F;
    }

    public boolean isOK() {
        return (getImageRule() != null) || isHypothese();
    }

    public String getMessageCheck() {
        if (isRuleEliminationExists()) {
            if (!checkRuleEliminationExists()) {
                return "variable libre !";
            }
        }

        if (isRuleIntroForall()) {
            if (!checkRuleIntroForall()) {
                return "variable libre !";
            }
        }

        if (isRuleIntroExists()) {
            if (!checkRuleIntroExists()) {
                return "substitution non saine !";
            }
        }

        if (isRuleEliminationForall()) {
            if (!checkRuleEliminationForall()) {
                return "substitution non saine !";
            }
        }
        
        
        if (isRuleFrom()) {
            if (!checkRuleFrom()) {
                return "non !";
            }
        }
        
        return "";
    }

    @Override
    public String getLaTEXCodeArbre() {
        String s = super.getLaTEXCodeArbre();

        if(isHypotheseTemporaire())
        {
            return s = "{" + s + "}^{(" + getNumHypotheseTemporaire() + ")}";
        }
        else if(isHypothese())
           return s;
        else if(isOK())
        {
            s = s + getRuleNameLaTEXCode();

            for(int i :hypothesesDechargeesIciNumeros)
            {
                s = s + "(" + i + ")";
            }
            return s;
        }

        return s;
    }

    private String getRuleNameLaTEXCode() {
        if (isRuleEliminationAnd()) {
            return "(E\\wedge)";
        } else if (isRuleEliminationImply()) {
            return "(E\\rightarrow)";
        } else if (isRuleEliminationNotNot()) {
            return "(E\\neg)";
        } else if (isRuleEliminationBottom()) {
            return "(E\\bot)";
        } else if (isRuleEliminationOr()) {
            return "(E\\vee)";
        } else if (isRuleIntroAnd()) {
            return "(I\\wedge)";
        } else if (isRuleIntroOr()) {
            return "(I\\vee)";
        } else if (isRuleIntroBottom()) {
            return "(I\\bot)";
        } else if (isRuleIntroImply()) {
            return "(I\\rightarrow)";
        } else if (isRuleIntroNot()) {
            return "(I\\neg)";
        } else if (isRuleEliminationForall()) {
            return "(E\\forall)";
        } else if (isRuleEliminationExists()) {
            return "(E\\exists)";
        } else if (isRuleIntroForall()) {
            return "(I\\forall)";
        } else if (isRuleIntroExists()) {
            return "(I\\exists)";
        } else {
            return null;
        }
    }




    /**
     *
     * @return l'ensemble des hypothèses que l'on peut décharger dans l'arbre de ce noeud
     */
    public ArrayList<Formula> getHypothesesDechargeables() {
        if(noFather())
            return getFormulasHypothesesDechargeesIciDansCeNoeud();
        else
        {
            ProofFormulaNodeNatDet father = ((ProofFormulaNodeNatDet) getFather());
            ArrayList<Formula> F = father.getHypothesesDechargeables(this);
            F.addAll(getFormulasHypothesesDechargeesIciDansCeNoeud());

            return F;
        }

        
    }




    /**
     *
     * @return l'ensemble des hypothèses que l'on peut décharger dans l'arbre de ce noeud
     */
    public ArrayList<Formula> getHypothesesDechargeables(ProofFormulaNodeNatDet child) {
        final ArrayList<Formula> F;
        if(noFather())
            F = new ArrayList<Formula>();
        else
        {
            ProofFormulaNodeNatDet father = ((ProofFormulaNodeNatDet) getFather());
            F = father.getHypothesesDechargeables(this);
        }

        if(isRuleEliminationOr())
        {
            if(child == getChild(1))
                F.add(getChild(0).getFormula().getSubFormulaLeft());
            else if(child == getChild(2))
                F.add(getChild(0).getFormula().getSubFormulaRight());
        }
        else
            F.addAll(getFormulasHypothesesDechargeesIciDansCeNoeud());

        return F;


    }



    /**
     *
     * @return true ssi le noeud est une hypothèse principale (qu'on ne décharge pas)
     */
    public boolean isHypothesePrincipale() {
        return isHypothese() & !isHypotheseTemporaire();
    }



    /**
     *
     * @return true iff there is no error at all in the tree
     */
    public boolean isTreeOK() {
        if(isOK())
        {
            for(ProofFormulaNode n : getChildren())
                if(!((ProofFormulaNodeNatDet) n).isTreeOK())
                    return false;

            return true;
        }
        else
            return false;
    }

    
    /**
     * 
     * @return true iff the current node is a rule
     */
    private boolean isRule() {
        return (getImageRule() != null);
    }

    private boolean isRuleEqualityCongruence() {
        if(getNbChildren() != 2)
            return false;
        
        final Formula formulaEquality = getChild(0).getFormula();
        
        final Formula formulaOne = getChild(1).getFormula();
        final Formula formulaTwo = getFormula();
        
        
        if(!formulaEquality.isEgalite())
            return false;
        
        return formulaTwo.equalsTo(formulaOne, formulaEquality.getEgaliteLeft(), formulaEquality.getEgaliteRight());
        
        
        
        
        
    }

    





    
}
