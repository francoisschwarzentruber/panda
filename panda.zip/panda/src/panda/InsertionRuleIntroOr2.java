/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 *
 * @author Ancmin
 */
public class InsertionRuleIntroOr2 extends InsertionRuleButtonOneNode {
    public InsertionRuleIntroOr2() {
        super("\\frac{\\newnode{B}}{\\selectednode{A \\vee B}}(I \\vee)");
    }

    @Override
    boolean testIfRuleApplicable(ProofFormulaNodeNatDet node) {
        return node.getFormula().isOr() & node.noChildren();
    }

    @Override
    void ruleApply(ProofPanel proofPanel, ProofFormulaNodeNatDet node) {
        if(!node.getFormula().isOr())
            return;
        
        ProofFormulaNodeNatDet child = new ProofFormulaNodeNatDet(null, node.getFormula().getSubFormulaRight());
        proofPanel.commandExecute(
                new CommandNodeAddNewChild(node, child));
        proofPanel.setNodeSelected(child);
        
    }

}
