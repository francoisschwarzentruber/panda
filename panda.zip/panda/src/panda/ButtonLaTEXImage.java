/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

/**
 * This class represents a button made up of LaTEX code. It is a standard JButton
 * but the icon image is made up of the rendering of LaTEX.
 * 
 * @author François Schwarzentruber
 */
abstract public class ButtonLaTEXImage extends javax.swing.JButton {


    /**
     * Example new ButtonLaTEXImage("p \\vee q")
     * ("\\" and "\" because of Java...)
     * @param codeLaTEX
     */
    ButtonLaTEXImage(String codeLaTEX)
    {
        try
        {
            this.setIcon(LaTEX.latexCodeImageIconForButton(codeLaTEX));
        }
        catch(Exception e)
        {
            System.out.println("Erreur de création du bouton. Problème avec le code LaTEX suivant : "+ codeLaTEX);
        }
    }



}
