/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package panda;

import javax.swing.SwingUtilities;

/**
 *
 * @author Ancmin
 */
public class VoiceTopDown extends Thread {

    private final ProofPanel panel;

    VoiceTopDown(ProofPanel panel)
    {
        this.panel = panel;
    }



    
    @Override
    public void run() {
        speak(panel.getSelectedNode());

    }




    private void selectNode(final ProofFormulaNode node)
    {
        SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            panel.setNodeSelected(node);
            panel.repaint();
          }
         });
    }



    private void speakToProveAWehaveToProve(Formula formula)
    {
        int i = (int) Math.floor((Math.random() * 4) % 4);

        switch(i)
        {
            case 0: PandaVoice.speak("In order to prove " + formula + ", we are going to prove "); break;
            case 1: PandaVoice.speak("Our aim is " + formula + ". For that we prove "); break;
            case 2: PandaVoice.speak("I want to prove " + formula + ". So I have constructed a proof for "); break;
            default: PandaVoice.speak("This is a proof tree of " + formula + " because we give proof of ");
        }
        
    }


    private void speak(ProofFormulaNodeNatDet node) {
        selectNode(node);


        if(node.isHypothesePrincipale())
            PandaVoice.speak(node.getFormula() + " is an global hypothesis.");
        else if (node.isHypotheseTemporaire())
            PandaVoice.speak(node.getFormula() + " is an temporary hypothesis.");
        else if(node.isRuleEliminationOr())
        {
            speakToProveAWehaveToProve(node.getFormula());
            selectNode(node.getChild(0));
            PandaVoice.speak(node.getChild(0).getFormula().toString());
            selectNode(node.getChild(1));
            PandaVoice.speak(" and " + node.getChild(1).getFormula().toString());
            PandaVoice.speak(" with the temporary hypothesis " + node.getChild(0).getFormula().getSubFormulaLeft());
            selectNode(node.getChild(2));
            PandaVoice.speak(" and " + node.getChild(2).getFormula().toString());
            PandaVoice.speak(" with the temporary hypothesis " + node.getChild(0).getFormula().getSubFormulaRight());
            
            
        }
        else if(node.isRuleIntroImply())
        {
            speakToProveAWehaveToProve(node.getFormula());
            selectNode(node.getChild(0));
            PandaVoice.speak(node.getChild(0).getFormula().toString());
            PandaVoice.speak(" with the temporary hypothesis " + node.getFormula().getSubFormulaLeft());
        }
        else
        {
            
            speakToProveAWehaveToProve(node.getFormula());
            for(ProofFormulaNode child : node.getChildren())
            {
                selectNode(child);
                PandaVoice.speak(child.getFormula().toString());
            }
        }

        for(ProofFormulaNode child : node.getChildren())
        {
                speak((ProofFormulaNodeNatDet) child);
        }
    }



    




}
